'use strict';
/* smoke_game.js <carpeta_proyecto>
   Ejecuta TODO el juego (engine, world, sectors, character, actors, main) con un DOM y un WebGL simulados:
   arranque, carga por sectores, culling/LOD, zombis, daño por zona, ruido, señuelos, interiores, viaje rápido y guardado. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = process.argv[2] || '.';
const dir = path.join(root, 'app', 'src', 'main', 'assets', 'www', 'js');
const files = ['engine.js', 'world.js', 'sectors.js', 'character.js', 'actors.js', 'main.js'];
const code = files.map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('\n;\n');

// ---------- DOM y WebGL simulados ----------
const GL = new Proxy({}, { get: (t, k) => (k in t ? t[k] : (typeof k === 'string' && k === k.toUpperCase() ? 1 : () => 1)), set: (t, k, v) => { t[k] = v; return true; } });
const els = {};
function makeEl(id) {
  const e = {
    id, style: {}, children: [], className: '', textContent: '', hidden: false, innerHTML: '', value: '', scrollTop: 0, width: 720, height: 1600, listeners: {},
    classList: { add() {}, remove() {}, toggle() {} },
    addEventListener(t, f) { (this.listeners[t] = this.listeners[t] || []).push(f); },
    appendChild(c) { this.children.push(c); return c; }, setAttribute() {}, setPointerCapture() {}, getContext() { return GL; },
    get firstElementChild() { return makeEl('child'); }
  };
  return e;
}
const document = {
  hidden: false, body: makeEl('body'),
  getElementById(id) { return els[id] || (els[id] = makeEl(id)); },
  createElement() { return makeEl('new'); },
  addEventListener() {}
};
const timers = [];
let nowMs = 0, raf = null;
const win = {
  innerWidth: 720, innerHeight: 1600, devicePixelRatio: 2, listeners: {},
  addEventListener(t, f) { (this.listeners[t] = this.listeners[t] || []).push(f); },
  requestAnimationFrame(f) { raf = f; }, Android: null
};
const ls = new Map();
const sandbox = {
  console, document, window: win, performance: { now: () => nowMs }, Date,
  localStorage: { getItem: k => (ls.has(k) ? ls.get(k) : null), setItem: (k, v) => ls.set(k, String(v)) },
  setTimeout(f, ms) { timers.push({ f, at: nowMs + (ms || 0) }); return timers.length; }, clearTimeout() {},
  requestAnimationFrame(f) { raf = f; }, location: { reload() {} }
};
sandbox.window.window = sandbox.window;

const driver = `
;(function () {
  const fail = m => { throw new Error('JUEGO: ' + m); };
  return { fail };
})();
`;
vm.createContext(sandbox);
vm.runInContext(code + driver, sandbox, { filename: 'juego', timeout: 60000 });

let ts = 0;
function frames(n) {
  for (let i = 0; i < n; i++) {
    ts += 16.7; nowMs = ts;
    for (let k = timers.length - 1; k >= 0; k--) if (timers[k].at <= nowMs) { const t = timers.splice(k, 1)[0]; t.f(); }
    raf(ts);
  }
}
const fail = m => { throw new Error('JUEGO: ' + m); };
const S = win.__sim;
if (!S) fail('main.js no expuso __sim (¿falló el arranque?)');
const { G, P, World, Zombies, Npcs } = S;
const key = (k, down) => (win.listeners[down ? 'keydown' : 'keyup'] || []).forEach(f => f({ key: k, preventDefault() {} }));
const stats = {};

try {
  // 1) arranque + carga del mundo detrás del menú
  frames(30);
  S.startGame(true);
  frames(240);
  if (World.count() < 20) fail('pocas celdas cargadas: ' + World.count());
  if (!(World.stats.drawn > 0)) fail('no se dibujó ninguna celda');
  stats.celdas = World.count(); stats.dibujadas = World.stats.drawn; stats.lod = World.stats.lod.join('/');

  // 2) movimiento: avanzar, correr, agacharse; el ruido cambia
  key('w', true); frames(90); key('w', false);
  if (Math.hypot(P.x - 22, P.z + 14) < 0.5) fail('el jugador no se movió');
  key('c', true); key('c', false); frames(30);
  if (!(P.crouch > 0.5)) fail('no se agachó (crouch=' + P.crouch + ')');
  key('c', true); key('c', false); frames(30);

  // 3) cámara 1ª/3ª persona
  key('v', true); key('v', false); frames(20); if (!G.fp) fail('no cambió a 1ª persona');
  key('f', true); key('f', false); frames(40);   // tajo en 1ª persona
  key('v', true); key('v', false); frames(10); if (G.fp) fail('no volvió a 3ª persona');

  // 4) zombis: individualidad y zonas de daño
  G.mode = 1;
  P.x = 22; P.z = -14; P.y = World.heightAt(P.x, P.z); P.yaw = 0; frames(5);
  const spawnAt = (d) => Zombies.spawn(P.x + Math.sin(P.yaw) * d, P.z + Math.cos(P.yaw) * d, -1);
  const a = spawnAt(1.4), b = spawnAt(8), c2 = spawnAt(-6);
  if (!a || !b || !c2) fail('no se pudieron generar zombis');
  if (a.cad === b.cad && a.strideB === b.strideB && a.leanB === b.leanB) fail('los zombis no tienen variación individual');
  const hitOf = (z, zone, dmg) => Zombies.hit(z, zone, dmg, 0, 1, P);
  if (hitOf(a, 4, 20) !== 'wound') fail('golpe leve a pierna debería ser herida');
  if (hitOf(a, 4, 30) !== 'cut' || !a.cut[4]) fail('pierna izquierda no se cortó');
  if (a.legs !== 1 || !(a.rollB > 0) || !(a.speedK < 0.7)) fail('cojera asimétrica no aplicada');
  const rollBefore = a.rollB;
  if (hitOf(a, 5, 99) !== 'cut' || !a.crawl) fail('sin ambas piernas debería arrastrarse');
  if (hitOf(a, 2, 99) !== 'cut' || a.arms !== 1) fail('brazo no se cortó');
  if (hitOf(a, 1, 10) !== 'stagger') fail('golpe al torso debería tambalear');
  if (hitOf(a, 0, 1) !== 'dead' || !a.dead) fail('la cabeza debería ser letal');
  if (hitOf(b, 3, 99) !== 'cut') fail('brazo derecho no se cortó');
  if (hitOf(b, 3, 10) === 'cut') fail('una parte ya cortada no debe volver a cortarse');
  if (rollBefore === undefined) fail('rollB');
  frames(60);

  // 4b) tajo real con el botón: la altura elegida decide la zona (cojera por pierna, brazo, cabeza letal)
  Zombies.clear(); G.hp = 9999; G.crouchOn = false; frames(20);
  const mk = (d) => { const z = Zombies.spawn(P.x + Math.sin(P.yaw) * d, P.z + Math.cos(P.yaw) * d, -1); z.state = 0; z.moveW = false; z.wT = 999; return z; };
  const slash = (kind) => { G.heightSel = kind; G.cd = 0; G.swing = -1; S.attack(); frames(40); };
  let zt = mk(1.3);
  slash(2); slash(2); slash(2);
  if (!(zt.cut[4] || zt.cut[5])) fail('el tajo bajo no cortó una pierna (hp piernas ' + zt.hp[4] + ',' + zt.hp[5] + ')');
  if (zt.legs < 1 || !(zt.speedK < 0.7)) fail('el tajo bajo no causó cojera');
  zt = mk(1.3); slash(1); slash(1); slash(1); slash(1);
  if (!(zt.cut[2] || zt.cut[3] || zt.hp[1] < 60)) fail('el tajo medio no dañó torso/brazos');
  zt = mk(1.3); slash(0);
  if (!zt.dead || !zt.cut[0]) fail('el tajo alto en la cabeza debería ser letal');
  const kills0 = G.kills; zt = mk(1.3); slash(0); if (G.kills !== kills0 + 1) fail('la baja no se contabilizó');

  // 4c) un zombi que ve al jugador lo persigue y avanza; con ambas piernas cortadas se arrastra más lento
  Zombies.clear(); G.hp = 9999;
  const ch1 = Zombies.spawn(P.x + 10, P.z, -1); ch1.yaw = Math.atan2(P.x - ch1.x, P.z - ch1.z); ch1.seeT = 0; ch1.base = 1.2;
  const d0 = Math.hypot(ch1.x - P.x, ch1.z - P.z); frames(90);
  if (!(ch1.state >= 2)) fail('el zombi no persigue al ver al jugador (estado ' + ch1.state + ')');
  if (!(Math.hypot(ch1.x - P.x, ch1.z - P.z) < d0 - 1)) fail('el zombi no avanza hacia el jugador');
  const cr1 = Zombies.spawn(P.x + 10, P.z + 5, -1); cr1.yaw = Math.atan2(P.x - cr1.x, P.z - cr1.z); cr1.seeT = 0; cr1.base = 1.2;
  Zombies.hit(cr1, 4, 99, 0, 1, P); Zombies.hit(cr1, 5, 99, 0, 1, P);
  const ch2 = Zombies.spawn(P.x - 10, P.z + 5, -1); ch2.yaw = Math.atan2(P.x - ch2.x, P.z - ch2.z); ch2.seeT = 0; ch2.base = 1.2;
  const dc = Math.hypot(cr1.x - P.x, cr1.z - P.z), dn = Math.hypot(ch2.x - P.x, ch2.z - P.z); frames(60);
  if (!((dc - Math.hypot(cr1.x - P.x, cr1.z - P.z)) < (dn - Math.hypot(ch2.x - P.x, ch2.z - P.z)))) fail('sin piernas debería avanzar más lento');

  // 4d) ruido dinámico: agachado < caminar < correr
  Zombies.clear(); G.crouchOn = true; key('w', true); frames(120); const nCrouch = sandbox_noise(); key('w', false);
  G.crouchOn = false; frames(60); key('w', true); frames(120); const nRun = sandbox_noise(); key('w', false);
  function sandbox_noise() { return S.Noise.level; }
  if (!(nCrouch < 6)) fail('agachado debería hacer poco ruido (' + nCrouch + ')');
  if (!(nRun > nCrouch * 2)) fail('correr debería ser mucho más ruidoso (' + nRun + ' vs ' + nCrouch + ')');

  // 5) sonido: un ruido amplio atrae a un infectado lejano sin línea de visión
  const far = Zombies.spawn(P.x + 30, P.z + 30, -1); far.state = 0;
  G.mode = 1;
  const before = far.state;
  Zombies.hear(P.x, P.z, 60, -1);
  if (!(far.state === 1)) fail('el infectado no reaccionó al ruido (estado ' + far.state + ')');
  Zombies.hear(P.x, P.z, 5, -1);
  // agacharse reduce lo que perciben: radio mínimo
  frames(120);

  // 6) señuelo: pulso de ruido en el punto de impacto
  G.decoy = 3; key('g', true); key('g', false); frames(90);
  if (G.decoy !== 2) fail('el señuelo no se lanzó');

  // 7) consumibles
  G.hp = 40; G.med = 2; key('h', true); key('h', false);
  if (!(G.hp > 40)) fail('el botiquín no curó');
  G.adr = 1; key('r', true); key('r', false); frames(30);
  if (!(G.ts < 1)) fail('la adrenalina no activó cámara lenta (ts=' + G.ts + ')');

  // 8) viaje rápido a cada sector (carga dinámica por áreas, relieve, culling)
  const secs = [];
  for (let i = 0; i < 5; i++) {
    S.travelTo(i); frames(40); frames(140);
    secs.push(World.count());
    if (!(World.cellLoaded(P.x, P.z))) fail('sector ' + i + ': celda sin cargar');
    if (!(P.y >= World.heightAt(P.x, P.z) - 0.5)) fail('sector ' + i + ': jugador bajo el terreno');
    key('w', true); frames(60); key('w', false);
    if (Number.isNaN(P.x) || Number.isNaN(P.y)) fail('NaN en la posición');
  }
  stats.sectores = secs.join(',');

  // 9) interiores: entrar, zombis dentro, salir
  for (let i = 0; i < 3; i++) {
    S.travelTo(0); frames(180);
    S.enterInterior(i); frames(60); frames(30);
    if (P.zone !== i) fail('no se entró al interior ' + i);
    frames(120);
    const inZ = Zombies.pool.filter(z => z.active && z.zone === i).length;
    if (inZ < 1) fail('sin zombis en el interior ' + i);
    S.exitInterior(); frames(60); frames(30);
    if (P.zone !== -1) fail('no se salió del interior ' + i);
  }

  // 10) personaje militar: arma pesada, munición y enfriamiento
  G.chIdx = 2; S.startGame(true);
  G.chIdx = 2;
  const sv = ls.get('sim3d_save_v2');
  frames(10);
  G.ch = S.chars[2]; G.ammo = 24; G.wp = 1;
  const t1 = Zombies.spawn(P.x + Math.sin(P.yaw) * 6, P.z + Math.cos(P.yaw) * 6, -1);
  frames(10); G.cd = 0; S.fire(); frames(30);
  if (G.ammo !== 23) fail('el disparo no consumió munición');
  for (let i = 0; i < 8; i++) { G.cd = 0; if (G.jam <= 0) S.fire(); }
  if (!(G.jam > 0)) fail('el arma no se sobrecalentó');

  // 10b) Mundo Abierto: no aparecen zombis ni hay daño
  Zombies.clear(); G.mode = 0; G.hp = 50; frames(400);
  if (Zombies.pool.some(z => z.active)) fail('en Mundo Abierto no deben aparecer zombis');
  G.mode = 1;

  // 11) modo Mundo Abierto: NPC con frases; guardado y carga
  G.mode = 0; frames(60);
  S.save();
  if (!ls.get('sim3d_save_v2')) fail('no se guardó la partida');
  const saved = JSON.parse(ls.get('sim3d_save_v2'));
  if (saved.v !== 2 || typeof saved.x !== 'number') fail('formato de guardado inválido');
  S.startGame(false); frames(120);

  // 12) estrés: 900 frames corriendo por todo el mapa sin excepciones
  key('w', true);
  for (let i = 0; i < 900; i++) { if (i % 150 === 0) P.yaw += 1.7; frames(1); }
  key('w', false);
  stats.fps_sim = 'ok';
  console.log('JUEGO OK · ' + JSON.stringify(stats) + ' · zombis activos ' + Zombies.pool.filter(z => z.active).length);
} catch (e) {
  console.error(String(e && e.stack ? e.stack : e));
  process.exit(1);
}
