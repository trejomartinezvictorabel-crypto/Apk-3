'use strict';
/* smoke_test.js <carpeta_proyecto>
   Prueba del mundo (sin navegador): normales/backface culling, 289 celdas con 3 LOD, puntos de juego libres,
   calles transitables, frustum culling, oclusión por edificios/cerros, colisiones deslizantes y relieve. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = process.argv[2] || '.';
const dir = path.join(root, 'app', 'src', 'main', 'assets', 'www', 'js');
const src = ['engine.js', 'world.js', 'sectors.js', 'character.js', 'actors.js'].map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('\n;\n');

const tests = `
;(function () {
  const fail = m => { throw new Error('MUNDO: ' + m); };

  // 1) backface culling: las normales apuntan hacia afuera y el bobinado coincide con la normal
  function chk(name, fn, cx, cy, cz) {
    const b = new MeshBuilder(); fn(b); let bad = 0;
    for (let i = 0; i < b.n; i += 3) {
      const g = k => b.a.slice((i + k) * 10, (i + k) * 10 + 10), p = g(0), q = g(1), r = g(2);
      const ux = q[0] - p[0], uy = q[1] - p[1], uz = q[2] - p[2], vx = r[0] - p[0], vy = r[1] - p[1], vz = r[2] - p[2];
      if ((uy * vz - uz * vy) * p[3] + (uz * vx - ux * vz) * p[4] + (ux * vy - uy * vx) * p[5] < -1e-9) bad++;
      const mx = (p[0] + q[0] + r[0]) / 3 - cx, my = (p[1] + q[1] + r[1]) / 3 - cy, mz = (p[2] + q[2] + r[2]) / 3 - cz;
      if (p[3] * mx + p[4] * my + p[5] * mz < -1e-6 && !(Math.abs(p[4]) > 0.99 && p[4] < 0)) bad++;
    }
    if (bad) fail('normales/bobinado inválidos en ' + name + ' (' + bad + ')');
  }
  chk('caja', b => addBox(b, 0, 0, 0, 2, 3, 1, 0.7, [1, 1, 1], 0), 0, 1.5, 0);
  chk('cilindro', b => addCyl(b, 0, 0, 0, 1, 0.4, 2, 8, [1, 1, 1], 0), 0, 1, 0);
  chk('cono', b => addCyl(b, 0, 0, 0, 1, 0, 2, 7, [1, 1, 1], 0, 0.7), 0, 0.7, 0);
  chk('esfera', b => addSphere(b, 0, 0, 0, 1, 1.4, 1, 7, 4, [1, 1, 1], 0), 0, 0, 0);

  // 2) las 289 celdas del mapa se construyen con 3 LOD decrecientes y valores finitos
  const fakeR = { newMesh() { return { n: 0, bad: false, upload(d, n) { this.n = n; this.bad = false; for (let i = 0; i < d.length; i += 7) if (!Number.isFinite(d[i])) { this.bad = true; break; } } }; }, makeMesh(b) { const m = this.newMesh(); m.upload(b.data(), b.n); return m; } };
  World.init(fakeR);
  let built = 0, v = [0, 0, 0], maxV0 = 0, t0 = Date.now();
  for (let cx = -GRID_R; cx <= GRID_R; cx++) for (let cz = -GRID_R; cz <= GRID_R; cz++) {
    const c = { cx, cz, key: World.key(cx, cz), mesh: [fakeR.newMesh(), fakeR.newMesh(), fakeR.newMesh()], cols: [], occ: [], nc: 0, nocc: 0, minY: 0, maxY: 0, ready: false, queued: false, occN: 0 };
    buildCell(c); c.ready = true; World.cells.set(c.key, c); built++;
    for (let i = 0; i < 3; i++) { if (c.mesh[i].bad) fail('vértices no finitos en celda ' + cx + ',' + cz + ' LOD' + i); v[i] += c.mesh[i].n; }
    if (c.mesh[0].n > maxV0) maxV0 = c.mesh[0].n;
    if (!(c.mesh[2].n < c.mesh[1].n && c.mesh[1].n < c.mesh[0].n) && c.mesh[0].n > 400) fail('LOD no decreciente en ' + cx + ',' + cz + ': ' + c.mesh.map(m => m.n));
  }
  const ms = Date.now() - t0;
  if (built !== 289) fail('celdas construidas: ' + built);
  if (!(v[1] < v[0] * 0.55 && v[2] < v[1] * 0.45)) fail('LOD sin reducción suficiente: ' + v);
  if (maxV0 > 20000) fail('celda LOD0 demasiado pesada: ' + maxV0);
  World.rebuildOcc();
  if (World.nocc < 30) fail('muy pocos oclusores: ' + World.nocc);

  // 3) puntos de juego libres de colisionadores
  const bad = [];
  const free = (n, x, z, r) => { if (!World.free(x, z, r)) bad.push(n + '(' + x + ',' + z + ')'); };
  STARTS.forEach((s, i) => free('inicio' + i, s.x, s.z, 0.6)); SPAWNS.forEach((s, i) => free('spawn' + i, s.x, s.z, 0.6));
  DOORS.forEach(d => free('puerta ' + d.id, d.x, d.z, 0.6));
  PICKUPS.filter(p => p.zone < 0).forEach(p => free('pickup ' + p.id, p.x, p.z, 0.3)); NPC_SPAWNS.forEach((s, i) => free('npc' + i, s[0], s[1], 0.4));
  if (bad.length) fail('puntos dentro de colisionadores: ' + bad.join(' '));

  // 4) calles transitables entre sectores (pendiente < 0.95 salvo los 8-10 m de cada extremo)
  ROADS.forEach((r, ri) => {
    const segs = []; for (let j = 0; j < r.p.length - 1; j++) segs.push(Math.hypot(r.p[j + 1][0] - r.p[j][0], r.p[j + 1][1] - r.p[j][1]));
    const L = segs.reduce((a, b) => a + b, 0); let acc = 0;
    for (let j = 0; j < r.p.length - 1; j++) {
      const a = r.p[j], b = r.p[j + 1], len = segs[j];
      for (let s = 0; s < len; s++) {
        if (acc + s < 8 || acc + s > L - 10) continue;
        const t1 = s / len, t2 = Math.min(1, (s + 1) / len), x1 = a[0] + (b[0] - a[0]) * t1, z1 = a[1] + (b[1] - a[1]) * t1, x2 = a[0] + (b[0] - a[0]) * t2, z2 = a[1] + (b[1] - a[1]) * t2;
        const sl = Math.abs(World.heightAt(x2, z2) - World.heightAt(x1, z1)) / Math.hypot(x2 - x1, z2 - z1);
        if (sl > 0.95) fail('calle ' + ri + ' intransitable (pendiente ' + sl.toFixed(2) + ' en ' + Math.round(x1) + ',' + Math.round(z1) + ')');
      }
      acc += len;
    }
  });
  if (!(World.heightAt(-152, 126) > 20)) fail('el mirador debería estar en altura');
  if (!(World.heightAt(0, 0) === 0 && World.heightAt(112, 24) === 0)) fail('centro y retén deben ser planos');
  if (!(World.heightAt(190, 0) > 15)) fail('el borde del mapa debería ser montañoso');

  // 5) frustum culling real
  const m = M4.create(), view = M4.create(), pr = M4.create();
  M4.perspective(pr, 1.2, 0.45, 0.12, 130); M4.lookAt(view, 0, 2, 0, 10, 2, 0); M4.mul(m, pr, view); Frustum.extract(m);
  if (!Frustum.aabb(8, 0, -1, 12, 3, 1)) fail('frustum: caja delante debería ser visible');
  if (Frustum.aabb(-12, 0, -1, -8, 3, 1)) fail('frustum: caja detrás debería descartarse');
  if (Frustum.aabb(0, 0, 60, 2, 3, 64)) fail('frustum: caja fuera del FOV debería descartarse');
  if (Frustum.sphere(-20, 2, 0, 1) || !Frustum.sphere(20, 2, 0, 1)) fail('frustum: esfera');

  // 6) oclusión: edificio del aula (50,2) y cerros
  if (!World.rayBlocked(30, 1.6, 2, 70, 3, 2)) fail('oclusión: el aula debería tapar lo que está detrás');
  if (World.rayBlocked(30, 1.6, 20, 70, 3, 20)) fail('oclusión: línea libre marcada como tapada');
  if (!World.rayBlocked(-60, 2, 40, -190, 3, 100)) fail('oclusión: la sierra debería tapar');
  const cam = { x: 30, ey: 1.6, z: 2 }, cell = World.cells.get(World.key(cellOf(70), cellOf(2)));
  const hid = World.cellOccluded(cell, cam);
  if (typeof hid !== 'boolean') fail('cellOccluded');

  // 7) colisiones deslizantes: pared de edificio y escalón de terreno
  const wall = { x: 41.9, y: 0, z: 4, vx: 3, vz: 0, vy: 0, grounded: true, zone: -1 };
  World.resolve(wall);
  if (wall.x > 41.9 - 0.2 + 0.3 || wall.vx > 0.01) fail('el edificio no frenó al jugador (x=' + wall.x + ')');
  const slide = { x: 41.8, y: 0, z: 4, vx: 3, vz: 2, vy: 0, grounded: true, zone: -1 };
  World.resolve(slide);
  if (!(slide.vz > 1.5 && slide.vx <= 0.01)) fail('no desliza a lo largo de la pared (vx=' + slide.vx + ', vz=' + slide.vz + ')');
  const hill = { x: -120, y: 0, z: 90, vx: 0, vz: 0, vy: 0, grounded: false, zone: -1 };
  World.resolve(hill);
  if (Math.abs(hill.y - World.heightAt(-120, 90)) > 0.5 && hill.y < World.heightAt(-120, 90) - 0.01) fail('el jugador quedó bajo el terreno');

  return 'MUNDO OK · ' + built + ' celdas en ' + ms + ' ms · vértices LOD ' + v.map(x => Math.round(x / 1000) + 'k').join('/') + ' · ' + World.nocc + ' oclusores';
})();
`;
const sandbox = { console, performance: { now: () => Date.now() }, setTimeout: () => 0, clearTimeout: () => {}, localStorage: { getItem: () => null, setItem: () => {} } };
try { console.log(vm.runInNewContext(src + tests, sandbox, { filename: 'mundo', timeout: 120000 })); }
catch (e) { console.error(String(e && e.stack ? e.stack : e)); process.exit(1); }
