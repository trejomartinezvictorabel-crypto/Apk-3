'use strict';
/* smoke_test.js <carpeta_proyecto>
   Carga engine.js + world.js + character.js en un contexto aislado (sin navegador) y comprueba:
   generación de celdas, reutilización del pool, colisiones, personaje con todas las combinaciones de atuendo. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = process.argv[2] || '.';
const dir = path.join(root, 'app', 'src', 'main', 'assets', 'www', 'js');
const read = f => fs.readFileSync(path.join(dir, f), 'utf8');
const engine = ['engine.js', 'world.js', 'character.js'].map(read).join('\n;\n');

const tests = `
;(function () {
  const fail = m => { throw new Error('SMOKE: ' + m); };
  let created = 0;
  const fakeR = {
    newMesh() {
      created++;
      return { n: 0, bad: false, upload(d, n) { this.n = n; this.bad = false; for (let i = 0; i < d.length; i++) if (!Number.isFinite(d[i])) { this.bad = true; break; } } };
    },
    makeMesh(b) { const m = this.newMesh(); m.upload(b.data(), b.n); return m; }
  };

  // 1) generación del mundo alrededor del origen
  World.init(fakeR);
  World.update(0, 0, 1e9);
  if (World.count() !== World.total()) fail('celdas cargadas ' + World.count() + ' de ' + World.total());
  let verts = 0, cols = 0;
  for (const c of World.cells.values()) {
    if (c.mesh.bad) fail('vértices no finitos en la celda ' + c.cx + ',' + c.cz);
    verts += c.mesh.n; cols += c.nc;
  }
  if (verts < 5000) fail('muy pocos vértices: ' + verts);
  if (cols < 20) fail('muy pocos colisionadores: ' + cols);
  const meshesBefore = created;

  // 2) streaming: al alejarse se reutilizan buffers (no se crean mallas nuevas)
  World.update(300, 300, 1e9);
  if (World.count() !== World.total()) fail('streaming: celdas ' + World.count());
  if (created !== meshesBefore) fail('el pool no reutiliza mallas (' + created + ' vs ' + meshesBefore + ')');
  World.update(0, 0, 1e9);
  if (created !== meshesBefore) fail('al volver se crearon mallas nuevas');

  // 3) colisiones: un jugador dentro de un árbol o una casa es expulsado
  let tested = 0;
  for (const cell of World.cells.values()) {
    for (let i = 0; i < cell.nc && tested < 40; i++) {
      const c = cell.cols[i];
      if (c.top < 2) continue;
      const p = c.t === 0
        ? { x: c.x + 0.01, y: 0, z: c.z, vx: 0, vz: 0, vy: 0, grounded: true }
        : { x: (c.x0 + c.x1) / 2, y: 0, z: (c.z0 + c.z1) / 2, vx: 0, vz: 0, vy: 0, grounded: true };
      World.resolve(p);
      const inside = c.t === 0
        ? Math.hypot(p.x - c.x, p.z - c.z) < c.r + 0.32 - 1e-3
        : (p.x > c.x0 - 0.32 + 1e-3 && p.x < c.x1 + 0.32 - 1e-3 && p.z > c.z0 - 0.32 + 1e-3 && p.z < c.z1 + 0.32 - 1e-3 &&
           p.x > c.x0 && p.x < c.x1 && p.z > c.z0 && p.z < c.z1);
      if (inside) fail('el jugador sigue dentro de un colisionador');
      tested++;
    }
  }
  if (tested < 5) fail('no se encontraron colisionadores altos para probar');
  // escalón bajo: se sube solo; caja alta: hace falta saltar
  const st = { x: -4, y: 0, z: -9, vx: 0, vz: 0, vy: 0, grounded: true };
  World.resolve(st);
  if (!(st.y > 0.3 && st.y < 0.4)) fail('el primer escalón debería subirse solo (y=' + st.y + ')');

  // 4) interactivos
  if (!World.nearest(4, -5) || World.nearest(4, -5).id !== 'mirror') fail('punto interactivo del espejo no detectado');
  if (World.nearest(500, 500)) fail('interactivo detectado muy lejos');

  // 5) personaje: todas las combinaciones dibujan matrices finitas
  Character.init(fakeR);
  let calls = 0, bad = 0;
  const rec = {
    drawPart(mesh, cur, sx, sy, sz, col, a) {
      calls++;
      for (let i = 0; i < 16; i++) if (!Number.isFinite(cur[i])) bad++;
      if (!(sx > 0 && sy > 0 && sz > 0)) bad++;
    },
    blend() {}
  };
  const stt = { x: 1, y: 0, z: 2, yaw: 0.7, phase: 1.3, speed: 3, grounded: true, t: 2 };
  for (let top = 0; top < 4; top++) for (let bot = 0; bot < 4; bot++) for (let out = 0; out < 3; out++)
    for (let sh = 0; sh < 3; sh++) for (let hs = 0; hs < 6; hs++) for (let stn = 0; stn < 3; stn++) {
      Character.set('top', top, true); Character.set('bottom', bot, true); Character.set('outer', out, true);
      Character.set('shoes', sh, true); Character.set('hairStyle', hs, true); Character.set('stance', stn, true);
      stt.grounded = (top + bot + out) % 2 === 0;
      Character.draw(rec, stt);
    }
  for (let i = 0; i < 20; i++) { Character.randomize(); Character.draw(rec, stt); Character.shadow(rec, 1, 0, 2, 0.3); }
  Character.reset();
  if (calls < 20000) fail('el personaje dibuja muy pocas piezas: ' + calls);
  if (bad) fail('matrices o escalas no finitas en el personaje: ' + bad);

  return 'SMOKE OK · ' + World.total() + ' celdas, ' + verts + ' vértices, ' + cols + ' colisionadores, ' + calls + ' piezas de personaje';
})();
`;

const sandbox = {
  console, performance: { now: () => Date.now() },
  setTimeout: () => 0, clearTimeout: () => {},
  localStorage: { getItem: () => null, setItem: () => {} },
  window: {}, Math, Number, Float32Array, Map, Object, JSON, Array
};
try {
  const result = vm.runInNewContext(engine + tests, sandbox, { filename: 'engine+tests', timeout: 60000 });
  console.log(result);
} catch (e) {
  console.error(String(e && e.stack ? e.stack : e));
  process.exit(1);
}
