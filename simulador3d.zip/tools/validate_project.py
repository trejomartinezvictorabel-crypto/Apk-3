#!/usr/bin/env python3
"""
validate_project.py <carpeta_proyecto> [--red] [--entorno]

Modo normal : verifica que no falte nada (contenedor Android/WebView + motor WebGL),
              revisa sintaxis y rutas, repara Gradle/Manifest/recursos si es posible,
              comprueba las dependencias (solo repositorios PUBLICOS) y ejecuta una
              prueba de humo del motor con Node.js (si esta disponible).
--red       : ademas comprueba en Maven (Google / Central) y Gradle que cada dependencia,
              el plugin de Android y la distribucion de Gradle existen realmente.
--entorno   : solo comprueba herramientas instaladas (Java 17+, Gradle, SDK 36, build-tools).

Escribe un informe en $GITHUB_STEP_SUMMARY. Sale con codigo 1 si queda algun ERROR.
"""
import os
import re
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET

ARGS = [a for a in sys.argv[1:] if not a.startswith("--")]
FLAGS = {a for a in sys.argv[1:] if a.startswith("--")}
ROOT = os.path.abspath(ARGS[0] if ARGS else os.getcwd())
APP_ID = "app.simulador3d"
GRADLE_VERSION = os.environ.get("GRADLE_VERSION", "8.11.1")
rep = []  # (nivel, mensaje)  nivel: OK | REPARADO | AVISO | ERROR


def add(level, msg):
    rep.append((level, msg))
    print(f"[{level}] {msg}", flush=True)


def P(*parts):
    return os.path.join(ROOT, *parts)


def read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)


# ------------------------------------------------------------------ plantillas de reparacion
T = {}
T["settings.gradle"] = """pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "Simulador3D"
include ':app'
"""
T["build.gradle"] = """plugins {
    id 'com.android.application' version '8.9.1' apply false
}
"""
T["gradle.properties"] = """org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
android.suppressUnsupportedCompileSdk=36
"""
T["app/build.gradle"] = """plugins {
    id 'com.android.application'
}

android {
    namespace 'app.simulador3d'
    compileSdk 36

    defaultConfig {
        applicationId 'app.simulador3d'
        minSdk 26
        targetSdk 36
        versionCode 2
        versionName '0.2.0'
    }

    buildTypes {
        release {
            minifyEnabled false
            shrinkResources false
            signingConfig signingConfigs.debug
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }

    lint {
        abortOnError false
        checkReleaseBuilds false
    }
}

dependencies {
    implementation 'androidx.webkit:webkit:1.12.1'
}
"""
T["app/proguard-rules.pro"] = "# Sin reglas: minify desactivado.\n"
T["app/src/main/AndroidManifest.xml"] = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:label="Simulador 3D"
        android:icon="@drawable/ic_launcher"
        android:allowBackup="false"
        android:hardwareAccelerated="true"
        android:enableOnBackInvokedCallback="true"
        android:theme="@style/AppTheme">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTask"
            android:screenOrientation="fullUser"
            android:configChanges="orientation|screenSize|smallestScreenSize|screenLayout|keyboardHidden|uiMode|density|fontScale">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
"""
T["app/src/main/res/values/styles.xml"] = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="@android:style/Theme.Black.NoTitleBar.Fullscreen">
        <item name="android:windowBackground">@android:color/black</item>
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:navigationBarColor">@android:color/transparent</item>
    </style>
</resources>
"""
T["app/src/main/res/drawable/ic_launcher.xml"] = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp" android:height="108dp"
    android:viewportWidth="108" android:viewportHeight="108">
    <path android:fillColor="#0B0B12" android:pathData="M0,0h108v108h-108z" />
    <path android:fillColor="#FFC857" android:pathData="M54,22 L84,40 L84,68 L54,86 L24,68 L24,40 Z" />
    <path android:fillColor="#08080C" android:pathData="M54,36 L72,47 L72,62 L54,73 L36,62 L36,47 Z" />
</vector>
"""

# Archivos que NO se pueden regenerar (codigo del juego)
CRITICAL = [
    "app/src/main/java/app/simulador3d/MainActivity.java",
    "app/src/main/assets/www/index.html",
    "app/src/main/assets/www/js/engine.js",
    "app/src/main/assets/www/js/world.js",
    "app/src/main/assets/www/js/sectors.js",
    "app/src/main/assets/www/js/character.js",
    "app/src/main/assets/www/js/actors.js",
    "app/src/main/assets/www/js/main.js",
]
JS_DIR = P("app", "src", "main", "assets", "www", "js")
HTML = P("app", "src", "main", "assets", "www", "index.html")
MANIFEST = P("app", "src", "main", "AndroidManifest.xml")
APPGRADLE = P("app", "build.gradle")


# ------------------------------------------------------------------ estructura y reparaciones
def check_required():
    for rel, text in T.items():
        path = P(*rel.split("/"))
        if os.path.isfile(path) and os.path.getsize(path) > 0:
            add("OK", f"{rel}")
        else:
            write(path, text)
            add("REPARADO", f"{rel} faltaba: regenerado desde plantilla")
    for rel in CRITICAL:
        if os.path.isfile(P(*rel.split("/"))):
            add("OK", rel)
        else:
            add("ERROR", f"{rel} falta y no se puede regenerar")
    for rel in ("tools/validate_project.py", "tools/smoke_test.js", "tools/smoke_game.js"):
        if not os.path.isfile(P(*rel.split("/"))):
            add("AVISO", f"{rel} no esta en el proyecto")


def ensure_prop(text, key, value):
    pat = re.compile(r"(?m)^\s*" + re.escape(key) + r"\s*=.*$")
    if pat.search(text):
        new = pat.sub(f"{key}={value}", text)
        return new, new != text
    return text.rstrip("\n") + f"\n{key}={value}\n", True


def fix_gradle():
    path = P("gradle.properties")
    text = read(path)
    changed = False
    for k, v in (("android.useAndroidX", "true"), ("android.suppressUnsupportedCompileSdk", "36")):
        text, c = ensure_prop(text, k, v)
        changed = changed or c
    if changed:
        write(path, text)
        add("REPARADO", "gradle.properties: AndroidX / suppressUnsupportedCompileSdk")

    rb = P("build.gradle")
    t = read(rb)
    m = re.search(r"com\.android\.application'\s+version\s+'(\d+)\.(\d+)\.(\d+)'", t)
    if m and (int(m.group(1)), int(m.group(2)), int(m.group(3))) < (8, 9, 1):
        t = t.replace(m.group(0), "com.android.application' version '8.9.1'")
        write(rb, t)
        add("REPARADO", f"AGP {'.'.join(m.groups())} -> 8.9.1 (requerido por compileSdk 36)")
    elif m:
        add("OK", f"AGP {'.'.join(m.groups())}")
    else:
        add("AVISO", "No pude leer la version de AGP en build.gradle")

    st = read(P("settings.gradle"))
    if "include ':app'" not in st and 'include(":app")' not in st:
        write(P("settings.gradle"), T["settings.gradle"])
        add("REPARADO", "settings.gradle no incluia :app: regenerado")

    t = read(APPGRADLE)
    orig = t
    for key, val in (("compileSdk", 36), ("targetSdk", 36), ("minSdk", 26)):
        pat = re.compile(r"(?m)^([ \t]*)" + key + r"(?:Version)?[ \t]*=?[ \t]*\S+[ \t]*$")
        if pat.search(t):
            t = pat.sub(lambda mm, k=key, v=val: f"{mm.group(1)}{k} {v}", t)
        else:
            anchor = "defaultConfig {" if key != "compileSdk" else "android {"
            t = t.replace(anchor, anchor + f"\n        {key} {val}", 1)
    if "namespace" not in t:
        t = t.replace("android {", f"android {{\n    namespace '{APP_ID}'", 1)
    if "signingConfigs.debug" not in t:
        t = re.sub(r"release\s*\{", "release {\n            signingConfig signingConfigs.debug", t, count=1)
    if "androidx.webkit" not in t:
        t = re.sub(r"dependencies\s*\{", "dependencies {\n    implementation 'androidx.webkit:webkit:1.12.1'", t, count=1)
    if t != orig:
        write(APPGRADLE, t)
        add("REPARADO", "app/build.gradle: compileSdk 36 / targetSdk 36 / minSdk 26 / firma / dependencias")
    else:
        add("OK", "app/build.gradle: SDK 36/36/26, firma y webkit correctos")


def fix_manifest():
    ns = "http://schemas.android.com/apk/res/android"
    ET.register_namespace("android", ns)
    a = "{%s}" % ns
    try:
        tree = ET.parse(MANIFEST)
    except ET.ParseError as e:
        write(MANIFEST, T["app/src/main/AndroidManifest.xml"])
        add("REPARADO", f"Manifest mal formado ({e}): regenerado")
        return
    root = tree.getroot()
    changed = False
    app = root.find("application")
    if app is None:
        write(MANIFEST, T["app/src/main/AndroidManifest.xml"])
        add("REPARADO", "Manifest sin <application>: regenerado")
        return
    if app.get(a + "enableOnBackInvokedCallback") != "true":
        app.set(a + "enableOnBackInvokedCallback", "true")
        changed = True
    if app.get(a + "hardwareAccelerated") != "true":
        app.set(a + "hardwareAccelerated", "true")
        changed = True
    act = None
    for x in app.findall("activity"):
        if x.get(a + "name", "").endswith("MainActivity"):
            act = x
    if act is None:
        write(MANIFEST, T["app/src/main/AndroidManifest.xml"])
        add("REPARADO", "Manifest sin MainActivity: regenerado")
        return
    if act.get(a + "exported") != "true":
        act.set(a + "exported", "true")
        changed = True
    has_launcher = any(
        any(c.get(a + "name") == "android.intent.category.LAUNCHER" for c in f.findall("category"))
        for f in act.findall("intent-filter")
    )
    if not has_launcher:
        write(MANIFEST, T["app/src/main/AndroidManifest.xml"])
        add("REPARADO", "MainActivity sin intent-filter LAUNCHER: manifest regenerado")
        return
    if changed:
        tree.write(MANIFEST, encoding="utf-8", xml_declaration=True)
        add("REPARADO", "Manifest: exported / back predictivo / aceleracion por hardware")
    else:
        add("OK", "AndroidManifest.xml correcto")
    text = read(MANIFEST)
    resdir = P("app", "src", "main", "res")
    for kind, name in sorted(set(re.findall(r"@(style|drawable|mipmap)/(\w+)", text))):
        found = False
        if kind == "style":
            vdir = os.path.join(resdir, "values")
            for f in os.listdir(vdir) if os.path.isdir(vdir) else []:
                if f.endswith(".xml") and f'name="{name}"' in read(os.path.join(vdir, f)):
                    found = True
        else:
            for d in os.listdir(resdir) if os.path.isdir(resdir) else []:
                if d.startswith(kind) and any(fn.split(".")[0] == name for fn in os.listdir(os.path.join(resdir, d))):
                    found = True
        if found:
            add("OK", f"Recurso @{kind}/{name}")
        else:
            add("ERROR", f"El manifest usa @{kind}/{name} pero no existe en res/")


# ------------------------------------------------------------------ sintaxis
def strip_code(src, js=False):
    """Quita comentarios y contenido de cadenas en una sola pasada (respeta '//' dentro de cadenas)."""
    out = []
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        two = src[i:i + 2]
        if two == "//":
            while i < n and src[i] != "\n":
                i += 1
        elif two == "/*":
            j = src.find("*/", i + 2)
            i = n if j < 0 else j + 2
        elif c in "\"'" or (js and c == "`"):
            q = c
            i += 1
            while i < n and src[i] != q:
                if src[i] == "\\":
                    i += 1
                elif src[i] == "\n" and q != "`":
                    break
                i += 1
            i += 1
            out.append(q + q)
        else:
            out.append(c)
            i += 1
    return "".join(out)


def balanced(src):
    stack = []
    pairs = {")": "(", "]": "[", "}": "{"}
    for ch in src:
        if ch in "([{":
            stack.append(ch)
        elif ch in ")]}":
            if not stack or stack.pop() != pairs[ch]:
                return False
    return not stack


def check_java():
    path = P(*CRITICAL[0].split("/"))
    if not os.path.isfile(path):
        return
    text = read(path)
    if not balanced(strip_code(text)):
        add("ERROR", "MainActivity.java: llaves/parentesis desbalanceados")
    else:
        add("OK", "MainActivity.java: estructura balanceada")
    if f"package {APP_ID};" not in text:
        add("ERROR", f"MainActivity.java: el package debe ser {APP_ID}")
    if "class MainActivity" not in text:
        add("ERROR", "MainActivity.java: no declara class MainActivity")
    m = re.search(r'"/assets/(www/[\w./-]+)"', text)
    if m:
        target = P("app", "src", "main", "assets", *m.group(1).split("/"))
        if os.path.isfile(target):
            add("OK", f"loadUrl apunta a un archivo existente ({m.group(1)})")
        else:
            add("ERROR", f"loadUrl apunta a {m.group(1)} que no existe")
    else:
        add("AVISO", "No encontre la ruta /assets/www/... en MainActivity.java")
    if shutil.which("javac") and os.environ.get("VALIDATE_JAVAC") == "1":
        add("AVISO", "javac sin classpath de Android: se omite compilacion aislada")


def check_xml():
    resdir = P("app", "src", "main", "res")
    bad = False
    for base, _, files in os.walk(resdir):
        for f in files:
            if f.endswith(".xml"):
                try:
                    ET.parse(os.path.join(base, f))
                except ET.ParseError as e:
                    bad = True
                    add("ERROR", f"XML invalido {os.path.relpath(os.path.join(base, f), ROOT)}: {e}")
    if not bad:
        add("OK", "XML de res/ revisado")


def check_js():
    node = shutil.which("node")
    if not os.path.isdir(JS_DIR):
        return
    symbols = {"engine.js": ["Renderer", "MeshBuilder", "Env", "MStack", "M4", "Frustum"],
               "world.js": ["World", "Interiors", "collideList"],
               "sectors.js": ["SECT", "ROADS", "INT_DEFS", "genCell", "PICKUPS", "DOORS"],
               "character.js": ["Character"],
               "actors.js": ["Zombies", "Npcs", "Noise", "Pieces", "Proj", "Pickups", "Body", "Actors"]}
    for f in sorted(os.listdir(JS_DIR)):
        if not f.endswith(".js"):
            continue
        path = os.path.join(JS_DIR, f)
        text = read(path)
        if node:
            r = subprocess.run([node, "--check", path], capture_output=True, text=True)
            if r.returncode != 0:
                add("ERROR", f"js/{f}: sintaxis invalida\n{r.stderr.strip()[:600]}")
            else:
                add("OK", f"js/{f}: sintaxis valida (node --check)")
        else:
            if balanced(strip_code(text, js=True)):
                add("AVISO", f"js/{f}: sin node; parentesis/llaves balanceados")
            else:
                add("ERROR", f"js/{f}: llaves/parentesis desbalanceados")
        for s in symbols.get(f, []):
            if not re.search(r"\b(class|const|let|var|function)\s+" + s + r"\b", text):
                add("ERROR", f"js/{f}: falta la definicion de {s}")


def check_html():
    if not os.path.isfile(HTML):
        return
    text = read(HTML)
    base = os.path.dirname(HTML)
    refs = re.findall(r'(?:src|href)\s*=\s*"([^"]+)"', text)
    order = []
    for r in refs:
        if r.startswith(("http", "data:", "#", "//")):
            continue
        if os.path.isfile(os.path.normpath(os.path.join(base, r))):
            add("OK", f"index.html -> {r}")
        else:
            add("ERROR", f"index.html referencia {r} que no existe")
        if r.endswith(".js"):
            order.append(os.path.basename(r))
    want = ["engine.js", "world.js", "sectors.js", "character.js", "actors.js", "main.js"]
    if [o for o in order if o in want] != want:
        add("ERROR", "Orden de scripts incorrecto; debe ser engine, world, sectors, character, actors, main")
    ids = set(re.findall(r'id="([\w-]+)"', text))
    for ident in ("gl", "touch", "creator", "toast", "loading", "menu", "hud", "fade", "bubbles", "btn-atk", "btn-crouch", "btn-cam", "btn-throw", "btn-med", "btn-adr", "travel", "dead"):
        if ident not in ids:
            add("ERROR", f'index.html: falta el elemento id="{ident}"')
    main = os.path.join(JS_DIR, "main.js")
    if os.path.isfile(main):
        used = set(re.findall(r"\$\('([\w-]+)'\)", read(main)))
        missing = sorted(u for u in used if u not in ids)
        if missing:
            add("ERROR", "main.js usa ids que no existen en index.html: " + ", ".join(missing))
        else:
            add("OK", f"main.js: los {len(used)} ids del DOM existen en index.html")
    if "viewport-fit=cover" not in text:
        add("AVISO", "index.html: falta viewport-fit=cover (edge-to-edge / notch)")
    if re.search(r'(?:src|href)\s*=\s*"https?://', text):
        add("AVISO", "index.html carga recursos externos: la app deberia ser 100% offline")


def check_smoke():
    node = shutil.which("node")
    for name, label in (("smoke_test.js", "mundo (celdas, LOD, culling, oclusión, colisiones)"),
                        ("smoke_game.js", "juego completo (zombis, zonas, ruido, interiores, viaje, guardado)")):
        smoke = P("tools", name)
        if not os.path.isfile(smoke):
            continue
        if not node:
            add("AVISO", f"Sin Node.js: se omite la prueba de {label}")
            continue
        try:
            r = subprocess.run([node, smoke, ROOT], capture_output=True, text=True, timeout=240)
        except subprocess.TimeoutExpired:
            add("ERROR", f"Prueba de {label}: tiempo agotado")
            continue
        out = (r.stdout + r.stderr).strip()
        if r.returncode == 0:
            add("OK", f"Prueba de {label}: " + (out.splitlines()[-1] if out else "ok"))
        else:
            add("ERROR", f"Prueba de {label} falló\n" + out[-700:])


# ------------------------------------------------------------------ dependencias
GOOGLE_PREFIX = ("androidx.", "com.android.", "com.google.android.", "com.google.firebase",
                 "com.google.gms", "com.google.mlkit", "com.google.testing")
PUBLIC_URLS = ("https://dl.google.com", "https://maven.google.com", "https://repo.maven.apache.org",
               "https://repo1.maven.org", "https://plugins.gradle.org")
DEP_RE = re.compile(
    r"""(?m)^\s*(?:implementation|api|compileOnly|runtimeOnly|annotationProcessor|"""
    r"""testImplementation|androidTestImplementation)\s*\(?\s*['"]([^'":\s]+):([^'":\s]+):([^'":\s]+)['"]""")


def pom_url(group, art, ver):
    base = "https://dl.google.com/dl/android/maven2/" if group.startswith(GOOGLE_PREFIX) \
        else "https://repo.maven.apache.org/maven2/"
    return f"{base}{group.replace('.', '/')}/{art}/{ver}/{art}-{ver}.pom"


def http_ok(url, timeout=20):
    """True = existe, False = 404/410, None = no se pudo verificar (sin red, bloqueo...)."""
    try:
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "validate-project/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return 200 <= r.status < 400
    except urllib.error.HTTPError as e:
        return False if e.code in (404, 410) else None
    except Exception:
        return None


def check_repositories():
    """Solo se admiten repositorios publicos: Google, Maven Central y el portal de plugins de Gradle."""
    files = [P("settings.gradle"), P("build.gradle"), APPGRADLE]
    bad = False
    for path in files:
        if not os.path.isfile(path):
            continue
        text = strip_code(read(path), js=True)
        name = os.path.relpath(path, ROOT)
        if re.search(r"(?i)\b(credentials|password|passwd|apikey|api_key|access[_-]?token|secret)\b", text):
            add("ERROR", f"{name}: credenciales/tokens en Gradle (dependencia privada o comercial no permitida)")
            bad = True
        if re.search(r"\bjcenter\s*\(", text):
            add("ERROR", f"{name}: jcenter() esta cerrado; usa mavenCentral()")
            bad = True
        if re.search(r"\bmavenLocal\s*\(", text) or re.search(r"\bflatDir\b", text):
            add("ERROR", f"{name}: mavenLocal()/flatDir no son repositorios publicos")
            bad = True
        if re.search(r"\b(fileTree|files)\s*\(", text):
            add("AVISO", f"{name}: usa binarios locales (files/fileTree); no son dependencias publicas")
        for m in re.finditer(r"maven\s*\{[^}]*?url\s*(?:=)?\s*(?:uri\s*\()?\s*['\"]([^'\"]+)['\"]", read(path)):
            url = m.group(1)
            if url.startswith(PUBLIC_URLS):
                add("OK", f"{name}: repositorio publico {url}")
            else:
                add("AVISO", f"{name}: repositorio de terceros {url} (no es Google/Central/Gradle)")
    if not bad:
        add("OK", "Repositorios: solo publicos (google / mavenCentral / gradlePluginPortal)")
    st = read(P("settings.gradle")) if os.path.isfile(P("settings.gradle")) else ""
    for repo in ("google()", "mavenCentral()"):
        if repo not in st:
            add("ERROR", f"settings.gradle: falta {repo} en los repositorios")


def parse_deps():
    deps = []
    if os.path.isfile(APPGRADLE):
        for g, a, v in DEP_RE.findall(read(APPGRADLE)):
            deps.append((g, a, v))
    return deps


def check_dependencies(online):
    check_repositories()
    deps = parse_deps()
    if not deps:
        add("ERROR", "app/build.gradle no declara ninguna dependencia (se espera androidx.webkit)")
    for g, a, v in deps:
        coord = f"{g}:{a}:{v}"
        if re.search(r"[+\[\]]|latest|SNAPSHOT", v, re.I):
            add("AVISO", f"{coord}: version dinamica; fija una version exacta")
        else:
            add("OK", f"Dependencia declarada {coord}")
    # compatibilidad AGP <-> Gradle
    need = {(8, 9): (8, 11, 1), (8, 10): (8, 11, 1), (8, 8): (8, 10, 2), (8, 7): (8, 9, 0), (8, 6): (8, 7, 0)}
    m = re.search(r"com\.android\.application'\s+version\s+'(\d+)\.(\d+)\.(\d+)'", read(P("build.gradle")))
    gv = tuple(int(x) for x in re.findall(r"\d+", GRADLE_VERSION)[:3])
    gv = gv + (0,) * (3 - len(gv))
    if m:
        key = (int(m.group(1)), int(m.group(2)))
        if key in need and gv < need[key]:
            add("ERROR", f"AGP {key[0]}.{key[1]} necesita Gradle >= {'.'.join(map(str, need[key]))} (tienes {GRADLE_VERSION})")
        else:
            add("OK", f"AGP {m.group(1)}.{m.group(2)} compatible con Gradle {GRADLE_VERSION}")
    if not online:
        add("AVISO", "Verificacion en linea omitida (usa --red para comprobar Maven y Gradle)")
        return
    checks = [(f"{g}:{a}:{v}", pom_url(g, a, v)) for g, a, v in deps]
    if m:
        ver = ".".join(m.groups())
        checks.append((f"plugin com.android.tools.build:gradle:{ver}",
                       f"https://dl.google.com/dl/android/maven2/com/android/tools/build/gradle/{ver}/gradle-{ver}.pom"))
    checks.append((f"distribucion Gradle {GRADLE_VERSION}",
                   f"https://services.gradle.org/distributions/gradle-{GRADLE_VERSION}-bin.zip"))
    for name, url in checks:
        res = http_ok(url)
        if res is True:
            add("OK", f"Disponible en repositorio publico: {name}")
        elif res is False:
            add("ERROR", f"No existe en el repositorio publico: {name} ({url})")
        else:
            add("AVISO", f"No pude verificar {name} (sin respuesta de la red)")


# ------------------------------------------------------------------ entorno de compilacion
def check_env():
    java = shutil.which("java")
    if not java:
        add("ERROR", "Java no esta instalado")
    else:
        r = subprocess.run([java, "-version"], capture_output=True, text=True)
        m = re.search(r'version "(\d+)', r.stderr + r.stdout)
        major = int(m.group(1)) if m else 0
        add("OK" if major >= 17 else "ERROR", f"Java {major} (se requiere 17 o superior)")
    gr = shutil.which("gradle")
    if not gr:
        add("ERROR", "Gradle no esta en el PATH")
    else:
        r = subprocess.run([gr, "--version"], capture_output=True, text=True, timeout=180)
        m = re.search(r"Gradle (\d+\.\d+(?:\.\d+)?)", r.stdout)
        ver = m.group(1) if m else "?"
        add("OK" if ver.startswith(GRADLE_VERSION) else "AVISO", f"Gradle {ver} (esperado {GRADLE_VERSION})")
    sdk = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")
    if not sdk or not os.path.isdir(sdk):
        add("ERROR", "ANDROID_HOME / ANDROID_SDK_ROOT no apunta a un SDK de Android")
        return
    for rel in ("platforms/android-36", "build-tools/36.0.0", "platform-tools"):
        if os.path.isdir(os.path.join(sdk, rel)):
            add("OK", f"Android SDK: {rel}")
        else:
            add("ERROR", f"Android SDK: falta {rel}")
    if not os.path.isfile(os.path.expanduser("~/.android/debug.keystore")):
        add("AVISO", "No existe ~/.android/debug.keystore (el workflow la crea antes de compilar)")
    else:
        add("OK", "Clave de firma debug disponible")


# ------------------------------------------------------------------ informe
def write_summary(title):
    counts = {k: sum(1 for l, _ in rep if l == k) for k in ("OK", "REPARADO", "AVISO", "ERROR")}
    icon = {"OK": "✅", "REPARADO": "🔧", "AVISO": "⚠️", "ERROR": "❌"}
    lines = [f"## {title}", "",
             f"✅ {counts['OK']} correctos · 🔧 {counts['REPARADO']} reparados · "
             f"⚠️ {counts['AVISO']} avisos · ❌ {counts['ERROR']} errores", ""]
    for lvl in ("ERROR", "REPARADO", "AVISO"):
        items = [m for l, m in rep if l == lvl]
        if items:
            lines.append(f"### {icon[lvl]} {lvl.capitalize()}")
            for m in items:
                parts = m.splitlines()
                lines.append(f"- {parts[0]}" + "".join("\n  " + x for x in parts[1:]))
            lines.append("")
    lines.append("<details><summary>Detalle completo</summary>\n")
    lines += [f"- {icon[l]} {m.splitlines()[0]}" for l, m in rep]
    lines.append("\n</details>\n")
    out = "\n".join(lines)
    dest = os.environ.get("GITHUB_STEP_SUMMARY")
    if dest:
        with open(dest, "a", encoding="utf-8") as fh:
            fh.write(out + "\n")
    return counts


def main():
    print(f"Validando proyecto en {ROOT}")
    if "--entorno" in FLAGS:
        check_env()
        counts = write_summary("Entorno de compilacion")
    else:
        check_required()
        if os.path.isfile(P("gradle.properties")):
            fix_gradle()
            fix_manifest()
        check_dependencies("--red" in FLAGS)
        check_java()
        check_xml()
        check_js()
        check_html()
        check_smoke()
        counts = write_summary("Informe del validador")
    print(f"\nResultado: {counts}")
    if counts["ERROR"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
