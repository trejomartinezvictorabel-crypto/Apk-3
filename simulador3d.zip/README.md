# Simulador 3D (Bloque 1)

Contenido no explícito. Motor WebGL/HTML5 dentro de un WebView Android (compileSdk/targetSdk 36, minSdk 26).

Compilar: sube este .zip a la raíz del repositorio. El workflow `.github/workflows/build.yml`
lo descomprime, ejecuta `tools/validate_project.py` y compila el APK release como artifact.

Validar en local:  python3 tools/validate_project.py .
