# Simulador 3D · Zapopan (Bloque 3 · Parte 1)

Contenido no explícito. Motor WebGL/HTML5 dentro de un WebView Android (compileSdk/targetSdk 36, minSdk 26).

## Novedades del Bloque 3 · Parte 1 (formato horizontal)
- La app abre y se mantiene en horizontal (`sensorLandscape` en el Manifest y por código); en vertical se muestra «Gira el teléfono» y el juego se pausa.
- HUD y controles para jugar de lado: bloque de acciones en el pulgar derecho, consumibles y ritmo en el borde izquierdo, brújula arriba al centro y el centro de la pantalla libre.
- Botón «¿Qué hay?»: descripción breve del entorno en el HUD (la voz llega en una parte posterior).
- Menú a dos columnas con acceso a cambio de personaje/modo, Apariencia y Viaje rápido.

## Novedades del Bloque 2
- Render optimizado: frustum culling real, oclusión por edificios/muros/cerros, backface culling y 3 niveles de detalle + niebla de horizonte.
- Mapa de 5 sectores conectados: Zapopan Centro y Campus, Retén militar, Bosque y sendero, Mirador y ruta serrana, Enlace carretero. Viaje rápido en los postes verdes.
- 3 interiores (aula, caseta del retén, cabaña) con transición suave; el exterior se suspende dentro.
- Zombis con movimiento individual, daño por zona (cabeza letal, cojera por pierna, brazos), piezas desprendidas en pool.
- Machete, 1ª/3ª persona, sigilo, ruido dinámico, señuelos, botiquines, adrenalina (cámara lenta), arma pesada con enfriamiento.
- 3 personajes jugables, modos Mundo Abierto y Modo Zombi, NPC con frases de Jalisco, guardado local.

## Compilar
Sube este .zip a la raíz del repositorio; el workflow `.github/workflows/build.yml` lo descomprime, ejecuta `tools/validate_project.py --red` y compila el APK release.

Validar en local:  python3 tools/validate_project.py .   (requiere Node.js para las pruebas del motor)
