'use strict';
/* =====================================================================
   sectors.js — contenido del mapa: Zapopan y rumbos de Jalisco (5 sectores conectados)
   Relieve, calles/banquetas, props low-poly con 3 LOD, puertas, recolectables e interiores.
   ===================================================================== */
const SECTORS = [
  { id: 0, name: 'Zapopan Centro y Campus', x: 0, z: 0 },
  { id: 1, name: 'Retén militar', x: 112, z: 24 },
  { id: 2, name: 'Bosque y sendero', x: 24, z: 132 },
  { id: 3, name: 'Mirador y ruta serrana', x: -132, z: 88 },
  { id: 4, name: 'Enlace carretero a Guadalajara', x: 24, z: -140 }
];
const SECTOR_R = [70, 56, 66, 84, 62];
function sectorAt(x, z) {
  let best = 0, bd = 1e9;
  for (let i = 0; i < SECTORS.length; i++) {
    const d = Math.hypot(x - SECTORS[i].x, z - SECTORS[i].z) / SECTOR_R[i];
    if (d < bd) { bd = d; best = i; }
  }
  return best;
}

/* ---------- relieve ---------- */
function bump(x, z, cx, cz, rx, rz, a) {
  const dx = (x - cx) / rx, dz = (z - cz) / rz, d = dx * dx + dz * dz;
  if (d >= 1) return 0;
  const t = 1 - d; return a * t * t;
}
function natH(x, z) {
  let h = 0;
  const edge = Math.max(Math.abs(x), Math.abs(z));
  h += Math.pow(smooth(142, 206, edge), 1.4) * 46 * (0.8 + 0.2 * Math.sin(x * 0.05) * Math.cos(z * 0.045)); // cordillera exterior
  h += bump(x, z, -135, 88, 78, 100, 30) + bump(x, z, -168, 40, 40, 34, 14) + bump(x, z, -150, 124, 44, 42, 13); // sierra
  h += bump(x, z, 50, 142, 52, 38, 9) + bump(x, z, -22, 124, 40, 34, 7) + bump(x, z, 22, 168, 50, 24, 10);       // lomas del bosque
  const rural = smooth(60, 95, Math.hypot(x, z));
  h += rural * (Math.sin(x * 0.09 + 1.3) * Math.cos(z * 0.07) * 1.6 + Math.sin(x * 0.21) * Math.sin(z * 0.17) * 0.5);
  h *= smooth(62, 92, Math.hypot(x, z));                               // centro urbano plano
  h *= smooth(34, 62, Math.hypot(x - 112, z - 24));                    // retén plano
  h *= smooth(30, 62, Math.hypot(x - 24, z + 140) * 0.8);              // enlace carretero plano
  return h;
}
const PADS = [{ x: -106, z: 100, r: 9, f: 10 }, { x: -152, z: 126, r: 11, f: 26 }]; // cabaña y mirador
for (const p of PADS) p.h = natH(p.x, p.z);
const SECT = {
  height(x, z) {
    let h = natH(x, z);
    for (let i = 0; i < PADS.length; i++) {
      const p = PADS[i], d = Math.hypot(x - p.x, z - p.z);
      if (d < p.r + p.f) h = p.h + (h - p.h) * smooth(p.r, p.r + p.f, d);
    }
    return h;
  }
};

/* ---------- calles ---------- */
// t: 0 urbana (banquetas) · 1 carretera · 2 terracería · 3 ruta serrana
const ROADS = [
  { t: 0, w: 10, p: [[-64, -24], [64, -24]] }, { t: 0, w: 10, p: [[-64, 24], [64, 24]] },
  { t: 0, w: 10, p: [[-24, -64], [-24, 64]] }, { t: 0, w: 10, p: [[24, -64], [24, 64]] },
  { t: 0, w: 9, p: [[64, 24], [168, 24]] },
  { t: 1, w: 10, p: [[24, -64], [24, -198]] },
  { t: 2, w: 5, p: [[24, 64], [26, 82], [22, 100], [14, 114], [24, 130], [32, 146], [20, 164], [22, 186]] },
  { t: 3, w: 6, p: [[-64, 24], [-86, 34], [-104, 52], [-112, 74], [-122, 96], [-138, 112], [-152, 126]] }
];
function segDist(px, pz, ax, az, bx, bz) {
  const dx = bx - ax, dz = bz - az, l2 = dx * dx + dz * dz;
  let t = l2 ? ((px - ax) * dx + (pz - az) * dz) / l2 : 0; t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (ax + dx * t), pz - (az + dz * t));
}
/** Distancia al borde de la calzada más cercana (negativa = sobre la calzada). */
function roadDist(x, z, skip) {
  let m = 1e9;
  for (let i = 0; i < ROADS.length; i++) {
    if (i === skip) continue;
    const r = ROADS[i];
    for (let j = 0; j < r.p.length - 1; j++) {
      const d = segDist(x, z, r.p[j][0], r.p[j][1], r.p[j + 1][0], r.p[j + 1][1]) - r.w / 2;
      if (d < m) m = d;
    }
  }
  return m;
}

/* ---------- datos de juego ---------- */
const STARTS = [{ x: 22, z: -14, yaw: Math.PI }, { x: -110, z: 70, yaw: Math.PI }, { x: 96, z: 28, yaw: Math.PI / 2 }];
const DOORS = [
  { id: 'aula', idx: 0, x: 40.4, z: 2, name: 'Entrar al aula' },
  { id: 'bunker', idx: 1, x: 112, z: 41.2, name: 'Entrar a la caseta' },
  { id: 'cabana', idx: 2, x: -111, z: 100, name: 'Entrar a la cabaña' }
];
const TPOSTS = [{ sec: 0, x: -9.5, z: -3 }, { sec: 1, x: 98, z: 16 }, { sec: 2, x: 27, z: 96 }, { sec: 3, x: -104, z: 68 }, { sec: 4, x: 31, z: -98 }];
const SPAWNS = [{ x: -9, z: -6 }, { x: 98, z: 21 }, { x: 26, z: 99 }, { x: -107, z: 70 }, { x: 27, z: -100 }];
const PICKUPS = [
  { id: 'm1', t: 'med', x: 18, z: -18, zone: -1 }, { id: 'm2', t: 'med', x: -30, z: 22, zone: -1 },
  { id: 'a1', t: 'adr', x: 4, z: 40, zone: -1 }, { id: 'd1', t: 'decoy', x: -18, z: -30, zone: -1 }, { id: 'd2', t: 'decoy', x: 30, z: 30, zone: -1 },
  { id: 'm3', t: 'med', x: 100, z: 26, zone: -1 }, { id: 'p1', t: 'ammo', x: 118, z: 30, zone: -1 }, { id: 'p2', t: 'ammo', x: 126, z: 24, zone: -1 },
  { id: 'm4', t: 'med', x: 18, z: 118, zone: -1 }, { id: 'd3', t: 'decoy', x: 30, z: 152, zone: -1 }, { id: 'a2', t: 'adr', x: 10, z: 166, zone: -1 },
  { id: 'm5', t: 'med', x: -118, z: 66, zone: -1 }, { id: 'm6', t: 'med', x: -100, z: 92, zone: -1 }, { id: 'a3', t: 'adr', x: -148, z: 119, zone: -1 }, { id: 'd4', t: 'decoy', x: -132, z: 100, zone: -1 },
  { id: 'm7', t: 'med', x: 28, z: -100, zone: -1 }, { id: 'p3', t: 'ammo', x: 30, z: -130, zone: -1 }, { id: 'a4', t: 'adr', x: 20, z: -172, zone: -1 }, { id: 'd5', t: 'decoy', x: 18, z: -118, zone: -1 }
];
const NPC_SPAWNS = [
  [-4, 6], [6, -5], [0, -14], [24, -6], [-24, 10], [44, -6], [38, -20],      // Zapopan Centro y campus
  [108, 30], [103, 14],                                                       // retén
  [18, 110], [30, 142],                                                       // bosque
  [-114, 62], [-128, 104], [-148, 112],                                       // sierra
  [26, -110], [22, -160]                                                      // carretera
];
const KEEPS = [];
STARTS.forEach(s => KEEPS.push({ x: s.x, z: s.z, r: 4 }));
DOORS.forEach(d => KEEPS.push({ x: d.x, z: d.z, r: 4 }));
TPOSTS.forEach(t => KEEPS.push({ x: t.x, z: t.z, r: 3 }));
PICKUPS.forEach(p => KEEPS.push({ x: p.x, z: p.z, r: 1.6 }));

/* ---------- paleta ---------- */
const PC = {
  trunk: rgb(0x6b4a2f), leaf: [rgb(0x2f8f45), rgb(0x3a9a4f), rgb(0x4aa35a)], pine: rgb(0x1f6b3b), oak: rgb(0x3d7a35), rock: rgb(0x80808c), bush: rgb(0x3f9a4a),
  wood: rgb(0x8a5a35), wood2: rgb(0x5e3d24), pole: rgb(0x2a2a33), warm: rgb(0xffd27a), conc: rgb(0x9a9a96), concD: rgb(0x77776f),
  walls: [0xe8dcc0, 0xd9a77a, 0xc98f6a, 0xb8cfe0, 0xe3c566, 0xd47f7f, 0x9fc7a5, 0xf0e4d0].map(rgb),
  roofs: [0x9b3b32, 0x8a4b3a, 0x6d4b8a, 0x3b6f8f].map(rgb), awn: [0xc0392b, 0x2e86de, 0x2e7d4f, 0xe67e22, 0x7d3c98].map(rgb),
  door: rgb(0x3a2a22), win: rgb(0x9fd6ff), olive: rgb(0x55603a), sand: rgb(0xb7a77c), rust: rgb(0x8a4b32), steel: rgb(0x6f7782),
  red: rgb(0xc0392b), white: rgb(0xf2f2f2), green: rgb(0x1f7a4d), stone: rgb(0xb5aa95), agave: rgb(0x5f9a8a), glass: rgb(0xaee7ff), yel: rgb(0xe8c547)
};
const RCOL = [rgb(0x3b3b43), rgb(0x34343c), rgb(0x8c7350), rgb(0x4a4a52)];
const SIDEW = rgb(0xa9a79f);

/* ---------- terreno por celda (3 LOD: 8x8, 4x4, 2x2) ---------- */
const GC = [rgb(0x77746b), rgb(0x857a5f), rgb(0x2f4a24), rgb(0x56602f), rgb(0x76803f)];
const ROCKC = rgb(0x6b665e);
function groundColor(x, z, h, sl) {
  let ws = 0, r = 0, g = 0, b = 0;
  for (let i = 0; i < 5; i++) {
    const d = Math.hypot(x - SECTORS[i].x, z - SECTORS[i].z) / SECTOR_R[i], w = 1 / (0.15 + d * d * d * d);
    ws += w; r += GC[i][0] * w; g += GC[i][1] * w; b += GC[i][2] * w;
  }
  let c = [r / ws, g / ws, b / ws];
  if (Math.abs(x) < 12 && Math.abs(z) < 12) c = [0.66, 0.62, 0.55]; // plaza empedrada
  const t = Math.max(smooth(118, 160, Math.max(Math.abs(x), Math.abs(z))) * 0.9, smooth(0.5, 0.95, sl), smooth(22, 34, h) * 0.7);
  c = mixc(c, ROCKC, t);
  return shade(c, 0.92 + 0.16 * hash3(Math.floor(x / 3), Math.floor(z / 3), 5));
}
const _H = [new Float32Array(81), new Float32Array(25), new Float32Array(9)];
function emitTerrain(cell, L) {
  const x0 = cell.cx * CELL - HALF, z0 = cell.cz * CELL - HALF, NN = [8, 4, 2];
  for (let lod = 0; lod < 3; lod++) {
    const n = NN[lod], s = CELL / n, H = _H[lod], b = L[lod], m = n + 1;
    for (let j = 0; j <= n; j++) for (let i = 0; i <= n; i++) { const h = World.heightAt(x0 + i * s, z0 + j * s); H[j * m + i] = h; tY(cell, h); }
    for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
      const h00 = H[j * m + i], h10 = H[j * m + i + 1], h01 = H[(j + 1) * m + i], h11 = H[(j + 1) * m + i + 1];
      const xa = x0 + i * s, xb = xa + s, za = z0 + j * s, zb = za + s;
      const gx = ((h10 + h11) - (h00 + h01)) / (2 * s), gz = ((h01 + h11) - (h00 + h10)) / (2 * s), nl = Math.hypot(gx, 1, gz);
      const col = groundColor((xa + xb) / 2, (za + zb) / 2, (h00 + h11) / 2, Math.hypot(gx, gz));
      b.quad([xa, h00, za], [xb, h10, za], [xb, h11, zb], [xa, h01, zb], -gx / nl, 1 / nl, -gz / nl, col, 0);
    }
    // faldones: evitan grietas entre celdas con distinto LOD
    const sc = shade(groundColor(x0 + HALF, z0 + HALF, H[(n >> 1) * m + (n >> 1)], 0.2), 0.85);
    for (let i = 0; i < n; i++) {
      const xa = x0 + i * s, xb = xa + s, za = z0 + i * s, zb = za + s;
      b.quad([xa, H[i], z0], [xb, H[i + 1], z0], [xb, H[i + 1] - 3, z0], [xa, H[i] - 3, z0], 0, 0, -1, sc, 0);
      b.quad([xa, H[n * m + i], z0 + CELL], [xb, H[n * m + i + 1], z0 + CELL], [xb, H[n * m + i + 1] - 3, z0 + CELL], [xa, H[n * m + i] - 3, z0 + CELL], 0, 0, 1, sc, 0);
      b.quad([x0, H[i * m], za], [x0, H[(i + 1) * m], zb], [x0, H[(i + 1) * m] - 3, zb], [x0, H[i * m] - 3, za], -1, 0, 0, sc, 0);
      b.quad([x0 + CELL, H[i * m + n], za], [x0 + CELL, H[(i + 1) * m + n], zb], [x0 + CELL, H[(i + 1) * m + n] - 3, zb], [x0 + CELL, H[i * m + n] - 3, za], 1, 0, 0, sc, 0);
    }
  }
}

/* ---------- calles: calzada, banquetas, rayas y cruces peatonales ---------- */
function strip(b, ax, az, bx, bz, nx, nz, o0, o1, dy, col) {
  const P = (x, z, o) => { const px = x + nx * o, pz = z + nz * o; return [px, World.heightAt(px, pz) + dy, pz]; };
  b.quad(P(ax, az, o0), P(ax, az, o1), P(bx, bz, o1), P(bx, bz, o0), 0, 1, 0, col, 0);
}
function emitRoads(cell, L) {
  const x0 = cell.cx * CELL - HALF, x1 = x0 + CELL, z0 = cell.cz * CELL - HALF, z1 = z0 + CELL;
  for (let ri = 0; ri < ROADS.length; ri++) {
    const r = ROADS[ri], hw = r.w / 2;
    for (let lod = 0; lod < 3; lod++) {
      const step = [3, 6, 12][lod], b = L[lod];
      for (let j = 0; j < r.p.length - 1; j++) {
        const a = r.p[j], c = r.p[j + 1], dx = c[0] - a[0], dz = c[1] - a[1], len = Math.hypot(dx, dz), ux = dx / len, uz = dz / len, nx = -uz, nz = ux;
        const n = Math.max(1, Math.ceil(len / step));
        for (let i = 0; i < n; i++) {
          const t0 = i / n, t1 = (i + 1) / n, mx = a[0] + dx * (t0 + t1) / 2, mz = a[1] + dz * (t0 + t1) / 2;
          if (mx < x0 || mx >= x1 || mz < z0 || mz >= z1) continue;
          const ax = a[0] + dx * t0 - ux * 0.3, az = a[1] + dz * t0 - uz * 0.3, bx = a[0] + dx * t1 + ux * 0.3, bz = a[1] + dz * t1 + uz * 0.3;
          strip(b, ax, az, bx, bz, nx, nz, -hw, hw, 0.05, RCOL[r.t]);
          const onOther = roadDist(mx, mz, ri) < 0.4;
          if (r.t === 0 && lod < 2 && !onOther) { strip(b, ax, az, bx, bz, nx, nz, hw, hw + 2.4, 0.1, SIDEW); strip(b, ax, az, bx, bz, nx, nz, -hw - 2.4, -hw, 0.1, SIDEW); }
          if (lod === 0 && r.t !== 2 && (i & 1) === 0 && !onOther) strip(b, ax + ux * 0.6, az + uz * 0.6, bx - ux * 0.6, bz - uz * 0.6, nx, nz, -0.12, 0.12, 0.07, r.t === 1 ? PC.white : PC.yel);
          if (lod === 0 && r.t === 2 && (i & 1) === 0) strip(b, ax, az, bx, bz, nx, nz, -hw * 0.55, -hw * 0.25, 0.07, shade(RCOL[2], 0.85)); // surcos de terracería
        }
      }
    }
  }
}
function emitCrosswalks(cell, L) {
  for (const sx of [-24, 24]) for (const sz of [-24, 24]) {
    if (cellOf(sx) !== cell.cx || cellOf(sz) !== cell.cz) continue;
    for (const d of [[1, 0], [-1, 0], [0, 1], [0, -1]]) for (let k = -2; k <= 2; k++) {
      const px = sx + d[0] * 7.2 + (d[0] ? 0 : k * 1.5), pz = sz + d[1] * 7.2 + (d[1] ? 0 : k * 1.5);
      const hx = d[0] ? 0.35 : 0.55, hz = d[1] ? 0.35 : 0.55;
      const y = World.heightAt(px, pz) + 0.08;
      L[0].quad([px - hx, y, pz - hz], [px + hx, y, pz - hz], [px + hx, y, pz + hz], [px - hx, y, pz + hz], 0, 1, 0, PC.white, 0);
    }
  }
}

/* ---------- ayudas de props (cada una escribe en los 3 LOD según máscara: 1=LOD0, 2=LOD1, 4=LOD2) ---------- */
function bx(cell, L, x, y, z, w, h, d, c, o) {
  o = o || {}; const lm = o.l || 7;
  for (let i = 0; i < 3; i++) if (lm & (1 << i)) addBox(L[i], x, y, z, w, h, d, 0, c, o.em || 0);
  if (o.col) { addBoxCol(cell, x - w / 2, x + w / 2, z - d / 2, z + d / 2, y + h, y, !!o.sight); if (o.occ) addOcc(cell, x - w / 2, x + w / 2, z - d / 2, z + d / 2, y + h); }
  tY(cell, y + h);
}
function cy(cell, L, x, y, z, rb, rt, h, seg, c, o) {
  o = o || {}; const lm = o.l || 7;
  for (let i = 0; i < 3; i++) if (lm & (1 << i)) addCyl(L[i], x, y, z, rb, rt, h, i === 0 ? seg : Math.max(4, seg - 2 * i), c, o.em || 0, o.rot || 0);
  if (o.col) addCircleCol(cell, x, z, o.cr || Math.max(rb, rt), y + h, y);
  tY(cell, y + h);
}
function sp(cell, L, x, y, z, rx, ry, rz, c, o) {
  o = o || {}; const lm = o.l || 3;
  if (lm & 1) addSphere(L[0], x, y, z, rx, ry, rz, 7, 4, c, o.em || 0);
  if (lm & 2) addSphere(L[1], x, y, z, rx, ry, rz, 5, 3, c, o.em || 0);
  if (lm & 4) addSphere(L[2], x, y, z, rx, ry, rz, 4, 2, c, o.em || 0);
  tY(cell, y + ry);
}
function inCell(cell, x, z) { return cellOf(x) === cell.cx && cellOf(z) === cell.cz; }

/** Fachada con puerta y ventanas sobre la cara f (0:+z 1:-z 2:+x 3:-x). */
function facade(b, x, z, w, d, y, h, f, nWin, doorCol, em) {
  const horiz = f < 2, len = horiz ? w : d, off = (horiz ? d : w) / 2 + 0.03;
  const nx = f === 2 ? 1 : f === 3 ? -1 : 0, nz = f === 0 ? 1 : f === 1 ? -1 : 0, tx = horiz ? 1 : 0, tz = horiz ? 0 : 1;
  const put = (u, y0, ww, hh, col, e) => {
    const px = x + nx * off + tx * u, pz = z + nz * off + tz * u;
    if (horiz) addBox(b, px, y + y0, pz, ww, hh, 0.07, 0, col, e); else addBox(b, px, y + y0, pz, 0.07, hh, ww, 0, col, e);
  };
  put(0, 0, 1.0, 2.1, doorCol, 0);
  for (let k = 0; k < nWin; k++) {
    const u = (k - (nWin - 1) / 2) * (len / nWin);
    if (Math.abs(u) < 1.2) continue;
    put(u, 1.0, 1.1, 1.0, PC.win, em);
    if (h > 5) put(u, 3.6, 1.1, 1.0, PC.win, em);
  }
}
function pBuilding(cell, L, x, z, w, d, h, wall, roof, face, o) {
  o = o || {};
  const y = World.heightAt(x, z);
  bx(cell, L, x, y, z, w, h, d, wall, { col: 1, sight: 1, occ: h >= 4 });
  if (o.pyr) { cy(cell, L, x, y + h, z, Math.max(w, d) * 0.72, 0, 1.7, 4, roof, { l: 7, rot: Math.PI / 4 }); }
  else bx(cell, L, x, y + h, z, w + 0.3, 0.25, d + 0.3, roof, { l: 3 });
  facade(L[0], x, z, w, d, y, h, face, Math.max(2, Math.round((face < 2 ? w : d) / 3)), PC.door, 0.5);
  if (o.awn) { // toldo del comercio
    const nx = face === 2 ? 1 : face === 3 ? -1 : 0, nz = face === 0 ? 1 : face === 1 ? -1 : 0, hd = (face < 2 ? d : w) / 2 + 0.7;
    const ax = x + nx * hd, az = z + nz * hd, ac = o.awn;
    if (face < 2) { bx(cell, L, ax, y + 2.5, az, w - 0.6, 0.12, 1.4, ac, { l: 3 }); } else { bx(cell, L, ax, y + 2.5, az, 1.4, 0.12, d - 0.6, ac, { l: 3 }); }
  }
  tY(cell, y + h + 2);
}
function pTree(cell, L, x, z, s, kind, R) {
  const y = World.heightAt(x, z);
  if (kind === 0) { // fresno urbano
    const lf = shade(PC.leaf[(R() * 3) | 0], 0.9 + 0.2 * R());
    cy(cell, L, x, y, z, 0.2 * s, 0.14 * s, 2.3 * s, 6, PC.trunk, { l: 3, col: 1, cr: 0.4 * s });
    cy(cell, L, x, y, z, 1.2 * s, 0, 4.0 * s, 4, lf, { l: 4, rot: 0.8 });
    sp(cell, L, x, y + 2.1 * s, z, 1.5 * s, 1.25 * s, 1.5 * s, lf, { l: 3 });
  } else if (kind === 1) { // pino
    const pn = shade(PC.pine, 0.85 + 0.3 * R());
    cy(cell, L, x, y, z, 0.2 * s, 0.15 * s, 1.3 * s, 6, PC.trunk, { l: 3, col: 1, cr: 0.35 * s });
    cy(cell, L, x, y + 0.9 * s, z, 1.3 * s, 0, 1.9 * s, 7, pn, { l: 3 });
    cy(cell, L, x, y + 1.9 * s, z, 1.0 * s, 0, 1.7 * s, 7, shade(pn, 1.1), { l: 1 });
    cy(cell, L, x, y + 2.8 * s, z, 0.7 * s, 0, 1.5 * s, 7, shade(pn, 1.2), { l: 1 });
    cy(cell, L, x, y + 0.9 * s, z, 1.2 * s, 0, 4.4 * s, 4, pn, { l: 4, rot: 0.8 });
  } else { // encino
    const lf = shade(PC.oak, 0.85 + 0.3 * R());
    cy(cell, L, x, y, z, 0.28 * s, 0.2 * s, 2.0 * s, 6, PC.trunk, { l: 3, col: 1, cr: 0.45 * s });
    sp(cell, L, x, y + 2.3 * s, z, 1.9 * s, 1.3 * s, 1.9 * s, lf, { l: 7 });
  }
}
function pRock(cell, L, x, z, s, R) {
  const y = World.heightAt(x, z), c = shade(PC.rock, 0.85 + 0.3 * R());
  sp(cell, L, x, y + 0.3 * s, z, 0.9 * s, 0.6 * s, 0.8 * s, c, { l: 3 });
  cy(cell, L, x, y, z, 0.9 * s, 0.4 * s, 0.8 * s, 4, c, { l: 4, col: 1, cr: 0.75 * s });
}
function pBush(cell, L, x, z, s, R) {
  const y = World.heightAt(x, z);
  sp(cell, L, x, y + 0.3 * s, z, 0.8 * s, 0.55 * s, 0.8 * s, shade(PC.bush, 0.85 + 0.3 * R()), { l: 3 });
}
function pAgave(cell, L, x, z, R) {
  const y = World.heightAt(x, z), c = shade(PC.agave, 0.85 + 0.3 * R());
  cy(cell, L, x, y, z, 0.7, 0, 0.8, 6, c, { l: 7 });
  for (let k = 0; k < 4; k++) { const a = k * 1.57 + 0.4; cy(cell, L, x + Math.cos(a) * 0.38, y, z + Math.sin(a) * 0.38, 0.22, 0, 1.0, 4, c, { l: 1 }); }
}
function pPole(cell, L, x, z, lamp) {
  const y = World.heightAt(x, z);
  cy(cell, L, x, y, z, 0.1, 0.08, lamp ? 4.6 : 7, 6, PC.pole, { l: 3, col: 1 });
  if (lamp) { bx(cell, L, x, y + 4.5, z, 0.5, 0.2, 0.5, PC.warm, { l: 3, em: 0.5 }); }
  else { bx(cell, L, x, y + 6.4, z, 1.8, 0.1, 0.1, PC.pole, { l: 1 }); }
}
function pBench(cell, L, x, z, alongX) {
  const y = World.heightAt(x, z), w = alongX ? 1.6 : 0.5, d = alongX ? 0.5 : 1.6;
  bx(cell, L, x, y + 0.36, z, w, 0.1, d, PC.wood, { l: 3 });
  bx(cell, L, x, y, z, w * 0.9, 0.36, d * 0.8, PC.wood2, { l: 1, col: 1 });
}
function pCar(cell, L, x, z, alongX, col) {
  const y = World.heightAt(x, z), w = alongX ? 4.2 : 1.8, d = alongX ? 1.8 : 4.2;
  bx(cell, L, x, y + 0.3, z, w, 0.7, d, col, { l: 7, col: 1 });
  bx(cell, L, x, y + 1.0, z, alongX ? 2.2 : 1.6, 0.6, alongX ? 1.6 : 2.2, shade(col, 0.8), { l: 3 });
  bx(cell, L, x, y + 1.05, z, alongX ? 2.3 : 1.65, 0.45, alongX ? 1.62 : 2.3, PC.win, { l: 1 });
}
function pKiosko(cell, L, x, z) {
  const y = World.heightAt(x, z);
  cy(cell, L, x, y, z, 2.6, 2.4, 0.5, 8, PC.stone, { l: 7, col: 1 });
  for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; cy(cell, L, x + Math.cos(a) * 2.1, y + 0.5, z + Math.sin(a) * 2.1, 0.1, 0.1, 2.6, 5, PC.white, { l: 3 }); }
  cy(cell, L, x, y + 3.1, z, 3.0, 0.2, 1.6, 8, PC.red, { l: 7 });
}
function pPortal(cell, L, x, z, len) { // pórtico / arcada de la plaza
  const y = World.heightAt(x, z), n = Math.floor(len / 3) + 1;
  for (let k = 0; k < n; k++) {
    const px = x - len / 2 + k * (len / (n - 1));
    cy(cell, L, px, y, z, 0.3, 0.3, 3.2, 8, PC.stone, { l: k % 2 === 0 ? 7 : 1, col: 1 });
  }
  bx(cell, L, x, y + 3.2, z, len + 0.8, 0.5, 2.4, PC.walls[1], { l: 7 });
  bx(cell, L, x, y + 3.7, z, len + 1.2, 0.2, 2.8, PC.roofs[1], { l: 3 });
  for (let k = 0; k < n - 1; k++) { const px = x - len / 2 + (k + 0.5) * (len / (n - 1)); bx(cell, L, px, y + 2.4, z + 1.22, 1.6, 0.8, 0.05, PC.concD, { l: 1 }); }
}
function pTemplo(cell, L, x, z) { // templo con dos torres (silueta de plaza mayor)
  const y = World.heightAt(x, z);
  bx(cell, L, x, y, z, 12, 10, 18, PC.walls[7], { col: 1, sight: 1, occ: 1 });
  bx(cell, L, x, y + 10, z, 12.6, 0.4, 18.6, PC.roofs[0], { l: 3 });
  for (const s of [-1, 1]) {
    bx(cell, L, x + s * 4.2, y, z + 9.6, 3.4, 14, 3.4, PC.walls[7], { col: 1, sight: 1, occ: 1 });
    cy(cell, L, x + s * 4.2, y + 14, z + 9.6, 2.6, 0, 4.2, 4, PC.roofs[1], { l: 7, rot: Math.PI / 4 });
    bx(cell, L, x + s * 4.2, y + 10.5, z + 11.35, 1.0, 1.6, 0.06, PC.concD, { l: 1 });
  }
  bx(cell, L, x, y, z + 9.1, 3.0, 4.0, 0.2, PC.door, { l: 1 });
  addSphere(L[0], x, y + 10, z - 2, 4.2, 3.2, 4.2, 8, 4, PC.walls[0], 0); addSphere(L[1], x, y + 10, z - 2, 4.2, 3.2, 4.2, 6, 3, PC.walls[0], 0);
  tY(cell, y + 19);
}
function pBarrier(cell, L, x, z0, z1) { // pluma del retén
  const y = World.heightAt(x, (z0 + z1) / 2), len = z1 - z0, zc = (z0 + z1) / 2;
  bx(cell, L, x, y, z0 - 0.3, 0.5, 1.4, 0.5, PC.steel, { col: 1 });
  bx(cell, L, x, y, z1 + 0.3, 0.5, 1.4, 0.5, PC.steel, { col: 1 });
  bx(cell, L, x, y + 1.1, zc, 0.22, 0.25, len / 2, PC.red, { l: 7, col: 1 });
  bx(cell, L, x, y + 1.1, z0 + len * 0.75, 0.22, 0.25, len / 2, PC.white, { l: 3 });
}
function pSandbags(cell, L, x, z, len, alongX) {
  const y = World.heightAt(x, z);
  bx(cell, L, x, y, z, alongX ? len : 1.0, 0.55, alongX ? 1.0 : len, PC.sand, { col: 1 });
  bx(cell, L, x, y + 0.55, z, alongX ? len - 0.6 : 0.9, 0.5, alongX ? 0.9 : len - 0.6, shade(PC.sand, 0.9), { l: 3, col: 1 });
}
function pTower(cell, L, x, z) {
  const y = World.heightAt(x, z);
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) cy(cell, L, x + sx * 1.3, y, z + sz * 1.3, 0.14, 0.14, 6, 5, PC.pole, { l: 3, col: 1 });
  bx(cell, L, x, y + 6, z, 3.4, 0.2, 3.4, PC.wood2, { l: 3 });
  bx(cell, L, x, y + 6.2, z, 3.0, 2.0, 3.0, PC.olive, { l: 7, occ: 1, col: 0 });
  addOcc(cell, x - 1.5, x + 1.5, z - 1.5, z + 1.5, y + 8.2);
  bx(cell, L, x, y + 8.2, z, 3.6, 0.25, 3.6, PC.rust, { l: 3 });
  bx(cell, L, x, y + 6.8, z + 1.52, 2.0, 0.7, 0.06, PC.glass, { l: 1, em: 0.5 });
}
function pTent(cell, L, x, z) {
  const y = World.heightAt(x, z);
  bx(cell, L, x, y, z, 5, 2, 3.4, PC.olive, { col: 1 });
  cy(cell, L, x, y + 2, z, 3.2, 0, 1.4, 4, shade(PC.olive, 1.1), { l: 7, rot: Math.PI / 4 });
}
function pContainer(cell, L, x, z, alongX, col) {
  const y = World.heightAt(x, z);
  bx(cell, L, x, y, z, alongX ? 6 : 2.5, 2.6, alongX ? 2.5 : 6, col, { l: 7, col: 1, sight: 1 });
}
function pTruck(cell, L, x, z) {
  const y = World.heightAt(x, z);
  bx(cell, L, x, y + 0.5, z, 6, 2.2, 2.4, PC.olive, { l: 7, col: 1 });
  bx(cell, L, x + 3.4, y + 0.5, z, 1.8, 1.6, 2.2, shade(PC.olive, 1.15), { l: 7, col: 1 });
  bx(cell, L, x + 4.0, y + 1.3, z, 0.05, 0.6, 1.8, PC.glass, { l: 1 });
}
function pFlood(cell, L, x, z) {
  const y = World.heightAt(x, z);
  cy(cell, L, x, y, z, 0.12, 0.1, 6, 5, PC.pole, { l: 3, col: 1 });
  bx(cell, L, x, y + 6, z, 0.9, 0.4, 0.5, PC.warm, { l: 3, em: 0.5 });
}
function pCabin(cell, L, x, z) {
  const y = World.heightAt(x, z);
  bx(cell, L, x, y, z, 7, 3.2, 6, PC.wood, { col: 1, sight: 1, occ: 0 });
  cy(cell, L, x, y + 3.2, z, 5.6, 0, 2.2, 4, PC.roofs[1], { l: 7, rot: Math.PI / 4 });
  bx(cell, L, x + 2, y + 3.2, z - 1.2, 0.6, 2.8, 0.6, PC.concD, { l: 3 });
  facade(L[0], x, z, 7, 6, y, 3.2, 3, 2, PC.door, 0.5);
  addOcc(cell, x - 3.5, x + 3.5, z - 3, z + 3, y + 4.2);
}
function pMirador(cell, L, x, z) {
  const y = World.heightAt(x, z);
  bx(cell, L, x, y, z, 9, 0.35, 9, PC.wood, { col: 1 });                       // plataforma caminable
  for (const s of [-1, 1]) {
    bx(cell, L, x + s * 4.4, y + 0.35, z, 0.15, 1.0, 9, PC.wood2, { l: 3, col: 1 });
    bx(cell, L, x, y + 0.35, z - 4.4, 9, 1.0, 0.15, PC.wood2, { l: 3, col: s > 0 ? 1 : 0 });
  }
  bx(cell, L, x - 1.5, y + 0.35, z - 3.6, 0.5, 1.5, 0.5, PC.steel, { l: 1, col: 1 }); // telescopio
  pBench(cell, L, x + 2, z + 2.6, true);
  cy(cell, L, x - 3.6, y + 0.35, z + 3.6, 0.12, 0.12, 3.6, 5, PC.pole, { l: 3 });
}
function pGantry(cell, L, x, z) { // pórtico de carretera con tableros verdes
  const y = World.heightAt(x, z);
  for (const s of [-1, 1]) cy(cell, L, x + s * 7.5, y, z, 0.28, 0.28, 6.2, 6, PC.steel, { l: 7, col: 1 });
  bx(cell, L, x, y + 6.0, z, 16.6, 0.8, 0.5, PC.steel, { l: 7 });
  for (const s of [-1, 1]) { bx(cell, L, x + s * 3.6, y + 4.6, z + 0.3, 5.2, 1.4, 0.08, PC.green, { l: 7 }); bx(cell, L, x + s * 3.6, y + 5.1, z + 0.36, 3.8, 0.2, 0.04, PC.white, { l: 1 }); }
}
function pSign(cell, L, x, z) {
  const y = World.heightAt(x, z);
  cy(cell, L, x - 1.3, y, z, 0.1, 0.1, 2.6, 5, PC.pole, { l: 3 });
  cy(cell, L, x + 1.3, y, z, 0.1, 0.1, 2.6, 5, PC.pole, { l: 3 });
  bx(cell, L, x, y + 2.0, z, 3.4, 1.4, 0.1, PC.green, { l: 7, col: 1 });
  bx(cell, L, x, y + 2.8, z + 0.06, 2.6, 0.2, 0.04, PC.white, { l: 1 });
}
function pWallSeg(cell, L, ax, az, bx2, bz2, th, h) { // muro alto (oclusor) recortado a la celda
  const x0 = cell.cx * CELL - HALF, x1 = x0 + CELL, z0 = cell.cz * CELL - HALF, z1 = z0 + CELL;
  const lx0 = Math.max(Math.min(ax, bx2) - th / 2, x0), lx1 = Math.min(Math.max(ax, bx2) + th / 2, x1);
  const lz0 = Math.max(Math.min(az, bz2) - th / 2, z0), lz1 = Math.min(Math.max(az, bz2) + th / 2, z1);
  if (lx1 - lx0 < 0.1 || lz1 - lz0 < 0.1) return;
  const cx = (lx0 + lx1) / 2, cz = (lz0 + lz1) / 2, y = World.heightAt(cx, cz);
  bx(cell, L, cx, y, cz, lx1 - lx0, h, lz1 - lz0, PC.conc, { col: 1, sight: 1, occ: 1 });
  bx(cell, L, cx, y + h, cz, lx1 - lx0 + 0.2, 0.2, lz1 - lz0 + 0.2, PC.concD, { l: 3 });
}
function pBeacon(cell, L, x, z, col) { // baliza luminosa de puntos interactivos
  const y = World.heightAt(x, z);
  cy(cell, L, x, y, z, 0.05, 0.05, 5, 5, col, { l: 7, em: 1 });
  sp(cell, L, x, y + 5.1, z, 0.2, 0.28, 0.2, col, { l: 3, em: 1 });
}
function pTravelPost(cell, L, x, z) {
  const y = World.heightAt(x, z);
  cy(cell, L, x, y, z, 0.3, 0.22, 0.4, 8, PC.pole, { l: 7, col: 1 });
  cy(cell, L, x, y + 0.4, z, 0.09, 0.08, 2.2, 6, PC.steel, { l: 3 });
  bx(cell, L, x, y + 2.2, z, 1.1, 0.5, 0.12, PC.green, { l: 7 });
  pBeacon(cell, L, x + 0.9, z, rgb(0x59d8c8));
}
const WALLS = [[92, 7, 132, 7], [92, 36, 106, 36], [118, 36, 132, 36], [92, 7, 92, 19], [92, 29, 92, 36], [132, 7, 132, 19], [132, 29, 132, 36]];
function genWalls(cell, L) {
  for (const w of WALLS) pWallSeg(cell, L, w[0], w[1], w[2], w[3], 0.8, 4.5);
}

/* ---------- colocación de elementos naturales ---------- */
function slopeAt(x, z) { return Math.max(Math.abs(World.heightAt(x + 1.5, z) - World.heightAt(x - 1.5, z)), Math.abs(World.heightAt(x, z + 1.5) - World.heightAt(x, z - 1.5))) / 3; }
function blockedPlace(x, z, r) {
  if (roadDist(x, z) < r + 1.2) return true;
  for (let i = 0; i < KEEPS.length; i++) { const k = KEEPS[i]; if (Math.hypot(x - k.x, z - k.z) < k.r + r) return true; }
  if (x > 86 && x < 134 && z > 2 && z < 56) return true;
  for (let i = 0; i < PADS.length; i++) if (Math.hypot(x - PADS[i].x, z - PADS[i].z) < PADS[i].r + 5 + r) return true;
  return slopeAt(x, z) > 0.8;
}
function scatter(cell, L, R) {
  const ox = cell.cx * CELL, oz = cell.cz * CELL, sid = sectorAt(ox, oz), edge = Math.max(Math.abs(ox), Math.abs(oz));
  let nTree = 4, nRock = 2, nBush = 2, pine = 0.3;
  if (sid === 2) { nTree = 13; nRock = 2; nBush = 4; pine = 0.65; }
  else if (sid === 3) { nTree = 7; nRock = 5; nBush = 3; pine = 0.9; }
  else if (sid === 1) { nTree = 3; nRock = 2; nBush = 2; pine = 0.2; }
  else if (sid === 4) { nTree = 3; nRock = 2; nBush = 3; pine = 0.2; }
  if (edge > 130) { nTree += 5; nRock += 3; pine = 0.9; }
  const spot = r => {
    for (let t = 0; t < 6; t++) {
      const x = ox - HALF + 1.5 + R() * (CELL - 3), z = oz - HALF + 1.5 + R() * (CELL - 3);
      if (!blockedPlace(x, z, r)) return [x, z];
    }
    return null;
  };
  for (let i = 0; i < nTree; i++) { const p = spot(1.1); if (p) pTree(cell, L, p[0], p[1], 0.8 + R() * 0.7, R() < pine ? 1 : 2, R); }
  for (let i = 0; i < nRock; i++) { const p = spot(1.0); if (p) pRock(cell, L, p[0], p[1], 0.7 + R() * 1.1, R); }
  for (let i = 0; i < nBush; i++) { const p = spot(0.8); if (p) pBush(cell, L, p[0], p[1], 0.8 + R() * 0.5, R); }
  // campos de agave (paisaje de Jalisco) junto al camino al bosque
  for (let gx = 38; gx <= 70; gx += 4) for (let gz = 72; gz <= 100; gz += 4) {
    if (inCell(cell, gx, gz) && !blockedPlace(gx, gz, 0.4) && roadDist(gx, gz) > 3) pAgave(cell, L, gx + (R() - 0.5), gz + (R() - 0.5), R);
  }
}

/* ---------- Zapopan Centro y Campus ---------- */
function shop(cell, L, x, z, alongX, len, dep, face, R) {
  const h = R() < 0.4 ? 6.4 : 3.5, w = alongX ? len : dep, d = alongX ? dep : len;
  pBuilding(cell, L, x, z, w, d, h, PC.walls[(R() * PC.walls.length) | 0], PC.roofs[(R() * 4) | 0], face, { awn: PC.awn[(R() * PC.awn.length) | 0] });
}
function houses(cell, L, R, ox, oz, n) {
  const spots = [[-6.5, -6.5, 1], [6.5, -6.5, 1], [-6.5, 6.5, 0], [6.5, 6.5, 0]];
  for (let k = 0; k < n; k++) {
    const s = spots[k], w = 7 + R() * 2, d = 6 + R() * 2;
    pBuilding(cell, L, ox + s[0], oz + s[1], w, d, R() < 0.35 ? 6.4 : 3.4, PC.walls[(R() * PC.walls.length) | 0], PC.roofs[(R() * 4) | 0], s[1] < 0 ? 0 : 1, { pyr: R() < 0.5 });
  }
}
function genTown(cell, L, R) {
  const cx = cell.cx, cz = cell.cz, ox = cx * CELL, oz = cz * CELL;
  const ns = Math.abs(cx) === 1, ew = Math.abs(cz) === 1;
  emitCrosswalks(cell, L);
  if (cx === 0 && cz === 0) { // plaza
    pKiosko(cell, L, 0, 0);
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) pTree(cell, L, sx * 7, sz * 7, 1.1, 0, R);
    pBench(cell, L, 5.5, 0.5, false); pBench(cell, L, -5.5, 0.5, false); pBench(cell, L, 0.5, -6, true);
    pPortal(cell, L, 0, 8.0, 18);
    return;
  }
  if (!ns && !ew) {
    if (cx === 0 && cz === -2) { pTemplo(cell, L, 0, -50); pTree(cell, L, -9, -38, 1, 0, R); pTree(cell, L, 9, -38, 1, 0, R); return; }
    if (cx === 2 && cz === 0) { // campus: edificio de aulas y biblioteca
      pBuilding(cell, L, 50, 2, 16, 9, 6.4, PC.walls[3], PC.roofs[3], 3, {});
      pBuilding(cell, L, 52, -11, 12, 6, 4.4, PC.walls[0], PC.roofs[2], 3, {});
      for (const t of [[36, 8], [36, -6], [58, 12], [46, 12], [60, -6]]) pTree(cell, L, t[0], t[1], 1, 0, R);
      pBench(cell, L, 38, 5, false); pBench(cell, L, 38, -2, false);
      return;
    }
    if (cx === 2 && cz === -2) { // campus: cancha y áreas verdes
      const y = World.heightAt(48, -48);
      L[0].quad([41, y + 0.06, -52], [55, y + 0.06, -52], [55, y + 0.06, -44], [41, y + 0.06, -44], 0, 1, 0, rgb(0x2e6f9e), 0);
      L[1].quad([41, y + 0.06, -52], [55, y + 0.06, -52], [55, y + 0.06, -44], [41, y + 0.06, -44], 0, 1, 0, rgb(0x2e6f9e), 0);
      for (const s of [-1, 1]) { cy(cell, L, 48 + s * 7.5, y, -48, 0.08, 0.08, 3.0, 5, PC.pole, { l: 3, col: 1 }); bx(cell, L, 48 + s * 7.3, y + 3.0, -48, 0.1, 0.9, 1.2, PC.white, { l: 3 }); }
      for (const t of [[40, -36], [56, -38], [44, -58], [54, -58]]) pTree(cell, L, t[0], t[1], 1, 0, R);
      return;
    }
    if (cx === 0 && cz === 2) { // mercado
      pBuilding(cell, L, -6, 50, 9, 6, 3.6, PC.walls[4], PC.roofs[0], 1, { awn: PC.awn[0] });
      pBuilding(cell, L, 6, 50, 9, 6, 3.6, PC.walls[5], PC.roofs[1], 1, { awn: PC.awn[2] });
      pTree(cell, L, 0, 58, 1, 0, R); pCar(cell, L, 0, 44, true, rgb(0x2e86de));
      return;
    }
    houses(cell, L, R, ox, oz, 4);
    return;
  }
  const intersection = ns && ew;
  if (intersection) { pPole(cell, L, ox + 6.7, oz + 6.7, true); pPole(cell, L, ox - 6.7, oz - 6.7, true); return; }
  if (ns) {
    for (const s of [-1, 1]) {
      for (const k of [-1, 1]) shop(cell, L, ox + s * 10.9, oz + k * 6, false, 9, 5.4, s > 0 ? 3 : 2, R);
      pPole(cell, L, ox + s * 6.9, oz - s * 6, s < 0); pTree(cell, L, ox + s * 6.9, oz + s * 6, 1, 0, R);
    }
    if (R() < 0.5) pCar(cell, L, ox + 3, oz + 2, false, PC.awn[(R() * 5) | 0]);
  } else {
    for (const s of [-1, 1]) {
      for (const k of [-1, 1]) shop(cell, L, ox + k * 6, oz + s * 10.9, true, 9, 5.4, s > 0 ? 1 : 0, R);
      pPole(cell, L, ox - s * 6, oz + s * 6.9, s < 0); pTree(cell, L, ox + s * 6, oz + s * 6.9, 1, 0, R);
    }
    if (R() < 0.5) pCar(cell, L, ox + 2, oz + 3, true, PC.awn[(R() * 5) | 0]);
  }
}

/* ---------- retén, sierra, carretera, puertas y postes de viaje ---------- */
function genStructures(cell, L, R) {
  if (inCell(cell, 104, 22)) { pBarrier(cell, L, 104, 19.4, 24.4); pSandbags(cell, L, 104, 17, 5, true); pSandbags(cell, L, 104, 31, 5, true); }
  if (inCell(cell, 112, 26)) pBarrier(cell, L, 112, 23.6, 28.6);
  if (inCell(cell, 120, 22)) { pBarrier(cell, L, 120, 19.4, 24.4); pSandbags(cell, L, 120, 17, 5, true); pSandbags(cell, L, 120, 31, 5, true); }
  if (inCell(cell, 108, 12)) pTower(cell, L, 108, 12);
  if (inCell(cell, 112, 46)) {
    const y = World.heightAt(112, 46);
    pBuilding(cell, L, 112, 46, 9, 7, 4.2, PC.olive, PC.concD, 1, {});
    pSandbags(cell, L, 108, 49.8, 3, true); pSandbags(cell, L, 116, 49.8, 3, true);
    tY(cell, y + 6);
  }
  if (inCell(cell, 96, 44)) pTent(cell, L, 96, 44);
  if (inCell(cell, 128, 44)) pTent(cell, L, 128, 44);
  if (inCell(cell, 98, 11)) { pContainer(cell, L, 98, 11, true, PC.rust); }
  if (inCell(cell, 98, 14.5)) { pContainer(cell, L, 98, 14.5, true, PC.steel); }
  if (inCell(cell, 126, 12)) pTruck(cell, L, 123, 12);
  for (const f of [[94, 10], [130, 10], [94, 34], [130, 34]]) if (inCell(cell, f[0], f[1])) pFlood(cell, L, f[0], f[1]);
  if (inCell(cell, -106, 100)) pCabin(cell, L, -106, 100);
  if (inCell(cell, -152, 126)) pMirador(cell, L, -152, 126);
  if (inCell(cell, 24, -150)) pGantry(cell, L, 24, -150);
  if (inCell(cell, 38, -110)) pSign(cell, L, 38, -110);
  if (inCell(cell, 10, -172)) pSign(cell, L, 10, -172);
  if (inCell(cell, 20, -120)) { pCar(cell, L, 21.5, -120, false, rgb(0xc0392b)); }
  if (inCell(cell, 29, -135)) { pTruck(cell, L, 28, -135); }
  for (const d of DOORS) if (inCell(cell, d.x, d.z)) pBeacon(cell, L, d.x - 1.2, d.z - 0.6, rgb(0xffc857));
  for (const t of TPOSTS) if (inCell(cell, t.x, t.z)) pTravelPost(cell, L, t.x, t.z);
}

function genCell(cell, L) {
  const R = rng((Math.imul(cell.cx, 73856093) ^ Math.imul(cell.cz, 19349663) ^ 0x51ed270b) >>> 0);
  emitTerrain(cell, L);
  emitRoads(cell, L);
  genWalls(cell, L);
  if (Math.abs(cell.cx) <= 2 && Math.abs(cell.cz) <= 2) genTown(cell, L, R); else scatter(cell, L, R);
  genStructures(cell, L, R);
}

/* =====================================================================
   Interiores (aula del campus, caseta del retén, cabaña serrana)
   ib(u, y, v, ancho, alto, fondo, color, sólido, emisivo): u,v = centro en la sala
   ===================================================================== */
const INT_DEFS = [
  { id: 'aula', name: 'Aula · Campus Zapopan', ox: 1000, oz: 1000, w: 12, d: 9, h: 3.2, wall: rgb(0xe6e0d0), floor: rgb(0x8a8f96), ceil: rgb(0xf0f0ea),
    pick: [['med', 1.5, 1.4, 'im1'], ['decoy', 10.5, 1.4, 'id1']], zspots: [[3, 2.8], [9, 3.4]],
    build(ib) {
      ib(6, 1.0, 0.22, 5, 1.3, 0.06, rgb(0x1f5a3a), false);          // pizarrón
      ib(6, 0, 1.7, 2.2, 0.8, 0.8, PC.wood, true);                     // escritorio
      for (let r = 0; r < 3; r++) for (let c = 0; c < 4; c++) { ib(2.2 + c * 2.6, 0, 3.8 + r * 1.5, 1.1, 0.75, 0.6, PC.wood2, true); ib(2.2 + c * 2.6, 0, 4.45 + r * 1.5, 0.45, 0.45, 0.45, PC.steel, false); }
      ib(0.05, 1.0, 3, 0.05, 1.2, 1.6, PC.glass, false, 1); ib(0.05, 1.0, 6, 0.05, 1.2, 1.6, PC.glass, false, 1);
      ib(3, 3.15, 4.5, 1.6, 0.05, 0.4, PC.white, false, 1); ib(9, 3.15, 4.5, 1.6, 0.05, 0.4, PC.white, false, 1);
      ib(11.2, 0, 1.2, 1.0, 1.9, 0.5, PC.wood, true);
    } },
  { id: 'bunker', name: 'Caseta del retén', ox: 1100, oz: 1000, w: 9, d: 7, h: 3.0, wall: rgb(0x6c7358), floor: rgb(0x55554f), ceil: rgb(0x70705f),
    pick: [['ammo', 6.5, 5.2, 'ip1'], ['ammo', 2.5, 5.0, 'ip2'], ['adr', 7.5, 3.6, 'ia1'], ['med', 4, 1.0, 'im2']], zspots: [[3, 4], [6, 2.5]],
    build(ib) {
      ib(1.1, 0, 1.2, 2.0, 1.1, 1.0, PC.olive, true); ib(1.1, 0, 2.6, 2.0, 1.1, 1.0, PC.olive, true);
      ib(5.5, 0, 3.2, 2.2, 0.8, 1.0, PC.wood, true); ib(5.5, 0.8, 3.2, 0.5, 0.3, 0.3, PC.steel, false, 1);
      ib(7.8, 0, 1.0, 1, 0.9, 1, PC.wood2, true); ib(7.8, 0.9, 1.0, 0.8, 0.7, 0.8, PC.wood2, true); ib(7.8, 0, 2.1, 1, 0.9, 1, PC.wood2, true);
      ib(4.5, 2.95, 3.5, 1.8, 0.05, 0.4, PC.warm, false, 1);
    } },
  { id: 'cabana', name: 'Cabaña · Sierra de Jalisco', ox: 1200, oz: 1000, w: 9, d: 7, h: 2.8, wall: rgb(0x7d5a3a), floor: rgb(0x5e4630), ceil: rgb(0x6a4a30),
    pick: [['med', 6, 5.5, 'ic1'], ['decoy', 2, 5.5, 'ic2']], zspots: [[4, 2]],
    build(ib) {
      ib(1.2, 0, 1.3, 2.0, 0.5, 1.0, PC.red, true);
      ib(5.5, 0, 3.0, 1.6, 0.75, 1.0, PC.wood, true); ib(4.3, 0, 3.0, 0.45, 0.45, 0.45, PC.wood2, false); ib(6.7, 0, 3.0, 0.45, 0.45, 0.45, PC.wood2, false);
      ib(8.0, 0, 0.8, 1.0, 1.0, 0.8, PC.steel, true); ib(8.0, 1.0, 0.8, 0.4, 1.8, 0.4, PC.steel, false); ib(8.0, 0.3, 1.22, 0.5, 0.3, 0.05, rgb(0xff8a3a), false, 1);
      ib(0.05, 1.0, 3.5, 0.05, 1.1, 1.4, PC.glass, false, 1);
      ib(4.5, 2.75, 3.5, 1.2, 0.05, 0.4, PC.warm, false, 1);
    } }
];
INT_DEFS.forEach(d => d.pick.forEach(p => PICKUPS.push({ id: p[3], t: p[0], x: d.ox + p[1], z: d.oz + p[2], zone: INT_DEFS.indexOf(d) })));
