'use strict';
/* =====================================================================
   engine.js — matemáticas, constructor de mallas, renderer WebGL1, entorno
   ===================================================================== */

/* ---------- color ---------- */
function rgb(h) { return [((h >> 16) & 255) / 255, ((h >> 8) & 255) / 255, (h & 255) / 255]; }
function shade(c, k) { return [Math.min(1, c[0] * k), Math.min(1, c[1] * k), Math.min(1, c[2] * k)]; }
function mixc(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }

/* ---------- matrices 4x4 (column-major) ---------- */
const M4 = {
  create() { const o = new Float32Array(16); o[0] = o[5] = o[10] = o[15] = 1; return o; },
  identity(o) { o.fill(0); o[0] = o[5] = o[10] = o[15] = 1; return o; },
  perspective(o, fovy, aspect, near, far) {
    const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
    o.fill(0);
    o[0] = f / aspect; o[5] = f; o[10] = (far + near) * nf; o[11] = -1; o[14] = 2 * far * near * nf;
    return o;
  },
  lookAt(o, ex, ey, ez, tx, ty, tz) { // up = (0,1,0)
    let zx = ex - tx, zy = ey - ty, zz = ez - tz;
    let l = Math.hypot(zx, zy, zz) || 1; zx /= l; zy /= l; zz /= l;
    let xx = zz, xz = -zx; l = Math.hypot(xx, xz) || 1; xx /= l; xz /= l;
    const yx = zy * xz, yy = zz * xx - zx * xz, yz = -zy * xx;
    o[0] = xx; o[1] = yx; o[2] = zx; o[3] = 0;
    o[4] = 0; o[5] = yy; o[6] = zy; o[7] = 0;
    o[8] = xz; o[9] = yz; o[10] = zz; o[11] = 0;
    o[12] = -(xx * ex + xz * ez); o[13] = -(yx * ex + yy * ey + yz * ez); o[14] = -(zx * ex + zy * ey + zz * ez); o[15] = 1;
    return o;
  },
  mul(o, a, b) {
    const t = M4._t;
    for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
      t[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
    }
    o.set(t); return o;
  }
};
M4._t = new Float32Array(16);

/* ---------- pila de transformaciones (sin asignaciones por frame) ---------- */
class MStack {
  constructor() { this.s = []; for (let i = 0; i < 24; i++) this.s.push(new Float32Array(16)); this.i = 0; M4.identity(this.s[0]); }
  reset() { this.i = 0; M4.identity(this.s[0]); return this; }
  m() { return this.s[this.i]; }
  push() { this.s[this.i + 1].set(this.s[this.i]); this.i++; }
  pop() { this.i--; }
  translate(x, y, z) {
    const m = this.s[this.i];
    m[12] += m[0] * x + m[4] * y + m[8] * z; m[13] += m[1] * x + m[5] * y + m[9] * z; m[14] += m[2] * x + m[6] * y + m[10] * z;
  }
  scale(k) { const m = this.s[this.i]; for (let i = 0; i < 12; i++) m[i] *= k; }
  rotX(a) {
    const m = this.s[this.i], c = Math.cos(a), s = Math.sin(a);
    const a4 = m[4], a5 = m[5], a6 = m[6], a8 = m[8], a9 = m[9], a10 = m[10];
    m[4] = a4 * c + a8 * s; m[5] = a5 * c + a9 * s; m[6] = a6 * c + a10 * s;
    m[8] = -a4 * s + a8 * c; m[9] = -a5 * s + a9 * c; m[10] = -a6 * s + a10 * c;
  }
  rotY(a) {
    const m = this.s[this.i], c = Math.cos(a), s = Math.sin(a);
    const a0 = m[0], a1 = m[1], a2 = m[2], a8 = m[8], a9 = m[9], a10 = m[10];
    m[0] = a0 * c - a8 * s; m[1] = a1 * c - a9 * s; m[2] = a2 * c - a10 * s;
    m[8] = a0 * s + a8 * c; m[9] = a1 * s + a9 * c; m[10] = a2 * s + a10 * c;
  }
  rotZ(a) {
    const m = this.s[this.i], c = Math.cos(a), s = Math.sin(a);
    const a0 = m[0], a1 = m[1], a2 = m[2], a4 = m[4], a5 = m[5], a6 = m[6];
    m[0] = a0 * c + a4 * s; m[1] = a1 * c + a5 * s; m[2] = a2 * c + a6 * s;
    m[4] = -a0 * s + a4 * c; m[5] = -a1 * s + a5 * c; m[6] = -a2 * s + a6 * c;
  }
}

/* ---------- constructor de mallas (v: pos3 nor3 col3 emisivo1 = 10 floats) ---------- */
class MeshBuilder {
  constructor() { this.a = new Float32Array(10 * 24000); this.n = 0; }
  reset() { this.n = 0; }
  vert(x, y, z, nx, ny, nz, c, e) {
    if ((this.n + 1) * 10 > this.a.length) { const b = new Float32Array(this.a.length * 2); b.set(this.a); this.a = b; }
    const a = this.a, o = this.n * 10;
    a[o] = x; a[o + 1] = y; a[o + 2] = z; a[o + 3] = nx; a[o + 4] = ny; a[o + 5] = nz;
    a[o + 6] = c[0]; a[o + 7] = c[1]; a[o + 8] = c[2]; a[o + 9] = e;
    this.n++;
  }
  tri(p, q, r, nx, ny, nz, c, e) {
    this.vert(p[0], p[1], p[2], nx, ny, nz, c, e);
    this.vert(q[0], q[1], q[2], nx, ny, nz, c, e);
    this.vert(r[0], r[1], r[2], nx, ny, nz, c, e);
  }
  quad(p, q, r, s, nx, ny, nz, c, e) { this.tri(p, q, r, nx, ny, nz, c, e); this.tri(p, r, s, nx, ny, nz, c, e); }
  data() { return this.a.subarray(0, this.n * 10); }
}

/* Emisivo e: 0 = ninguno · 0.5 = solo de noche · 1 = siempre */

/** Caja: centro de la base en (cx,cy,cz), tamaño w×h×d, giro rot sobre Y. */
function addBox(b, cx, cy, cz, w, h, d, rot, c, e) {
  const cs = Math.cos(rot), sn = Math.sin(rot), hx = w / 2, hz = d / 2;
  const P = (x, y, z) => [cx + x * cs + z * sn, cy + y, cz - x * sn + z * cs];
  const N = (x, z) => [x * cs + z * sn, 0, -x * sn + z * cs];
  const p000 = P(-hx, 0, -hz), p100 = P(hx, 0, -hz), p110 = P(hx, h, -hz), p010 = P(-hx, h, -hz);
  const p001 = P(-hx, 0, hz), p101 = P(hx, 0, hz), p111 = P(hx, h, hz), p011 = P(-hx, h, hz);
  let n = N(0, 1); b.quad(p001, p101, p111, p011, n[0], n[1], n[2], c, e);
  n = N(0, -1); b.quad(p100, p000, p010, p110, n[0], n[1], n[2], c, e);
  n = N(1, 0); b.quad(p101, p100, p110, p111, n[0], n[1], n[2], c, e);
  n = N(-1, 0); b.quad(p000, p001, p011, p010, n[0], n[1], n[2], c, e);
  b.quad(p011, p111, p110, p010, 0, 1, 0, c, e);
  b.quad(p000, p100, p101, p001, 0, -1, 0, c, e);
}

/** Cilindro / cono truncado: base en cy, radio rb abajo y rt arriba, altura h. */
function addCyl(b, cx, cy, cz, rb, rt, h, seg, c, e, rot) {
  rot = rot || 0;
  const slope = (rb - rt) / h;
  for (let i = 0; i < seg; i++) {
    const a0 = rot + i * 2 * Math.PI / seg, a1 = rot + (i + 1) * 2 * Math.PI / seg, am = (a0 + a1) / 2;
    const c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
    let nx = Math.cos(am), ny = slope, nz = Math.sin(am);
    const l = Math.hypot(nx, ny, nz); nx /= l; ny /= l; nz /= l;
    const p0 = [cx + c0 * rb, cy, cz + s0 * rb], p1 = [cx + c1 * rb, cy, cz + s1 * rb];
    const p2 = [cx + c1 * rt, cy + h, cz + s1 * rt], p3 = [cx + c0 * rt, cy + h, cz + s0 * rt];
    b.quad(p0, p1, p2, p3, nx, ny, nz, c, e);
    if (rt > 0) b.tri([cx, cy + h, cz], p3, p2, 0, 1, 0, c, e);
  }
}

/** Elipsoide (o hemisferio superior si hemi) con normales planas (low-poly). */
function addSphere(b, cx, cy, cz, rx, ry, rz, seg, rings, c, e, hemi) {
  const th1 = hemi ? Math.PI / 2 : Math.PI;
  const pt = (t, f) => [cx + rx * Math.sin(t) * Math.cos(f), cy + ry * Math.cos(t), cz + rz * Math.sin(t) * Math.sin(f)];
  for (let i = 0; i < rings; i++) {
    const t0 = i * th1 / rings, t1 = (i + 1) * th1 / rings;
    for (let j = 0; j < seg; j++) {
      const f0 = j * 2 * Math.PI / seg, f1 = (j + 1) * 2 * Math.PI / seg;
      const a = pt(t0, f0), q = pt(t0, f1), r = pt(t1, f1), d = pt(t1, f0);
      const mx = (a[0] + q[0] + r[0] + d[0]) / 4 - cx, my = (a[1] + q[1] + r[1] + d[1]) / 4 - cy, mz = (a[2] + q[2] + r[2] + d[2]) / 4 - cz;
      let nx = mx / (rx * rx), ny = my / (ry * ry), nz = mz / (rz * rz);
      const l = Math.hypot(nx, ny, nz) || 1;
      b.quad(a, q, r, d, nx / l, ny / l, nz / l, c, e);
    }
  }
}

/* ---------- malla en GPU (buffer reutilizable) ---------- */
class Mesh {
  constructor(gl) { this.gl = gl; this.buf = gl.createBuffer(); this.n = 0; }
  upload(data, count) {
    const gl = this.gl;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buf);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.DYNAMIC_DRAW);
    this.n = count;
  }
}

/* ---------- renderer WebGL1 ---------- */
const VS = `
attribute vec3 aPos; attribute vec3 aNor; attribute vec4 aCol;
uniform mat4 uVP; uniform mat4 uModel; uniform mat3 uNorm;
varying vec3 vN; varying vec4 vC; varying float vD;
void main(){
  gl_Position = uVP * (uModel * vec4(aPos, 1.0));
  vN = uNorm * aNor; vC = aCol; vD = gl_Position.w;
}`;
const FS = `
precision mediump float;
varying vec3 vN; varying vec4 vC; varying float vD;
uniform vec3 uSun; uniform vec3 uSunCol; uniform vec3 uAmbTop; uniform vec3 uAmbBot;
uniform vec3 uFog; uniform float uFogN; uniform float uFogF; uniform float uNight;
uniform vec3 uTint; uniform float uAlpha;
void main(){
  vec3 n = normalize(vN);
  float d = max(dot(n, uSun), 0.0);
  vec3 amb = mix(uAmbBot, uAmbTop, n.y * 0.5 + 0.5);
  vec3 base = vC.rgb * uTint;
  vec3 lit = base * (amb + uSunCol * d);
  float hi = step(0.75, vC.a);
  float e = hi + step(0.25, vC.a) * (1.0 - hi) * uNight;
  vec3 col = mix(lit, base * 1.3, e);
  float f = clamp((vD - uFogN) / (uFogF - uFogN), 0.0, 1.0);
  gl_FragColor = vec4(mix(col, uFog, f), uAlpha);
}`;

class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    const gl = canvas.getContext('webgl', { antialias: false, alpha: false, depth: true, stencil: false, powerPreference: 'high-performance' })
      || canvas.getContext('experimental-webgl');
    if (!gl) throw new Error('WebGL no disponible');
    this.gl = gl;
    const p = gl.createProgram();
    gl.attachShader(p, this._sh(gl.VERTEX_SHADER, VS));
    gl.attachShader(p, this._sh(gl.FRAGMENT_SHADER, FS));
    gl.bindAttribLocation(p, 0, 'aPos'); gl.bindAttribLocation(p, 1, 'aNor'); gl.bindAttribLocation(p, 2, 'aCol');
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('Link: ' + gl.getProgramInfoLog(p));
    gl.useProgram(p);
    this.u = {};
    ['uVP', 'uModel', 'uNorm', 'uTint', 'uAlpha', 'uSun', 'uSunCol', 'uAmbTop', 'uAmbBot', 'uFog', 'uFogN', 'uFogF', 'uNight']
      .forEach(n => { this.u[n] = gl.getUniformLocation(p, n); });
    gl.enableVertexAttribArray(0); gl.enableVertexAttribArray(1); gl.enableVertexAttribArray(2);
    gl.enable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE);
    this._m = new Float32Array(16); this._n = new Float32Array(9);
    this._I4 = M4.create(); this._I3 = new Float32Array([1, 0, 0, 0, 1, 0, 0, 0, 1]);
    this.aspect = 1;
  }
  _sh(type, src) {
    const gl = this.gl, s = gl.createShader(type);
    gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('Shader: ' + gl.getShaderInfoLog(s));
    return s;
  }
  resize(scale) {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(2, Math.floor(window.innerWidth * dpr * scale));
    const h = Math.max(2, Math.floor(window.innerHeight * dpr * scale));
    if (this.canvas.width !== w || this.canvas.height !== h) { this.canvas.width = w; this.canvas.height = h; }
    this.gl.viewport(0, 0, w, h);
    this.aspect = w / h;
  }
  makeMesh(builder) { const m = new Mesh(this.gl); m.upload(builder.data(), builder.n); return m; }
  newMesh() { return new Mesh(this.gl); }
  begin(env) {
    const gl = this.gl, u = this.u;
    gl.clearColor(env.sky[0], env.sky[1], env.sky[2], 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.uniform3fv(u.uSun, env.sunN); gl.uniform3fv(u.uSunCol, env.sunCol);
    gl.uniform3fv(u.uAmbTop, env.ambT); gl.uniform3fv(u.uAmbBot, env.ambB);
    gl.uniform3fv(u.uFog, env.sky); gl.uniform1f(u.uFogN, env.fogN); gl.uniform1f(u.uFogF, env.fogF);
    gl.uniform1f(u.uNight, env.night);
  }
  setVP(m) { this.gl.uniformMatrix4fv(this.u.uVP, false, m); }
  useStatic() {
    const gl = this.gl, u = this.u;
    gl.uniformMatrix4fv(u.uModel, false, this._I4); gl.uniformMatrix3fv(u.uNorm, false, this._I3);
    gl.uniform3f(u.uTint, 1, 1, 1); gl.uniform1f(u.uAlpha, 1);
  }
  _draw(mesh) {
    const gl = this.gl;
    gl.bindBuffer(gl.ARRAY_BUFFER, mesh.buf);
    gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 40, 0);
    gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 40, 12);
    gl.vertexAttribPointer(2, 4, gl.FLOAT, false, 40, 24);
    gl.drawArrays(gl.TRIANGLES, 0, mesh.n);
  }
  drawMesh(mesh) { if (mesh.n) this._draw(mesh); }
  /** Pieza con matriz (cur) y escala local (sx,sy,sz); normal = R·S⁻¹. */
  drawPart(mesh, cur, sx, sy, sz, col, alpha) {
    const gl = this.gl, u = this.u, m = this._m, n = this._n;
    m[0] = cur[0] * sx; m[1] = cur[1] * sx; m[2] = cur[2] * sx; m[3] = 0;
    m[4] = cur[4] * sy; m[5] = cur[5] * sy; m[6] = cur[6] * sy; m[7] = 0;
    m[8] = cur[8] * sz; m[9] = cur[9] * sz; m[10] = cur[10] * sz; m[11] = 0;
    m[12] = cur[12]; m[13] = cur[13]; m[14] = cur[14]; m[15] = 1;
    n[0] = cur[0] / sx; n[1] = cur[1] / sx; n[2] = cur[2] / sx;
    n[3] = cur[4] / sy; n[4] = cur[5] / sy; n[5] = cur[6] / sy;
    n[6] = cur[8] / sz; n[7] = cur[9] / sz; n[8] = cur[10] / sz;
    gl.uniformMatrix4fv(u.uModel, false, m); gl.uniformMatrix3fv(u.uNorm, false, n);
    gl.uniform3f(u.uTint, col[0], col[1], col[2]); gl.uniform1f(u.uAlpha, alpha);
    this._draw(mesh);
  }
  blend(on) {
    const gl = this.gl;
    if (on) { gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); }
    else { gl.disable(gl.BLEND); gl.depthMask(true); }
  }
}

/* ---------- entorno día/noche ---------- */
const Env = {
  night: 0, target: 0,
  sky: [0.47, 0.66, 0.85], sunN: [0.45, 0.8, 0.35], sunCol: [0.75, 0.7, 0.6],
  ambT: [0.45, 0.5, 0.6], ambB: [0.28, 0.26, 0.24], fogN: 26, fogF: 74,
  D: { sky: [0.47, 0.66, 0.85], sun: [0.45, 0.8, 0.35], sunCol: [0.75, 0.7, 0.6], ambT: [0.45, 0.5, 0.6], ambB: [0.28, 0.26, 0.24], fogN: 26, fogF: 74 },
  N: { sky: [0.03, 0.04, 0.09], sun: [-0.3, 0.6, -0.5], sunCol: [0.14, 0.18, 0.32], ambT: [0.12, 0.14, 0.26], ambB: [0.05, 0.05, 0.08], fogN: 10, fogF: 56 },
  update(dt) {
    this.night += (this.target - this.night) * Math.min(1, dt * 1.5);
    if (Math.abs(this.target - this.night) < 0.002) this.night = this.target;
    const t = this.night, D = this.D, N = this.N;
    for (let i = 0; i < 3; i++) {
      this.sky[i] = D.sky[i] + (N.sky[i] - D.sky[i]) * t;
      this.sunCol[i] = D.sunCol[i] + (N.sunCol[i] - D.sunCol[i]) * t;
      this.ambT[i] = D.ambT[i] + (N.ambT[i] - D.ambT[i]) * t;
      this.ambB[i] = D.ambB[i] + (N.ambB[i] - D.ambB[i]) * t;
      this.sunN[i] = D.sun[i] + (N.sun[i] - D.sun[i]) * t;
    }
    const l = Math.hypot(this.sunN[0], this.sunN[1], this.sunN[2]) || 1;
    this.sunN[0] /= l; this.sunN[1] /= l; this.sunN[2] /= l;
    this.fogN = D.fogN + (N.fogN - D.fogN) * t;
    this.fogF = D.fogF + (N.fogF - D.fogF) * t;
  }
};
