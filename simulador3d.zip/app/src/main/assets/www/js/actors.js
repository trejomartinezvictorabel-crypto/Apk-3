'use strict';
/* =====================================================================
   actors.js — cuerpos (NPC/zombis), zombis con daño por zona, ruido, piezas desprendidas (pool),
   señuelos/trazadoras, recolectables y frases de NPC con sabor de Jalisco / Zapopan
   ===================================================================== */
const Hooks = { say() {}, hurt() {}, msg() {}, kill() {}, hit() {} };
const ZH = 0, ZT = 1, ZLA = 2, ZRA = 3, ZLL = 4, ZRL = 5;
const ZNAMES = ['head', 'torso', 'leftArm', 'rightArm', 'leftLeg', 'rightLeg'];
const ZMAX = [1, 60, 30, 30, 38, 38];            // puntos de vida por zona (cabeza: golpe crítico)
const ZS = { WANDER: 0, INVEST: 1, CHASE: 2, ATTACK: 3 };
const rnd = () => Math.random();
const ZSHIRT = [0x7a3b32, 0x2e5f8c, 0xb59a2c, 0x2f6b4a, 0x9a8f7a, 0x5b3d7a, 0xa8602a, 0x3a7a7a, 0x8a4a6a, 0x6a6a74].map(rgb);
const ZPANTS = [0x22365e, 0x2e3d5c, 0x2e2e36, 0x6a5238, 0x4a4a55, 0x1c1c22].map(rgb);
const NSKIN = [0xf6d5c4, 0xe8b48f, 0xc98b63, 0x8f5a3b, 0x6e4430].map(rgb);
const NHAIR = [0x0a0a0c, 0x2b1d14, 0x4e3220, 0x7f5a3c, 0xb98b5e, 0xb5b5ba, 0x8e2b1c].map(rgb);
const WHITE = [1, 1, 1];

/* ---------- ruido: propagación por radio de distancia ---------- */
const Noise = {
  level: 0,
  emit(x, z, r, zone) { if (r > this.level) this.level = r; Zombies.hear(x, z, r, zone); },
  hold(r) { if (r > this.level) this.level = r; },
  decay(dt) { this.level *= Math.exp(-dt * 2.4); if (this.level < 0.5) this.level = 0; }
};

/* =====================================================================
   Cuerpo humanoide paramétrico (NPC y zombis). LOD 0 completo · LOD 1 simplificado · LOD 2 silueta
   ===================================================================== */
const Body = {
  S: new MStack(), M: null,
  init(M) { this.M = M; },
  make() {
    return {
      i: 0, x: 0, y: 0, z: 0, yaw: 0, sc: 1, bw: 1, skin: [0.9, 0.7, 0.6], shirt: WHITE, pants: WHITE, shoe: [0.2, 0.2, 0.2], hair: [0.1, 0.1, 0.1],
      hairStyle: 0, sleeve: 0, skirt: false, shorts: false, phase: 0, stride: 0, legL: 1, legR: 1, lean: 0.02, roll: 0, armUp: 0, armSway: 0.4,
      elbow: 0.2, headRoll: 0, headNod: 0, drop: 0, hipTilt: 0, atk: 0, fall: 0, fallDir: 1, cut: null, zombie: false, armBias: 0, seed: 0, vN: 0
    };
  },
  draw(R, b, lod) {
    const S = this.S, M = this.M;
    const part = (mesh, sx, sy, sz, col) => R.drawPart(mesh, S.m(), sx, sy, sz, col, 1);
    const bw = b.bw, hr = 0.16 * bw, sw = 0.18 * bw, wr = 0.12 * bw, cd = 0.1 * bw, lr = 0.07 * bw, ar = 0.04 * bw;
    S.reset(); S.translate(b.x, b.y, b.z);
    if (b.fall > 0) S.translate(0, 0.15 * b.fall, 0);
    S.rotY(b.yaw);
    if (b.fall > 0) S.rotX(-b.fall * 1.45 * b.fallDir);
    S.scale(b.sc);
    const hip = 0.94 - b.drop, cut = b.cut;

    if (lod >= 2) { // silueta mínima
      S.push(); S.translate(0, 0.9, 0); part(M.cyl, 0.38 * bw, 1.5, 0.28 * bw, b.shirt); S.pop();
      S.push(); S.translate(0, 1.66, 0); part(M.sph, 0.2, 0.23, 0.2, b.skin); S.pop();
      return;
    }
    if (lod === 1) { // geometría simplificada
      for (const s of [-1, 1]) {
        const zi = s < 0 ? ZLL : ZRL;
        S.push(); S.translate(s * hr * 0.55, hip, 0);
        if (cut && cut[zi]) { S.translate(0, -0.08, 0); part(M.cyl, 2 * lr, 0.16, 2 * lr, b.pants); }
        else { S.rotX(-Math.sin(b.phase + (s > 0 ? Math.PI : 0)) * b.stride * (s < 0 ? b.legL : b.legR)); S.translate(0, -0.44, 0); part(M.cyl, 2 * lr, 0.88, 1.7 * lr, b.pants); }
        S.pop();
      }
      S.push(); S.translate(0, hip, 0); S.rotZ(b.roll); S.rotX(b.lean);
      S.push(); S.translate(0, 0.3, 0); part(M.cyl, 1.9 * sw, 0.62, 2 * wr, b.shirt); S.pop();
      if (!(cut && cut[ZH])) { S.push(); S.translate(0, 0.69, 0); part(M.sph, 0.205, 0.235, 0.22, b.skin); S.pop(); }
      for (const s of [-1, 1]) {
        const zi = s < 0 ? ZLA : ZRA;
        if (cut && cut[zi]) continue;
        S.push(); S.translate(s * (sw + 0.04), 0.44, 0); S.rotX(b.armUp + Math.sin(b.phase + (s < 0 ? Math.PI : 0)) * b.armSway);
        S.translate(0, -0.28, 0); part(M.cyl, 2 * ar, 0.56, 2 * ar, b.sleeve === 2 ? b.skin : b.shirt); S.pop();
      }
      S.pop();
      return;
    }

    /* ----- LOD 0: piernas ----- */
    const thC = b.pants, shC = (b.shorts || b.skirt) ? b.skin : b.pants;
    for (const s of [-1, 1]) {
      const zi = s < 0 ? ZLL : ZRL;
      S.push(); S.translate(s * hr * 0.55, hip + s * b.hipTilt, 0);
      if (cut && cut[zi]) { S.translate(0, -0.08, 0); part(M.cyl, 2.1 * lr, 0.16, 2.1 * lr, thC); S.pop(); continue; } // muñón
      const p = b.phase + (s > 0 ? Math.PI : 0), amp = b.stride * (s < 0 ? b.legL : b.legR);
      S.rotX(-Math.sin(p) * amp);
      S.push(); S.translate(0, -0.225, 0); part(M.cyl, 2 * lr, 0.45, 2 * lr, thC); S.pop();
      S.translate(0, -0.45, 0); S.rotX(Math.max(0, Math.cos(p)) * amp * 1.1);
      S.push(); S.translate(0, -0.215, 0); part(M.cyl, 1.7 * lr, 0.43, 1.7 * lr, shC); S.pop();
      S.translate(0, -0.43, 0);
      S.push(); S.translate(0, -0.02, 0.05); part(M.box, lr * 2.1, 0.07, 0.27, b.shoe); S.pop();
      S.pop();
    }

    /* ----- tronco ----- */
    S.push(); S.translate(0, hip, 0); S.rotZ(b.roll); S.rotX(b.lean);
    S.push(); S.translate(0, 0.01, 0); part(M.cyl, 2 * hr, 0.2, 1.5 * hr, b.pants); S.pop();
    S.push(); S.translate(0, 0.16, 0); part(M.cyl, 2 * wr, 0.2, 1.6 * wr, b.shirt); S.pop();
    S.push(); S.translate(0, 0.33, 0); part(M.cyl, 2 * sw, 0.26, 2 * cd, b.shirt); S.pop();
    if (b.skirt) { S.push(); S.translate(0, -0.08, 0); part(M.skirt, 2 * hr * 1.5, 0.55, 2 * hr * 1.2, b.pants); S.pop(); }
    S.push(); S.translate(0, 0.55, 0); part(M.cyl, 0.17 * bw, 0.12, 0.17 * bw, b.skin); S.pop();

    /* ----- brazos ----- */
    const uF = b.sleeve === 2 ? 0 : (b.sleeve === 1 ? 1 : 0.55), fF = b.sleeve === 1 ? 1 : 0;
    for (const s of [-1, 1]) {
      const zi = s < 0 ? ZLA : ZRA;
      S.push(); S.translate(s * (sw + ar * 0.9), 0.44, 0);
      part(M.sph, ar * 2.3, ar * 2.3, ar * 2.3, uF > 0 ? b.shirt : b.skin);
      if (cut && cut[zi]) { S.translate(0, -0.07, 0); part(M.cyl, 2 * ar, 0.14, 2 * ar, uF > 0 ? b.shirt : b.skin); S.pop(); continue; }
      const pa = b.phase + (s < 0 ? Math.PI : 0);
      let ang = b.armUp + Math.sin(pa) * b.armSway + (s > 0 ? b.armBias : -b.armBias);
      if (b.atk > 0) ang -= 0.6 * Math.sin(Math.PI * b.atk);
      const el = -(b.elbow + 0.18 * Math.sin(pa * 0.5 + b.seed));
      S.rotZ(s * 0.12); S.rotX(ang);
      S.push(); S.translate(0, -0.15, 0); part(M.cyl, 2 * ar, 0.30, 2 * ar, b.skin); if (uF > 0) { S.translate(0, 0.15 - 0.15 * uF, 0); part(M.cyl, 2.2 * ar, 0.30 * uF, 2.2 * ar, b.shirt); } S.pop();
      S.translate(0, -0.30, 0); S.rotX(el);
      S.push(); S.translate(0, -0.135, 0); part(M.cyl, 1.8 * ar, 0.27, 1.8 * ar, fF > 0 ? b.shirt : b.skin); S.pop();
      S.translate(0, -0.27, 0); part(M.sph, 2.2 * ar, 2.5 * ar, 2.2 * ar, b.skin);
      S.pop();
    }

    /* ----- cabeza ----- */
    if (!(cut && cut[ZH])) {
      S.push(); S.translate(0, 0.69, 0); S.rotZ(b.headRoll); S.rotX(b.headNod);
      part(M.sph, 0.205, 0.235, 0.22, b.skin);
      if (b.zombie) for (const s of [-1, 1]) { S.push(); S.translate(s * 0.045, 0.03, 0.095); part(M.box, 0.034, 0.022, 0.02, [0.08, 0.06, 0.06]); S.pop(); }
      if (b.hairStyle >= 0) {
        S.push(); S.translate(0, 0.012, -0.012); S.rotX(-0.5); part(M.hemi, 0.238, 0.255, 0.25, b.hair); S.pop();
        if (b.hairStyle === 1) { S.push(); S.translate(0, -0.06, -0.085); part(M.box, 0.235, 0.3, 0.07, b.hair); S.pop(); }
        if (b.hairStyle === 2) { S.push(); S.translate(0, 0.03, -0.12); part(M.sph, 0.09, 0.09, 0.09, b.hair); S.pop(); }
      }
      S.pop();
    }
    S.pop();
  }
};

/* ---------- piezas desprendidas y efectos ligeros (object pooling, sin sangre) ---------- */
const Pieces = {
  pool: [],
  init() { for (let i = 0; i < 24; i++) this.pool.push({ a: false, i, zone: -1, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, rx: 0, ry: 0, rz: 0, wx: 0, wy: 0, wz: 0, life: 0, mesh: null, sx: 1, sy: 1, sz: 1, col: WHITE }); },
  clear() { for (const p of this.pool) p.a = false; },
  spawn(mesh, zone, x, y, z, vx, vy, vz, sx, sy, sz, col) {
    let p = null; for (const q of this.pool) if (!q.a) { p = q; break; }
    if (!p) { p = this.pool[0]; for (const q of this.pool) if (q.life < p.life) p = q; } // reutiliza la más vieja
    p.a = true; p.zone = zone; p.x = x; p.y = y; p.z = z; p.vx = vx; p.vy = vy; p.vz = vz; p.life = 5;
    p.rx = rnd() * 3; p.ry = rnd() * 3; p.rz = rnd() * 3; p.wx = (rnd() - 0.5) * 9; p.wy = (rnd() - 0.5) * 6; p.wz = (rnd() - 0.5) * 9;
    p.mesh = mesh; p.sx = sx; p.sy = sy; p.sz = sz; p.col = col;
    return p;
  },
  update(dt) {
    for (const p of this.pool) {
      if (!p.a) continue;
      p.life -= dt; if (p.life <= 0) { p.a = false; continue; }
      p.vy -= 14 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
      const g = (p.zone < 0 ? World.heightAt(p.x, p.z) : 0) + 0.1;
      if (p.y < g) { p.y = g; p.vy *= -0.25; p.vx *= 0.6; p.vz *= 0.6; p.wx *= 0.5; p.wz *= 0.5; if (Math.abs(p.vy) < 0.4) p.vy = 0; }
      p.rx += p.wx * dt; p.ry += p.wy * dt; p.rz += p.wz * dt;
    }
  },
  draw(R, S, zone) {
    for (const p of this.pool) {
      if (!p.a || p.zone !== zone || !Frustum.sphere(p.x, p.y, p.z, 0.8)) continue;
      const k = p.life < 0.6 ? p.life / 0.6 : 1;
      S.reset(); S.translate(p.x, p.y, p.z); S.rotY(p.ry); S.rotX(p.rx); S.rotZ(p.rz);
      R.drawPart(p.mesh, S.m(), p.sx * k, p.sy * k, p.sz * k, p.col, 1);
    }
  }
};

/* =====================================================================
   Zombis: variación individual, zonas de daño, cojera real, letalidad en la cabeza
   ===================================================================== */
function zRefresh(z) { // recalcula movimiento según partes dañadas/cortadas
  const cl = z.cut[ZLL], cr = z.cut[ZRL];
  const wl = cl ? 1 : 1 - z.hp[ZLL] / ZMAX[ZLL], wr = cr ? 1 : 1 - z.hp[ZRL] / ZMAX[ZRL];
  z.legL = cl ? 0 : (1 + z.asym) * (1 - 0.5 * wl);
  z.legR = cr ? 0 : (1 - z.asym) * (1 - 0.5 * wr);
  z.legs = cl + cr; z.crawl = z.legs === 2;
  z.drop = z.crawl ? 0.68 : (z.legs === 1 ? 0.2 : 0);
  z.hipTilt = z.legs === 1 ? (cl ? 0.06 : -0.06) : (wl - wr) * 0.04;
  z.rollB = z.legs === 1 ? (cl ? 0.2 : -0.2) : (wl - wr) * 0.1;
  z.speedK = z.crawl ? 0.16 : (z.legs === 1 ? 0.5 : 1 - 0.3 * Math.max(wl, wr));
  z.arms = 2 - z.cut[ZLA] - z.cut[ZRA];
  z.atkK = z.arms === 2 ? 1 : (z.arms === 1 ? 0.55 : 0.2);
}
function partWorld(z, zi, out) {
  const s = z.sc, bw = z.bw, cy = Math.cos(z.yaw), sy = Math.sin(z.yaw);
  let lx = 0, ly = 1;
  if (zi === ZH) ly = 1.63 - z.drop; else if (zi === ZLA) { lx = -(0.18 * bw + 0.04); ly = 1.15 - z.drop; } else if (zi === ZRA) { lx = 0.18 * bw + 0.04; ly = 1.15 - z.drop; }
  else if (zi === ZLL) { lx = -0.09 * bw; ly = 0.5 - z.drop * 0.5; } else if (zi === ZRL) { lx = 0.09 * bw; ly = 0.5 - z.drop * 0.5; }
  out[0] = z.x + lx * cy * s; out[1] = z.y + ly * s; out[2] = z.z - lx * sy * s;
}
const _pw = [0, 0, 0];
function zCut(z, zi) {
  if (z.cut[zi]) return;
  z.cut[zi] = 1; z.hp[zi] = 0;
  partWorld(z, zi, _pw);
  const M = Body.M, a = rnd() * 6.28, vx = Math.cos(a) * 1.6, vz = Math.sin(a) * 1.6;
  if (zi === ZH) Pieces.spawn(M.sph, z.zone, _pw[0], _pw[1], _pw[2], vx, 3.4, vz, 0.2, 0.23, 0.2, z.skin);
  else if (zi === ZLA || zi === ZRA) Pieces.spawn(M.cyl, z.zone, _pw[0], _pw[1], _pw[2], vx, 2.6, vz, 0.09, 0.55, 0.09, z.shirt);
  else Pieces.spawn(M.cyl, z.zone, _pw[0], _pw[1], _pw[2], vx, 2.2, vz, 0.15, 0.85, 0.15, z.pants);
}
function zKill(z) {
  z.dead = true; z.deadT = 0; z.fall = 0; z.fallDir = rnd() < 0.5 ? 1 : -1; z.vx = z.vz = 0; z.atk = 0;
  Hooks.kill(z);
}
const _zq = [];

const Zombies = {
  pool: [], cleared: [false, false, false], spawnT: 0, hiddenFn: null, time: 0,
  init() {
    for (let i = 0; i < 18; i++) {
      const z = Body.make(); z.i = i; z.zombie = true; z.cut = new Uint8Array(6); z.hp = new Float32Array(6);
      Object.assign(z, { active: false, dead: false, zone: -1, vx: 0, vz: 0, vy: 0, grounded: true, state: 0, tx: 0, tz: 0, alert: 0, seeT: 0, lostT: 0, atkT: 0, atkCd: 0, stag: 0, stagVx: 0, stagVz: 0, base: 1, cad: 1, strideB: 0.5, sway: 0.2, leanB: 0.2, asym: 0, trF: 8, trA: 0.03, headTilt: 0, armBase: -1.15, stumbleT: 0, stumbleCd: 3, deadT: 0, wT: 0, hx: 0, hz: 0, visMul: 1, hear: 1, legs: 0, crawl: false, rollB: 0, speedK: 1, arms: 2, atkK: 1, spd: 0, support: 0 });
      this.pool.push(z);
    }
  },
  clear() { for (const z of this.pool) { z.active = false; z.dead = false; } this.cleared = [false, false, false]; this.spawnT = 2; },
  activeCount(zone) { let n = 0; for (const z of this.pool) if (z.active && !z.dead && z.zone === zone) n++; return n; },
  countNear(x, z, r) { let n = 0; for (const q of this.pool) if (q.active && !q.dead && Math.hypot(q.x - x, q.z - z) < r) n++; return n; },

  spawn(x, zz, zone) {
    let z = null; for (const q of this.pool) if (!q.active) { z = q; break; }
    if (!z) return null;
    z.active = true; z.dead = false; z.zone = zone; z.x = x; z.z = zz; z.y = zone < 0 ? World.heightAt(x, zz) : 0; z.vx = z.vz = z.vy = 0; z.grounded = true;
    z.yaw = rnd() * 6.28; z.fall = 0; z.fallDir = 1; z.deadT = 0; z.stag = 0; z.state = ZS.WANDER; z.alert = 0; z.lostT = 0; z.atkT = 0; z.atkCd = 1; z.atk = 0;
    z.hx = x; z.hz = zz; z.tx = x; z.tz = zz; z.wT = rnd() * 3; z.vN = 0; z.seeT = rnd() * 0.3;
    // individualidad: ninguna se mueve igual
    z.seed = rnd() * 100; z.sc = 0.93 + rnd() * 0.16; z.bw = 0.85 + rnd() * 0.3; z.base = 0.8 + rnd() * 0.75; z.cad = 0.7 + rnd() * 0.7;
    z.strideB = 0.35 + rnd() * 0.3; z.sway = 0.1 + rnd() * 0.25; z.leanB = 0.12 + rnd() * 0.26; z.asym = (rnd() - 0.5) * 0.4; z.armBias = (rnd() - 0.5) * 0.5;
    z.trF = 5 + rnd() * 6; z.trA = 0.02 + rnd() * 0.035; z.headTilt = (rnd() - 0.5) * 0.5; z.armBase = -0.95 - rnd() * 0.45; z.phase = rnd() * 6.28;
    z.stumbleCd = 2 + rnd() * 6; z.stumbleT = 0; z.visMul = 0.8 + rnd() * 0.5; z.hear = 0.85 + rnd() * 0.4;
    const t = rnd(); z.skin = [0.5 + t * 0.12, 0.6 + t * 0.08, 0.47 + t * 0.08];
    z.shirt = shade(ZSHIRT[(rnd() * ZSHIRT.length) | 0], 0.55); z.pants = shade(ZPANTS[(rnd() * ZPANTS.length) | 0], 0.75);
    z.shoe = [0.14, 0.12, 0.11]; z.hair = shade(NHAIR[(rnd() * NHAIR.length) | 0], 0.6); z.hairStyle = rnd() < 0.2 ? -1 : (rnd() * 3) | 0;
    z.sleeve = rnd() < 0.5 ? 0 : 1; z.skirt = false; z.shorts = rnd() < 0.15;
    for (let i = 0; i < 6; i++) { z.cut[i] = 0; z.hp[i] = ZMAX[i]; }
    z.elbow = 0.25 + rnd() * 0.3;
    zRefresh(z);
    return z;
  },

  /** Los infectados dentro del radio oyen el origen del ruido y van hacia allí aunque no haya línea de visión. */
  hear(x, zz, r, zone) {
    for (const z of this.pool) {
      if (!z.active || z.dead || z.zone !== zone || z.state >= ZS.CHASE) continue;
      if (Math.hypot(z.x - x, z.z - zz) < r * z.hear) { z.state = ZS.INVEST; z.tx = x + (rnd() - 0.5) * 2.5; z.tz = zz + (rnd() - 0.5) * 2.5; z.alert = 9; }
    }
  },

  /** Zombis vivos dentro de un arco frontal (para tajos y disparos). */
  query(x, z, fx, fz, reach, cosA, zone) {
    _zq.length = 0;
    for (const q of this.pool) {
      if (!q.active || q.dead || q.zone !== zone) continue;
      const dx = q.x - x, dz = q.z - z, d = Math.hypot(dx, dz);
      if (d > reach || d < 1e-4) { if (d < 0.5) _zq.push(q); continue; }
      if ((dx * fx + dz * fz) / d >= cosA) _zq.push(q);
    }
    _zq.sort((a, b) => Math.hypot(a.x - x, a.z - z) - Math.hypot(b.x - x, b.z - z));
    return _zq;
  },

  /** Aplica daño a una zona. Devuelve 'miss' | 'wound' | 'cut' | 'dead' | 'stagger'. */
  hit(z, zone, dmg, hx, hz, P) {
    if (!z.active || z.dead) return 'miss';
    if (zone !== ZH && z.cut[zone]) zone = ZT;             // la parte ya no existe: el golpe cae en el torso
    z.hp[zone] -= dmg;
    let res = 'wound';
    if (zone === ZH) { zCut(z, ZH); zKill(z); res = 'dead'; }                                // cabeza: corte crítico letal
    else if (zone === ZT) {
      if (z.hp[ZT] <= 0) { zKill(z); res = 'dead'; }
      else { z.stag = 0.7; const l = Math.hypot(hx, hz) || 1; z.stagVx = hx / l * 2.6; z.stagVz = hz / l * 2.6; res = 'stagger'; } // daño corporal + retroceso/tambaleo
    } else if (z.hp[zone] <= 0) { zCut(z, zone); zRefresh(z); res = 'cut'; }               // pierna/brazo cortado
    else zRefresh(z);
    if (!z.dead && z.state < ZS.CHASE) { z.state = ZS.CHASE; z.tx = P.x; z.tz = P.z; z.alert = 8; }
    Hooks.hit(z, zone, res);
    return res;
  },

  /** Aparición alrededor del jugador (solo exterior, modo zombi). */
  spawnTick(dt, P, G) {
    if (G.mode !== 1 || P.zone >= 0) return;
    this.spawnT -= dt; if (this.spawnT > 0) return;
    this.spawnT = 1.3;
    const dens = [7, 3, 10, 8, 8][sectorAt(P.x, P.z)];
    if (this.activeCount(-1) >= Math.min(14, dens)) return;
    for (let t = 0; t < 8; t++) {
      const a = rnd() * 6.283, d = 42 + rnd() * 30, x = P.x + Math.sin(a) * d, z = P.z + Math.cos(a) * d;
      if (Math.abs(x) > 190 || Math.abs(z) > 190 || !World.cellLoaded(x, z) || !World.free(x, z, 0.5)) continue;
      const y = World.heightAt(x, z);
      if (this.hiddenFn && !this.hiddenFn(x, y + 1, z)) continue;
      this.spawn(x, z, -1); return;
    }
  },
  enterInterior(i, G) {
    if (G.mode !== 1 || this.cleared[i]) return;
    const d = INT_DEFS[i];
    for (const s of d.zspots) this.spawn(d.ox + s[0], d.oz + s[1], i);
  },
  leaveInterior(i) {
    let alive = 0;
    for (const z of this.pool) if (z.active && z.zone === i) { if (!z.dead) alive++; z.active = false; }
    if (alive === 0) this.cleared[i] = true;
  },

  update(dt, P, G) {
    this.time += dt;
    const t = this.time;
    for (const z of this.pool) {
      if (!z.active || z.zone !== P.zone) continue;
      if (z.dead) { z.deadT += dt; z.fall = Math.min(1, z.fall + dt * 1.8); if (z.deadT > 6) z.sc *= Math.max(0, 1 - dt * 1.5); if (z.deadT > 7.5) z.active = false; continue; }
      const dx = P.x - z.x, dz = P.z - z.z, d = Math.hypot(dx, dz);
      // ---- sentidos: vista (alcance, ángulo, línea de visión, sigilo) ----
      z.seeT -= dt;
      if (z.seeT <= 0) {
        z.seeT = 0.28;
        const vis = G.vision * (P.crouch > 0.5 ? 0.5 : 1) * z.visMul * (G.night ? 0.75 : 1);
        let sees = false;
        if (d < vis) {
          const dot = (dx * Math.sin(z.yaw) + dz * Math.cos(z.yaw)) / Math.max(d, 1e-3);
          if (dot > 0.35 || d < 3.2) sees = P.zone >= 0 || !World.segBlocked(z.x, z.z, P.x, P.z);
        }
        if (sees && !G.dead) { z.state = d < 1.3 ? ZS.ATTACK : ZS.CHASE; z.tx = P.x; z.tz = P.z; z.lostT = 0; z.alert = 6; }
        else if (z.state === ZS.CHASE || z.state === ZS.ATTACK) { z.lostT += 0.28; if (z.lostT > 3.5) z.state = ZS.INVEST; }
      }
      if (z.state === ZS.CHASE && d < 1.3) z.state = ZS.ATTACK; else if (z.state === ZS.ATTACK && d > 1.9) z.state = ZS.CHASE;
      if (G.dead && z.state >= ZS.CHASE) { z.state = ZS.WANDER; }
      // ---- decisión de movimiento ----
      let want = 0;
      if (z.state === ZS.WANDER) {
        z.wT -= dt;
        if (z.wT <= 0) { z.wT = 2 + rnd() * 5; if (rnd() < 0.6) { const a = rnd() * 6.28, r = 3 + rnd() * 7; z.tx = z.hx + Math.sin(a) * r; z.tz = z.hz + Math.cos(a) * r; z.moveW = true; } else z.moveW = false; }
        want = z.moveW ? 0.45 : 0;
      } else if (z.state === ZS.INVEST) { want = 0.9; if (Math.hypot(z.tx - z.x, z.tz - z.z) < 1.5) { z.state = ZS.WANDER; z.hx = z.x; z.hz = z.z; z.wT = 1; } }
      else if (z.state === ZS.CHASE) want = 1.35;
      else if (z.state === ZS.ATTACK) want = 0;
      const spd = z.base * want * z.speedK;
      let tvx = 0, tvz = 0;
      if (want > 0) {
        const ex = z.tx - z.x, ez = z.tz - z.z, el = Math.hypot(ex, ez) || 1;
        tvx = ex / el * spd; tvz = ez / el * spd;
        let da = Math.atan2(ex, ez) - z.yaw; while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI;
        z.yaw += da * Math.min(1, dt * 3.2);
      } else if (z.state === ZS.ATTACK) {
        let da = Math.atan2(dx, dz) - z.yaw; while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI;
        z.yaw += da * Math.min(1, dt * 5);
      }
      // micro-tambaleo: tropiezos breves con impulso de paso
      z.stumbleCd -= dt;
      if (z.stumbleT > 0) z.stumbleT -= dt; else if (z.stumbleCd <= 0 && spd > 0.2) { z.stumbleT = 0.45; z.stumbleCd = 3 + rnd() * 7; z.phase += 0.6; }
      if (z.stumbleT > 0) { tvx *= 0.55; tvz *= 0.55; }
      if (z.stag > 0) { z.stag -= dt; tvx = z.stagVx * (z.stag / 0.7); tvz = z.stagVz * (z.stag / 0.7); }
      const k = Math.min(1, dt * 4);
      z.vx += (tvx - z.vx) * k; z.vz += (tvz - z.vz) * k;
      z.x += z.vx * dt; z.z += z.vz * dt;
      // separación entre infectados
      for (const o of this.pool) {
        if (o === z || !o.active || o.dead || o.zone !== z.zone) continue;
        const ox = z.x - o.x, oz = z.z - o.z, od = Math.hypot(ox, oz);
        if (od < 0.7 && od > 1e-4) { z.x += ox / od * (0.7 - od) * 0.5; z.z += oz / od * (0.7 - od) * 0.5; }
      }
      World.resolve(z);
      z.spd = Math.hypot(z.vx, z.vz);
      z.phase += dt * z.cad * (0.5 + z.spd * 1.5);
      // ---- ataque (menos efectivo con brazos cortados) ----
      if (z.state === ZS.ATTACK) {
        z.atkT += dt;
        if (z.atkT >= 0.55) {
          if (d < 1.7) Hooks.hurt((6 + rnd() * 4) * z.atkK, z);
          z.atkT = -(1.0 + (2 - z.arms) * 0.4); z.atkCd = 0;
        }
        z.atk = z.atkT > 0 ? Math.min(1, z.atkT / 0.55) : 0;
      } else { z.atkT = 0; z.atk = 0; }
      // ---- pose individual ----
      const sp = Math.min(1, z.spd / 1.8), trem = Math.sin(t * z.trF + z.seed) * z.trA;
      const stum = z.stumbleT > 0 ? Math.sin(Math.PI * (1 - z.stumbleT / 0.45)) : 0;
      z.lean = z.leanB + (z.crawl ? 1.05 : 0) + 0.18 * stum + trem * 0.6 + (z.stag > 0 ? -0.3 : 0);
      z.roll = z.rollB + Math.sin(z.phase * 0.5 + z.seed) * z.sway * 0.35 * sp + trem * 0.5;
      z.armUp = z.crawl ? -0.6 : z.armBase + 0.18 * Math.sin(t * 0.6 + z.seed);
      z.armSway = 0.12 + z.sway * sp;
      z.stride = z.strideB * (0.45 + 0.9 * sp);
      z.headRoll = z.headTilt + Math.sin(t * 0.9 + z.seed * 2) * 0.1 + trem;
      z.headNod = 0.1 + 0.08 * Math.sin(t * 1.3 + z.seed) + stum * 0.15;
    }
  },

  draw(R, cam, frame, P) {
    for (const z of this.pool) {
      if (!z.active || z.zone !== P.zone) continue;
      const d = Math.hypot(z.x - cam.x, z.z - cam.z);
      if (P.zone < 0) { if (d > 112 || !World.visible(z, z.x, z.y + 1, z.z, 1.4, cam, frame)) continue; }
      else if (!Frustum.sphere(z.x, z.y + 1, z.z, 1.4)) continue;
      Body.draw(R, z, d < 26 ? 0 : (d < 52 ? 1 : 2));
    }
  }
};

/* =====================================================================
   NPC (habitantes en Mundo Abierto / supervivientes en Modo Zombi) y frases de Jalisco
   ===================================================================== */
const PHR = {
  greet: ['¡Qué tal, buen día!', '¿Qué onda, cómo andamos?', '¡Órale, qué gusto verte!', '¡Bienvenido a Zapopan!', '¡Buenas! ¿Todo bien por aquí?', '¡Ahorita nos vemos, mi estimado!', '¡Qué padre día, compa!'],
  cheer: ['¡Ánimo, compa!', '¡Échale ganas, tú puedes!', '¡No hay bronca, ahí la llevamos!', '¡Con calma y buena vibra!'],
  danger: ['¡Órale, aguas ahí!', '¡Aguas, que ahí vienen!', '¡Cuidado por el rumbo del cerro!', '¡Échale ojo al camino!', '¡Ponte buzo, compa!', '¡Híjole, qué se oye por allá!'],
  night: ['¡Qué fresco está esta noche!', '¡Ya anocheció, anda con cuidado!', '¡Aguas con la oscuridad, compa!'],
  day: ['¡Ya amaneció, qué bendición!', '¡Buen día, a darle con ganas!'],
  sec: [
    ['¿Ya probaste una torta ahogada?', '¡Aquí en Zapopan se vive bonito!', '¡La plaza está de lo más bonita!'],
    ['¡Siga las indicaciones del retén!', '¡Aquí estamos al pendiente, compa!'],
    ['¡Échale ojo al sendero!', '¡El bosque huele a pino, qué rico!'],
    ['¡Cuidado por el rumbo del cerro!', '¡Desde el mirador se ve toda la ciudad!'],
    ['¡Esta carretera lleva a Guadalajara y más allá!', '¡Buen viaje, compa!']
  ]
};
const Npcs = {
  list: [], globalCd: 0, dangerCd: 0,
  init() {
    NPC_SPAWNS.forEach((s, i) => {
      const n = Body.make(); n.i = 40 + i;
      n.x = s[0]; n.z = s[1]; n.hx = s[0]; n.hz = s[1]; n.y = World.heightAt(s[0], s[1]); n.zone = -1; n.vx = n.vz = n.vy = 0; n.grounded = true; n.yaw = rnd() * 6.28;
      n.sc = 0.93 + rnd() * 0.15; n.bw = 0.85 + rnd() * 0.3; n.skin = NSKIN[(rnd() * NSKIN.length) | 0];
      n.shirt = ZSHIRT[(rnd() * ZSHIRT.length) | 0]; n.pants = ZPANTS[(rnd() * ZPANTS.length) | 0]; n.shoe = [0.2, 0.15, 0.12];
      n.hair = NHAIR[(rnd() * NHAIR.length) | 0]; n.hairStyle = (rnd() * 3) | 0; n.sleeve = (rnd() * 3) | 0; n.skirt = rnd() < 0.25; n.shorts = rnd() < 0.2;
      n.seed = rnd() * 50; n.phase = rnd() * 6; n.talkCd = rnd() * 8; n.wT = rnd() * 3; n.moving = false; n.tx = n.x; n.tz = n.z; n.faceT = 0; n.last = -1; n.sec = sectorAt(s[0], s[1]);
      n.armSway = 0.45; n.elbow = 0.2; n.act = false;
      this.list.push(n);
    });
  },
  phrase(n, kind) {
    let pool;
    if (kind === 'greet') { const r = rnd(); pool = r < 0.45 ? PHR.greet : (r < 0.75 ? PHR.sec[n.sec] : PHR.cheer); }
    else pool = PHR[kind];
    let i = (rnd() * pool.length) | 0; if (i === n.last && pool.length > 1) i = (i + 1) % pool.length;
    n.last = i; return pool[i];
  },
  say(n, kind) {
    if (this.globalCd > 0) return false;
    Hooks.say(n, this.phrase(n, kind)); this.globalCd = 2.6; n.talkCd = 14 + rnd() * 10; n.faceT = 3; return true;
  },
  /** Al cambiar de hora, el NPC más cercano comenta (respeta enfriamientos). */
  onTime(isNight, P) {
    let best = null, bd = 30;
    for (const n of this.list) { const d = Math.hypot(n.x - P.x, n.z - P.z); if (d < bd && n.talkCd < 8) { bd = d; best = n; } }
    if (best) this.say(best, isNight ? 'night' : 'day');
  },
  update(dt, P, G) {
    this.globalCd -= dt; this.dangerCd -= dt;
    if (P.zone >= 0) return;
    for (const n of this.list) {
      const dx = P.x - n.x, dz = P.z - n.z, d = Math.hypot(dx, dz);
      n.act = d < 95; if (!n.act) continue;
      n.talkCd -= dt; n.wT -= dt;
      if (n.wT <= 0) {
        n.wT = 2 + rnd() * 5; n.moving = rnd() < 0.5;
        if (n.moving) { const a = rnd() * 6.28, r = 2 + rnd() * 6; n.tx = n.hx + Math.sin(a) * r; n.tz = n.hz + Math.cos(a) * r; }
      }
      let yawT = n.yaw, spd = 0;
      if (n.faceT > 0) { n.faceT -= dt; yawT = Math.atan2(dx, dz); }
      else if (n.moving) {
        const ex = n.tx - n.x, ez = n.tz - n.z, el = Math.hypot(ex, ez);
        if (el < 0.6) n.moving = false; else { yawT = Math.atan2(ex, ez); spd = 1.0; }
      }
      let da = yawT - n.yaw; while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI;
      n.yaw += da * Math.min(1, dt * 4);
      if (spd > 0) { n.vx = Math.sin(n.yaw) * spd; n.vz = Math.cos(n.yaw) * spd; n.x += n.vx * dt; n.z += n.vz * dt; } else { n.vx = n.vz = 0; }
      World.resolve(n);
      n.phase += dt * spd * 3.4; n.stride = spd > 0 ? 0.5 : 0; n.armSway = 0.45;
      // frases: cercanía, peligro en Modo Zombi (con enfriamiento para no saturar)
      if (G.mode === 1 && this.dangerCd <= 0 && d < 28 && Zombies.countNear(n.x, n.z, 20) > 0) { if (this.say(n, 'danger')) this.dangerCd = 9; }
      else if (d < 6.5 && n.talkCd <= 0) this.say(n, 'greet');
    }
  },
  draw(R, cam, frame, P) {
    if (P.zone >= 0) return;
    for (const n of this.list) {
      if (!n.act) continue;
      const d = Math.hypot(n.x - cam.x, n.z - cam.z);
      if (d > 100 || !World.visible(n, n.x, n.y + 1, n.z, 1.3, cam, frame)) continue;
      Body.draw(R, n, d < 30 ? 0 : (d < 60 ? 1 : 2));
    }
  }
};

/* =====================================================================
   Proyectiles ligeros en pool: señuelos (ruido que atrae) y trazadoras del arma pesada
   ===================================================================== */
const Proj = {
  decoys: [], tracers: [],
  init() {
    for (let i = 0; i < 4; i++) this.decoys.push({ a: false, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, zone: -1, landed: false, t: 0, pulses: 0, mul: 1, ring: 0 });
    for (let i = 0; i < 6; i++) this.tracers.push({ a: false, x0: 0, y0: 0, z0: 0, x1: 0, y1: 0, z1: 0, t: 0 });
  },
  clear() { for (const d of this.decoys) d.a = false; for (const t of this.tracers) t.a = false; },
  throwDecoy(x, y, z, dx, dz, power, zone, mul) {
    let d = null; for (const q of this.decoys) if (!q.a) { d = q; break; }
    if (!d) d = this.decoys[0];
    d.a = true; d.x = x; d.y = y; d.z = z; d.vx = dx * power; d.vz = dz * power; d.vy = 4.2; d.zone = zone; d.landed = false; d.t = 0; d.pulses = 0; d.mul = mul; d.ring = 0;
  },
  tracer(x0, y0, z0, x1, y1, z1) {
    let t = null; for (const q of this.tracers) if (!q.a) { t = q; break; }
    if (!t) t = this.tracers[0];
    t.a = true; t.x0 = x0; t.y0 = y0; t.z0 = z0; t.x1 = x1; t.y1 = y1; t.z1 = z1; t.t = 0.09;
  },
  update(dt) {
    for (const d of this.decoys) {
      if (!d.a) continue;
      if (!d.landed) {
        d.vy -= 15 * dt; d.x += d.vx * dt; d.y += d.vy * dt; d.z += d.vz * dt;
        const g = d.zone < 0 ? World.heightAt(d.x, d.z) : 0;
        if (d.y <= g + 0.05) {
          d.y = g + 0.05; d.landed = true; d.t = 0; d.ring = 0.001;
          Noise.emit(d.x, d.z, 30 * d.mul, d.zone); d.pulses = 1;   // el impacto genera un pulso de ruido
        }
      } else {
        d.t += dt; d.ring += dt;
        if (d.pulses === 1 && d.t > 1.0) { Noise.emit(d.x, d.z, 26 * d.mul, d.zone); d.pulses = 2; d.ring = 0.001; }
        if (d.pulses === 2 && d.t > 2.0) { Noise.emit(d.x, d.z, 22 * d.mul, d.zone); d.pulses = 3; d.ring = 0.001; }
        if (d.t > 3.4) d.a = false;
      }
    }
    for (const t of this.tracers) if (t.a) { t.t -= dt; if (t.t <= 0) t.a = false; }
  },
  draw(R, S, M, zone) {
    for (const d of this.decoys) {
      if (!d.a || d.zone !== zone) continue;
      S.reset(); S.translate(d.x, d.y, d.z); S.rotY(d.t * 3); R.drawPart(M.decoy, S.m(), 1, 1, 1, WHITE, 1);
      if (d.landed && d.ring > 0 && d.ring < 0.8) {
        const u = d.ring / 0.8, r = 1 + u * 5 * d.mul;
        S.reset(); S.translate(d.x, d.y + 0.05, d.z); R.blend(true);
        R.drawPart(M.glowCyl, S.m(), r * 2, 0.02, r * 2, [1, 0.8, 0.3], (1 - u) * 0.35); R.blend(false);
      }
    }
    for (const t of this.tracers) {
      if (!t.a) continue;
      const dx = t.x1 - t.x0, dy = t.y1 - t.y0, dz = t.z1 - t.z0, len = Math.hypot(dx, dy, dz);
      if (len < 0.1) continue;
      S.reset(); S.translate((t.x0 + t.x1) / 2, (t.y0 + t.y1) / 2, (t.z0 + t.z1) / 2);
      S.rotY(Math.atan2(dx, dz)); S.rotX(-Math.asin(dy / len));
      R.drawPart(M.glowBox, S.m(), 0.04, 0.04, len, [1, 0.9, 0.5], 1);
    }
  }
};

/* =====================================================================
   Recolectables: botiquines, adrenalina, munición y señuelos
   ===================================================================== */
const Pickups = {
  list: [], t: 0,
  init() { PICKUPS.forEach((p, i) => this.list.push({ i: 80 + i, id: p.id, t: p.t, x: p.x, z: p.z, zone: p.zone, y: p.zone < 0 ? World.heightAt(p.x, p.z) : 0, got: false, vN: 0 })); },
  reset(collected) { for (const p of this.list) p.got = !!(collected && collected.has(p.id)); },
  update(dt, P, G) {
    this.t += dt;
    for (const p of this.list) {
      if (p.got || p.zone !== P.zone) continue;
      if (Math.hypot(p.x - P.x, p.z - P.z) > 1.3 || Math.abs(p.y - P.y) > 1.6) continue;
      if (p.t === 'ammo' && !G.ch.heavy) { if (G.msgCd <= 0) { Hooks.msg('Munición pesada: tú no sabes usarla'); G.msgCd = 3; } continue; }
      p.got = true; G.collected.add(p.id);
      if (p.t === 'med') { G.med++; Hooks.msg('Botiquín recogido'); }
      else if (p.t === 'adr') { G.adr++; Hooks.msg('Inyector de adrenalina recogido'); }
      else if (p.t === 'ammo') { G.ammo += 12; Hooks.msg('Munición +12'); }
      else { G.decoy += 2; Hooks.msg('Señuelos +2'); }
    }
  },
  draw(R, S, M, cam, frame, P) {
    for (const p of this.list) {
      if (p.got || p.zone !== P.zone) continue;
      const y = p.y + 0.55 + Math.sin(this.t * 2 + p.i) * 0.08;
      if (P.zone < 0) { if (Math.hypot(p.x - cam.x, p.z - cam.z) > 70 || !World.visible(p, p.x, y, p.z, 0.6, cam, frame)) continue; }
      else if (!Frustum.sphere(p.x, y, p.z, 0.6)) continue;
      S.reset(); S.translate(p.x, y, p.z); S.rotY(this.t * 1.6 + p.i);
      R.drawPart(p.t === 'med' ? M.medkit : (p.t === 'adr' ? M.adren : (p.t === 'ammo' ? M.ammo : M.decoy)), S.m(), 1.6, 1.6, 1.6, WHITE, 1);
    }
  }
};

/* =====================================================================
   Actores: mallas de armas/objetos y reinicio de pools
   ===================================================================== */
const Actors = {
  M: {},
  init(R) {
    const b = new MeshBuilder(), M = this.M, C = Character.M;
    // el arma se construye hacia -y desde la mano (sigue la dirección del antebrazo)
    b.reset();
    addBox(b, 0, -0.13, 0, 0.035, 0.13, 0.035, 0, [0.25, 0.16, 0.1], 0);       // mango
    addBox(b, 0, -0.145, 0, 0.012, 0.015, 0.085, 0, [0.4, 0.4, 0.42], 0);      // guarda
    addBox(b, 0, -0.62, 0, 0.012, 0.48, 0.075, 0, [0.78, 0.8, 0.84], 0);       // hoja
    addBox(b, 0, -0.68, 0, 0.01, 0.06, 0.05, 0, [0.78, 0.8, 0.84], 0);         // punta
    M.machete = R.makeMesh(b);
    b.reset();
    addBox(b, 0, -0.5, 0, 0.05, 0.5, 0.07, 0, [0.22, 0.24, 0.22], 0);          // cuerpo
    addBox(b, 0, -0.85, 0, 0.025, 0.35, 0.025, 0, [0.12, 0.12, 0.14], 0);      // cañón
    addBox(b, 0, 0, 0, 0.05, 0.22, 0.08, 0, [0.3, 0.22, 0.16], 0);             // culata
    addBox(b, 0, -0.42, 0.08, 0.04, 0.14, 0.05, 0, [0.15, 0.15, 0.16], 0);     // cargador
    M.rifle = R.makeMesh(b);
    b.reset(); addCyl(b, 0, 0, 0, 0.05, 0.05, 0.11, 8, [0.7, 0.7, 0.72], 0); addCyl(b, 0, 0.04, 0, 0.053, 0.053, 0.03, 8, [0.85, 0.25, 0.2], 0); M.decoy = R.makeMesh(b);
    b.reset(); addBox(b, 0, 0, 0, 0.28, 0.2, 0.12, 0, [0.95, 0.95, 0.95], 1); addBox(b, 0, 0.02, 0, 0.14, 0.16, 0.125, 0, [0.85, 0.15, 0.15], 1); addBox(b, 0, 0.08, 0, 0.05, 0.06, 0.126, 0, [0.85, 0.15, 0.15], 1); M.medkit = R.makeMesh(b);
    b.reset(); addCyl(b, 0, 0, 0, 0.04, 0.04, 0.2, 8, [0.2, 0.9, 0.9], 1); addCyl(b, 0, 0.2, 0, 0.012, 0.012, 0.1, 6, [1, 1, 1], 1); M.adren = R.makeMesh(b);
    b.reset(); addBox(b, 0, 0, 0, 0.26, 0.16, 0.14, 0, [0.35, 0.6, 0.3], 1); addBox(b, 0, 0.06, 0, 0.27, 0.03, 0.15, 0, [0.95, 0.8, 0.2], 1); M.ammo = R.makeMesh(b);
    b.reset(); addBox(b, 0, -0.5, 0, 1, 1, 1, 0, WHITE, 1); M.glowBox = R.makeMesh(b);
    b.reset(); addCyl(b, 0, -0.5, 0, 0.5, 0.5, 1, 14, WHITE, 1); M.glowCyl = R.makeMesh(b);
    Character.W = { machete: M.machete, rifle: M.rifle };
    Body.init(C); Pieces.init(); Zombies.init(); Npcs.init(); Proj.init(); Pickups.init();
  },
  reset() { Zombies.clear(); Pieces.clear(); Proj.clear(); Noise.level = 0; }
};
