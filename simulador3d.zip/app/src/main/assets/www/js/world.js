'use strict';
/* =====================================================================
   world.js — mundo infinito por celdas, objetos reutilizados, colisiones 3D simples
   ===================================================================== */
const CELL = 24, HALF = 12, LOAD_R = 2, KEEP_R = 3;
const cellOf = v => Math.floor((v + HALF) / CELL);

function hash3(a, b, c) {
  let h = (Math.imul(a | 0, 0x27d4eb2d) ^ Math.imul(b | 0, 0x165667b1) ^ Math.imul(c | 0, 0x9e3779b1)) | 0;
  h = Math.imul(h ^ (h >>> 15), 0x85ebca6b);
  h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}
function rng(seed) {
  let t = seed >>> 0;
  return function () {
    t += 0x6D2B79F5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

const COL = {
  grass: rgb(0x35703a), grass2: rgb(0x2c6032), stone: rgb(0x6b6b78), stone2: rgb(0x5a5a66),
  trunk: rgb(0x6b4a2f), leaf: rgb(0x2f8f45), pine: rgb(0x1f6b3b), rock: rgb(0x80808c), bush: rgb(0x3f9a4a),
  wood: rgb(0x8a5a35), wood2: rgb(0x5e3d24), pole: rgb(0x2a2a33), warm: rgb(0xffd27a),
  walls: [rgb(0xd9c8a9), rgb(0xc9b3a0), rgb(0xb8c4cf), rgb(0xcfd8b5)],
  roofs: [rgb(0x9b3b32), rgb(0x6d4b8a), rgb(0x3b6f8f)],
  door: rgb(0x3a2a22), mirror: rgb(0xaee7ff), gold: rgb(0xffcf4a),
  flowers: [rgb(0xff6f91), rgb(0xffd166), rgb(0xffffff), rgb(0x9b8cff)]
};

/** Puntos interactivos (rot = 0 para que el collider AABB sea exacto). */
const INTERACTIVES = [
  { id: 'mirror', name: 'Espejo · Personaje', x: 4, z: -5, col: 0x59d8c8 },
  { id: 'lamp', name: 'Farol · Día / Noche', x: -6, z: 5, col: 0xffc857 },
  { id: 'chest', name: 'Cofre', x: 15, z: 5, col: 0xd85c9e }
];
const STEPS = { x: -4, z: -9 }; // escalones para practicar el salto
const KEEPOUTS = [{ x: 0, z: 0, r: 5.5 }, { x: STEPS.x, z: STEPS.z - 1.4, r: 5 }]
  .concat(INTERACTIVES.map(i => ({ x: i.x, z: i.z, r: 3 })));

function addCircle(cell, x, z, r, top) {
  let c = cell.cols[cell.nc];
  if (!c) { c = { t: 0, x: 0, z: 0, r: 0, x0: 0, x1: 0, z0: 0, z1: 0, top: 0 }; cell.cols[cell.nc] = c; }
  c.t = 0; c.x = x; c.z = z; c.r = r; c.top = top; cell.nc++;
}
function addBoxCol(cell, x0, x1, z0, z1, top) {
  let c = cell.cols[cell.nc];
  if (!c) { c = { t: 0, x: 0, z: 0, r: 0, x0: 0, x1: 0, z0: 0, z1: 0, top: 0 }; cell.cols[cell.nc] = c; }
  c.t = 1; c.x0 = x0; c.x1 = x1; c.z0 = z0; c.z1 = z1; c.top = top; cell.nc++;
}

/** Genera la malla fusionada y los colliders de una celda (determinista por coordenadas). */
function buildCell(cell) {
  const b = World.builder; b.reset(); cell.nc = 0;
  const cx = cell.cx, cz = cell.cz, ox = cx * CELL, oz = cz * CELL;
  const R = rng((Math.imul(cx, 73856093) ^ Math.imul(cz, 19349663) ^ 0x51ed270b) >>> 0);

  // Suelo en 6×6 parcelas (plaza de piedra alrededor del origen)
  const n = 6, st = CELL / n;
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
    const x0 = ox - HALF + i * st, z0 = oz - HALF + j * st, x1 = x0 + st, z1 = z0 + st;
    let c;
    if (Math.hypot(x0 + st / 2, z0 + st / 2) < 10) c = ((i + j) & 1) ? COL.stone : COL.stone2;
    else c = shade(((i * 7 + j * 3 + cx * 5 + cz * 11) & 1) ? COL.grass : COL.grass2, 0.92 + 0.16 * hash3(cx * 6 + i, cz * 6 + j, 7));
    b.quad([x0, 0, z0], [x1, 0, z0], [x1, 0, z1], [x0, 0, z1], 0, 1, 0, c, 0);
  }

  const placed = [];
  const keep = (x, z, r) => { for (const k of KEEPOUTS) if (Math.hypot(x - k.x, z - k.z) < k.r + r) return true; return false; };
  const place = r => {
    for (let t = 0; t < 6; t++) {
      const x = ox - HALF + r + 0.5 + R() * (CELL - 2 * r - 1), z = oz - HALF + r + 0.5 + R() * (CELL - 2 * r - 1);
      if (keep(x, z, r)) continue;
      let ok = true;
      for (let k = 0; k < placed.length; k += 3) if (Math.hypot(x - placed[k], z - placed[k + 1]) < r + placed[k + 2] + 0.5) { ok = false; break; }
      if (ok) { placed.push(x, z, r); return [x, z]; }
    }
    return null;
  };

  const count = 8 + Math.floor(R() * 4);
  for (let k = 0; k < count; k++) {
    const t = R();
    let p;
    if (t < 0.30) { // árbol
      if (!(p = place(1.2))) continue;
      const s = 0.8 + R() * 0.6, lf = shade(COL.leaf, 0.8 + R() * 0.4);
      addCyl(b, p[0], 0, p[1], 0.22 * s, 0.16 * s, 2.0 * s, 6, COL.trunk, 0);
      addCyl(b, p[0], 1.5 * s, p[1], 1.5 * s, 0, 2.2 * s, 7, lf, 0);
      addCyl(b, p[0], 2.6 * s, p[1], 1.1 * s, 0, 1.8 * s, 7, shade(lf, 1.12), 0);
      addCircle(cell, p[0], p[1], 0.4 * s, 99);
    } else if (t < 0.46) { // pino
      if (!(p = place(1.1))) continue;
      const s = 0.9 + R() * 0.7, pn = shade(COL.pine, 0.85 + R() * 0.3);
      addCyl(b, p[0], 0, p[1], 0.2 * s, 0.15 * s, 1.2 * s, 6, COL.trunk, 0);
      addCyl(b, p[0], 0.9 * s, p[1], 1.3 * s, 0, 1.8 * s, 7, pn, 0);
      addCyl(b, p[0], 1.9 * s, p[1], 1.0 * s, 0, 1.6 * s, 7, shade(pn, 1.1), 0);
      addCyl(b, p[0], 2.8 * s, p[1], 0.7 * s, 0, 1.4 * s, 7, shade(pn, 1.2), 0);
      addCircle(cell, p[0], p[1], 0.35 * s, 99);
    } else if (t < 0.58) { // roca
      if (!(p = place(1.0))) continue;
      const s = 0.7 + R() * 0.8;
      addSphere(b, p[0], 0.3 * s, p[1], 0.9 * s, 0.6 * s, 0.8 * s, 6, 4, shade(COL.rock, 0.85 + R() * 0.3), 0);
      addCircle(cell, p[0], p[1], 0.75 * s, 0.85 * s);
    } else if (t < 0.68) { // arbusto
      if (!(p = place(0.8))) continue;
      const s = 0.8 + R() * 0.5;
      addSphere(b, p[0], 0.35 * s, p[1], 0.8 * s, 0.55 * s, 0.8 * s, 7, 4, shade(COL.bush, 0.85 + R() * 0.3), 0);
      addCircle(cell, p[0], p[1], 0.65 * s, 0.85 * s);
    } else if (t < 0.77) { // caja (saltable)
      if (!(p = place(0.8))) continue;
      addBox(b, p[0], 0, p[1], 0.9, 0.9, 0.9, 0, COL.wood, 0);
      addBox(b, p[0], 0.9, p[1], 0.96, 0.06, 0.96, 0, COL.wood2, 0);
      addBoxCol(cell, p[0] - 0.45, p[0] + 0.45, p[1] - 0.45, p[1] + 0.45, 0.96);
    } else if (t < 0.84) { // farola decorativa (brilla de noche)
      if (!(p = place(0.6))) continue;
      addCyl(b, p[0], 0, p[1], 0.09, 0.07, 3.2, 6, COL.pole, 0);
      addSphere(b, p[0], 3.4, p[1], 0.28, 0.3, 0.28, 6, 4, COL.warm, 0.5);
      addCircle(cell, p[0], p[1], 0.2, 99);
    } else if (t < 0.90) { // banco (saltable)
      if (!(p = place(1.1))) continue;
      const rot = R() < 0.5 ? 0 : Math.PI / 2, w = rot === 0 ? 1.6 : 0.5, d = rot === 0 ? 0.5 : 1.6;
      addBox(b, p[0], 0.36, p[1], 1.6, 0.1, 0.5, rot, COL.wood, 0);
      addBox(b, p[0], 0, p[1], 1.5, 0.36, 0.4, rot, COL.wood2, 0);
      addBoxCol(cell, p[0] - w / 2, p[0] + w / 2, p[1] - d / 2, p[1] + d / 2, 0.46);
    } else if (t < 0.95) { // pilar en ruinas
      if (!(p = place(0.9))) continue;
      addCyl(b, p[0], 0, p[1], 0.45, 0.4, 2.2, 8, shade(COL.stone, 1.2), 0);
      addBox(b, p[0], 2.2, p[1], 1.0, 0.25, 1.0, 0.4, shade(COL.stone, 1.3), 0);
      addCircle(cell, p[0], p[1], 0.5, 99);
    } else { // casa
      const w = 4 + R() * 2.5, d = 4 + R() * 2;
      if (!(p = place(Math.max(w, d) * 0.62))) continue;
      const wall = COL.walls[Math.floor(R() * COL.walls.length)], roof = COL.roofs[Math.floor(R() * COL.roofs.length)];
      addBox(b, p[0], 0, p[1], w, 2.6, d, 0, wall, 0);
      addCyl(b, p[0], 2.6, p[1], Math.max(w, d) * 0.74, 0, 1.8, 4, roof, 0, Math.PI / 4);
      addBox(b, p[0], 0, p[1] + d / 2 + 0.03, 0.9, 1.7, 0.08, 0, COL.door, 0);
      addBox(b, p[0] - w * 0.28, 1.2, p[1] + d / 2 + 0.02, 0.7, 0.6, 0.06, 0, COL.warm, 0.5);
      addBox(b, p[0] + w * 0.28, 1.2, p[1] + d / 2 + 0.02, 0.7, 0.6, 0.06, 0, COL.warm, 0.5);
      addBoxCol(cell, p[0] - w / 2, p[0] + w / 2, p[1] - d / 2, p[1] + d / 2, 2.6);
    }
  }

  // Flores decorativas (sin colisión)
  for (let k = 0; k < 7; k++) {
    const x = ox - HALF + R() * CELL, z = oz - HALF + R() * CELL;
    if (keep(x, z, 0)) continue;
    const c = COL.flowers[Math.floor(R() * COL.flowers.length)];
    addBox(b, x, 0, z, 0.14, 0.18, 0.14, R() * 3, c, 0);
  }

  // Puntos interactivos de esta celda
  for (const it of INTERACTIVES) {
    if (cellOf(it.x) !== cx || cellOf(it.z) !== cz) continue;
    const bc = rgb(it.col);
    addCyl(b, it.x + 1.1, 0, it.z, 0.05, 0.05, 5.5, 5, bc, 1);       // baliza
    addSphere(b, it.x + 1.1, 5.7, it.z, 0.2, 0.28, 0.2, 5, 4, bc, 1);
    if (it.id === 'mirror') {
      addBox(b, it.x, 0, it.z, 1.3, 0.12, 0.5, 0, COL.wood2, 0);
      addBox(b, it.x, 0.12, it.z, 1.1, 2.0, 0.12, 0, COL.wood, 0);
      addBox(b, it.x, 0.22, it.z + 0.07, 0.9, 1.8, 0.04, 0, COL.mirror, 1);
      addBoxCol(cell, it.x - 0.65, it.x + 0.65, it.z - 0.25, it.z + 0.25, 2.1);
    } else if (it.id === 'lamp') {
      addCyl(b, it.x, 0, it.z, 0.3, 0.22, 0.3, 8, COL.pole, 0);
      addCyl(b, it.x, 0.3, it.z, 0.09, 0.07, 3.2, 6, COL.pole, 0);
      addSphere(b, it.x, 3.6, it.z, 0.34, 0.38, 0.34, 7, 5, COL.warm, 0.5);
      addCircle(cell, it.x, it.z, 0.3, 99);
    } else if (it.id === 'chest') {
      addBox(b, it.x, 0, it.z, 1.0, 0.5, 0.62, 0, COL.wood, 0);
      addBox(b, it.x - 0.3, 0, it.z, 0.08, 0.52, 0.64, 0, COL.pole, 0);
      addBox(b, it.x + 0.3, 0, it.z, 0.08, 0.52, 0.64, 0, COL.pole, 0);
      if (World.state.chestOpen) {
        addBox(b, it.x, 0.5, it.z, 0.9, 0.1, 0.5, 0, COL.gold, 1);
        addSphere(b, it.x, 1.0, it.z, 0.16, 0.2, 0.16, 6, 4, COL.gold, 1);
      } else {
        addBox(b, it.x, 0.5, it.z, 1.04, 0.18, 0.66, 0, COL.wood2, 0);
      }
      addBoxCol(cell, it.x - 0.5, it.x + 0.5, it.z - 0.31, it.z + 0.31, 0.5);
    }
  }
  // Escalones de práctica
  if (cellOf(STEPS.x) === cx && cellOf(STEPS.z) === cz) {
    for (let i = 0; i < 3; i++) {
      const z = STEPS.z - i * 1.4, h = 0.35 * (i + 1);
      addBox(b, STEPS.x, 0, z, 2.6, h, 1.4, 0, shade(COL.stone, 1.1 + i * 0.08), 0);
      addBoxCol(cell, STEPS.x - 1.3, STEPS.x + 1.3, z - 0.7, z + 0.7, h);
    }
  }

  cell.mesh.upload(b.data(), b.n);
}

const World = {
  cells: new Map(), pool: [], queue: [], builder: new MeshBuilder(), R: null,
  state: { chestOpen: false },
  init(R) { this.R = R; },
  key(cx, cz) { return (cx + 4096) * 8192 + (cz + 4096); },
  count() { let n = 0; for (const c of this.cells.values()) if (c.ready) n++; return n; },
  total() { return (LOAD_R * 2 + 1) * (LOAD_R * 2 + 1); },

  /** Activa celdas cercanas, descarta lejanas (reusa buffers) y construye con presupuesto de tiempo. */
  update(px, pz, budgetMs) {
    const pcx = cellOf(px), pcz = cellOf(pz);
    // 1) liberar lejanas al pool  2) activar cercanas reutilizando buffers del pool
    for (const [k, cell] of this.cells) {
      if (Math.max(Math.abs(cell.cx - pcx), Math.abs(cell.cz - pcz)) > KEEP_R) {
        this.cells.delete(k); cell.ready = false; cell.queued = false; cell.mesh.n = 0; cell.nc = 0; this.pool.push(cell);
      }
    }
    for (let dz = -LOAD_R; dz <= LOAD_R; dz++) for (let dx = -LOAD_R; dx <= LOAD_R; dx++) {
      const k = this.key(pcx + dx, pcz + dz);
      if (!this.cells.has(k)) {
        const cell = this.pool.pop() || { cx: 0, cz: 0, key: 0, mesh: this.R.newMesh(), cols: [], nc: 0, ready: false, queued: false };
        cell.cx = pcx + dx; cell.cz = pcz + dz; cell.key = k; cell.ready = false; cell.queued = true; cell.nc = 0;
        this.cells.set(k, cell); this.queue.push(cell);
      }
    }
    if (this.queue.length) {
      if (this.queue.length > 1) {
        this.queue.sort((a, b) => ((a.cx - pcx) ** 2 + (a.cz - pcz) ** 2) - ((b.cx - pcx) ** 2 + (b.cz - pcz) ** 2));
      }
      const t0 = performance.now();
      while (this.queue.length) {
        const c = this.queue.shift();
        if (!c.queued || this.cells.get(c.key) !== c) continue;
        buildCell(c); c.ready = true; c.queued = false;
        if (performance.now() - t0 > budgetMs) break;
      }
    }
  },

  /** Reconstruye la celda que contiene (x,z), p. ej. al abrir el cofre. */
  refreshAt(x, z) {
    const c = this.cells.get(this.key(cellOf(x), cellOf(z)));
    if (c && !c.queued) { c.queued = true; this.queue.unshift(c); }
  },

  draw(R, cam) {
    for (const cell of this.cells.values()) {
      if (!cell.ready || !cell.mesh.n) continue;
      const dx = cell.cx * CELL - cam.x, dz = cell.cz * CELL - cam.z, d = Math.hypot(dx, dz);
      if (d > CELL * 0.9 && (dx * cam.fx + dz * cam.fz) / d < -0.1) continue; // detrás de la cámara
      R.drawMesh(cell.mesh);
    }
  },

  nearest(px, pz) {
    let best = null, bd = 2.8;
    for (const it of INTERACTIVES) {
      const d = Math.hypot(px - it.x, pz - it.z);
      if (d < bd) { bd = d; best = it; }
    }
    return best;
  },

  /** Colisiones: círculos y cajas con altura. Escalón automático hasta 0.42 m; salto para lo más alto. */
  resolve(p) {
    const RAD = 0.32, STEP = 0.42;
    const pcx = cellOf(p.x), pcz = cellOf(p.z);
    let support = 0;
    for (let pass = 0; pass < 2; pass++) {
      support = 0;
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        const cell = this.cells.get(this.key(pcx + dx, pcz + dz));
        if (!cell || !cell.ready) continue;
        const cols = cell.cols;
        for (let i = 0; i < cell.nc; i++) {
          const c = cols[i];
          let nx = 0, nz = 0, pen = 0;
          if (c.t === 0) {
            const ddx = p.x - c.x, ddz = p.z - c.z, d = Math.hypot(ddx, ddz), lim = c.r + RAD;
            if (d >= lim) continue;
            if (p.y + STEP >= c.top) { if (c.top > support) support = c.top; continue; }
            if (d < 1e-6) { nx = 1; pen = lim; } else { nx = ddx / d; nz = ddz / d; pen = lim - d; }
          } else {
            const qx = Math.min(Math.max(p.x, c.x0), c.x1), qz = Math.min(Math.max(p.z, c.z0), c.z1);
            const ddx = p.x - qx, ddz = p.z - qz, d2 = ddx * ddx + ddz * ddz;
            if (d2 >= RAD * RAD) continue;
            if (p.y + STEP >= c.top) { if (c.top > support) support = c.top; continue; }
            if (d2 > 1e-10) { const d = Math.sqrt(d2); nx = ddx / d; nz = ddz / d; pen = RAD - d; }
            else {
              const l = p.x - c.x0, r = c.x1 - p.x, t = p.z - c.z0, bt = c.z1 - p.z, m = Math.min(l, r, t, bt);
              if (m === l) { nx = -1; pen = l + RAD; } else if (m === r) { nx = 1; pen = r + RAD; }
              else if (m === t) { nz = -1; pen = t + RAD; } else { nz = 1; pen = bt + RAD; }
            }
          }
          p.x += nx * pen; p.z += nz * pen;
          const vn = p.vx * nx + p.vz * nz;
          if (vn < 0) { p.vx -= vn * nx; p.vz -= vn * nz; }
        }
      }
    }
    if (p.y <= support && p.vy <= 0) { p.y = support; p.vy = 0; p.grounded = true; } else p.grounded = false;
    p.support = support;
  }
};
