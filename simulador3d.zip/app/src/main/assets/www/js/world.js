'use strict';
/* =====================================================================
   world.js — mundo por celdas (3 LOD), frustum + oclusión, streaming con pool,
   colisiones deslizantes sobre relieve e interiores.  El contenido del mapa está en sectors.js
   ===================================================================== */
const CELL = 24, HALF = 12, GRID_R = 8, LIM = 198;
const LOAD_R = 4.4, KEEP_R = 5.7;           // radio de carga / descarga (en celdas)
const LOD0_D = 36, LOD1_D = 74, LOD2_D = 118; // distancias de nivel de detalle (m); más allá: niebla de horizonte
const cellOf = v => Math.floor((v + HALF) / CELL);

function hash3(a, b, c) {
  let h = (Math.imul(a | 0, 0x27d4eb2d) ^ Math.imul(b | 0, 0x165667b1) ^ Math.imul(c | 0, 0x9e3779b1)) | 0;
  h = Math.imul(h ^ (h >>> 15), 0x85ebca6b);
  h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}
function rng(seed) {
  let t = seed >>> 0;
  return function () {
    t += 0x6D2B79F5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}
function smooth(a, b, x) { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); }

/* ---------- colisionadores (círculos y cajas con base y tope absolutos) ---------- */
function newCol() { return { t: 0, x: 0, z: 0, r: 0, x0: 0, x1: 0, z0: 0, z1: 0, top: 0, bot: 0, s: false }; }
function addCircleCol(cell, x, z, r, top, bot) {
  let c = cell.cols[cell.nc]; if (!c) { c = newCol(); cell.cols[cell.nc] = c; }
  c.t = 0; c.x = x; c.z = z; c.r = r; c.top = top; c.bot = bot || 0; c.s = false; cell.nc++;
}
function addBoxCol(cell, x0, x1, z0, z1, top, bot, sight) {
  let c = cell.cols[cell.nc]; if (!c) { c = newCol(); cell.cols[cell.nc] = c; }
  c.t = 1; c.x0 = x0; c.x1 = x1; c.z0 = z0; c.z1 = z1; c.top = top; c.bot = bot || 0; c.s = !!sight; cell.nc++;
}
/** Volumen oclusor (edificio, muro alto): se usa para ocultar lo que queda detrás. */
function addOcc(cell, x0, x1, z0, z1, top) {
  let o = cell.occ[cell.nocc]; if (!o) { o = [0, 0, 0, 0, 0]; cell.occ[cell.nocc] = o; }
  o[0] = x0; o[1] = x1; o[2] = z0; o[3] = z1; o[4] = top; cell.nocc++;
}
function tY(cell, y) { if (y < cell.minY) cell.minY = y; if (y > cell.maxY) cell.maxY = y; }

/** Resuelve colisiones deslizantes contra una lista; devuelve el apoyo más alto alcanzable (escalones/cajas). */
function collideList(p, cols, nc, RAD, STEP, sup) {
  for (let i = 0; i < nc; i++) {
    const c = cols[i];
    if (p.y + 1.8 <= c.bot) continue;
    let nx = 0, nz = 0, pen = 0;
    if (c.t === 0) {
      const ddx = p.x - c.x, ddz = p.z - c.z, lim = c.r + RAD, d2 = ddx * ddx + ddz * ddz;
      if (d2 >= lim * lim) continue;
      if (p.y + STEP >= c.top) { if (c.top > sup) sup = c.top; continue; }
      const d = Math.sqrt(d2);
      if (d < 1e-6) { nx = 1; pen = lim; } else { nx = ddx / d; nz = ddz / d; pen = lim - d; }
    } else {
      const qx = Math.min(Math.max(p.x, c.x0), c.x1), qz = Math.min(Math.max(p.z, c.z0), c.z1);
      const ddx = p.x - qx, ddz = p.z - qz, d2 = ddx * ddx + ddz * ddz;
      if (d2 >= RAD * RAD) continue;
      if (p.y + STEP >= c.top) { if (c.top > sup) sup = c.top; continue; }
      if (d2 > 1e-10) { const d = Math.sqrt(d2); nx = ddx / d; nz = ddz / d; pen = RAD - d; }
      else {
        const l = p.x - c.x0, r = c.x1 - p.x, t = p.z - c.z0, b = c.z1 - p.z, m = Math.min(l, r, t, b);
        if (m === l) { nx = -1; pen = l + RAD; } else if (m === r) { nx = 1; pen = r + RAD; }
        else if (m === t) { nz = -1; pen = t + RAD; } else { nz = 1; pen = b + RAD; }
      }
    }
    p.x += nx * pen; p.z += nz * pen;
    const vn = (p.vx || 0) * nx + (p.vz || 0) * nz;
    if (vn < 0) { p.vx -= vn * nx; p.vz -= vn * nz; }
  }
  return sup;
}
function segRect(ax, az, bx, bz, x0, x1, z0, z1) {
  let t0 = 0, t1 = 1; const dx = bx - ax, dz = bz - az;
  if (Math.abs(dx) < 1e-9) { if (ax < x0 || ax > x1) return false; }
  else { let a = (x0 - ax) / dx, b = (x1 - ax) / dx; if (a > b) { const t = a; a = b; b = t; } if (a > t0) t0 = a; if (b < t1) t1 = b; if (t0 > t1) return false; }
  if (Math.abs(dz) < 1e-9) { if (az < z0 || az > z1) return false; }
  else { let a = (z0 - az) / dz, b = (z1 - az) / dz; if (a > b) { const t = a; a = b; b = t; } if (a > t0) t0 = a; if (b < t1) t1 = b; if (t0 > t1) return false; }
  return true;
}

/** Genera las 3 mallas (LOD0/1/2) y los colisionadores de una celda (determinista por coordenadas). */
function buildCell(cell) {
  const B = World.B;
  for (let i = 0; i < 3; i++) B[i].reset();
  cell.nc = 0; cell.nocc = 0; cell.minY = 1e9; cell.maxY = -1e9;
  genCell(cell, B);
  for (let i = 0; i < 3; i++) cell.mesh[i].upload(B[i].data(), B[i].n);
  cell.verts = B[0].n;
}

const _OCC_PTS = [[0, 0], [-9, -9], [9, -9], [-9, 9], [9, 9]];

const World = {
  cells: new Map(), pool: [], queue: [], R: null, B: null,
  occ: new Float32Array(5 * 256), nocc: 0, occDirty: true,
  stats: { drawn: 0, culled: 0, occl: 0, verts: 0, lod: [0, 0, 0] },
  init(R) { this.R = R; this.B = [new MeshBuilder(), new MeshBuilder(), new MeshBuilder()]; },
  key(cx, cz) { return (cx + 4096) * 8192 + (cz + 4096); },
  count() { let n = 0; for (const c of this.cells.values()) if (c.ready) n++; return n; },
  pending() { return this.queue.length; },
  heightAt(x, z) { return (x > 900 || z > 900) ? 0 : SECT.height(x, z); },
  cellLoaded(x, z) { const c = this.cells.get(this.key(cellOf(x), cellOf(z))); return !!(c && c.ready); },

  /** Descarga lejanas (reusa buffers vía pool) y activa cercanas; construye con presupuesto de tiempo. */
  update(px, pz, budgetMs) {
    const pcx = cellOf(px), pcz = cellOf(pz), R = Math.ceil(LOAD_R) + 1;
    for (const [k, c] of this.cells) {
      if (Math.hypot(c.cx * CELL - px, c.cz * CELL - pz) / CELL > KEEP_R) {
        this.cells.delete(k); c.ready = false; c.queued = false; c.nc = 0; c.nocc = 0;
        for (let i = 0; i < 3; i++) c.mesh[i].n = 0;
        this.pool.push(c); this.occDirty = true;
      }
    }
    for (let dz = -R; dz <= R; dz++) for (let dx = -R; dx <= R; dx++) {
      const cx = pcx + dx, cz = pcz + dz;
      if (Math.abs(cx) > GRID_R || Math.abs(cz) > GRID_R) continue;
      if (Math.hypot(cx * CELL - px, cz * CELL - pz) / CELL > LOAD_R) continue;
      const k = this.key(cx, cz);
      if (this.cells.has(k)) continue;
      const c = this.pool.pop() || { cx: 0, cz: 0, key: 0, mesh: [this.R.newMesh(), this.R.newMesh(), this.R.newMesh()], cols: [], occ: [], nc: 0, nocc: 0, minY: 0, maxY: 0, ready: false, queued: false, occN: 0, verts: 0 };
      c.cx = cx; c.cz = cz; c.key = k; c.ready = false; c.queued = true; c.nc = 0; c.nocc = 0; c.occN = 0;
      this.cells.set(k, c); this.queue.push(c);
    }
    if (this.queue.length) {
      if (this.queue.length > 1) this.queue.sort((a, b) => Math.hypot(a.cx * CELL - px, a.cz * CELL - pz) - Math.hypot(b.cx * CELL - px, b.cz * CELL - pz));
      const t0 = performance.now();
      while (this.queue.length) {
        const c = this.queue.shift();
        if (!c.queued || this.cells.get(c.key) !== c) continue;
        buildCell(c); c.ready = true; c.queued = false; this.occDirty = true;
        if (performance.now() - t0 > budgetMs) break;
      }
    }
  },

  /* ---------- oclusión ligera ---------- */
  rebuildOcc() {
    let n = 0;
    for (const c of this.cells.values()) {
      if (!c.ready) continue;
      for (let i = 0; i < c.nocc; i++) {
        if ((n + 1) * 5 > this.occ.length) { const a = new Float32Array(this.occ.length * 2); a.set(this.occ); this.occ = a; }
        const o = c.occ[i], b = n * 5;
        this.occ[b] = o[0]; this.occ[b + 1] = o[1]; this.occ[b + 2] = o[2]; this.occ[b + 3] = o[3]; this.occ[b + 4] = o[4]; n++;
      }
    }
    this.nocc = n; this.occDirty = false;
  },
  /** ¿El segmento cámara→punto atraviesa un volumen grande (edificio/muro) o una elevación del terreno antes de llegar? */
  rayBlocked(ex, ey, ez, qx, qy, qz) {
    const dx = qx - ex, dy = qy - ey, dz = qz - ez, o = this.occ;
    for (let i = 0; i < this.nocc; i++) {
      const b = i * 5, x0 = o[b], x1 = o[b + 1], z0 = o[b + 2], z1 = o[b + 3], top = o[b + 4];
      let t0 = 0, t1 = 1;
      if (Math.abs(dx) < 1e-9) { if (ex < x0 || ex > x1) continue; }
      else { let a = (x0 - ex) / dx, c = (x1 - ex) / dx; if (a > c) { const t = a; a = c; c = t; } if (a > t0) t0 = a; if (c < t1) t1 = c; if (t0 > t1) continue; }
      if (Math.abs(dz) < 1e-9) { if (ez < z0 || ez > z1) continue; }
      else { let a = (z0 - ez) / dz, c = (z1 - ez) / dz; if (a > c) { const t = a; a = c; c = t; } if (a > t0) t0 = a; if (c < t1) t1 = c; if (t0 > t1) continue; }
      if (Math.abs(dy) < 1e-9) { if (ey > top) continue; }
      else { let a = (-60 - ey) / dy, c = (top - ey) / dy; if (a > c) { const t = a; a = c; c = t; } if (a > t0) t0 = a; if (c < t1) t1 = c; if (t0 > t1) continue; }
      if (t1 < 0.985) return true; // sale del volumen antes de llegar al punto: está detrás
    }
    const len = Math.hypot(dx, dz), steps = Math.min(22, Math.ceil(len / 5));
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      if (ey + dy * t < this.heightAt(ex + dx * t, ez + dz * t) - 0.2) return true; // cerro de por medio
    }
    return false;
  },
  /** Celda oculta solo si TODOS sus puntos de muestra (5) están tapados. */
  cellOccluded(c, cam) {
    const x = c.cx * CELL, z = c.cz * CELL, y = c.maxY + 1;
    for (let i = 0; i < 5; i++) if (!this.rayBlocked(cam.x, cam.ey, cam.z, x + _OCC_PTS[i][0], y, z + _OCC_PTS[i][1])) return false;
    return true;
  },
  /** Visibilidad de una entidad: frustum + oclusión (reevaluada cada 3 frames, con histéresis). */
  visible(o, x, y, z, r, cam, frame) {
    if (!Frustum.sphere(x, y, z, r)) return false;
    if ((frame + (o.i | 0)) % 3 === 0) {
      const hid = Math.hypot(x - cam.x, z - cam.z) > 14 && this.rayBlocked(cam.x, cam.ey, cam.z, x, y, z);
      o.vN = hid ? Math.min(3, (o.vN | 0) + 1) : 0;
    }
    return (o.vN | 0) < 2;
  },

  /** Dibuja celdas: frustum culling → oclusión → LOD por distancia (más allá del radio máximo: oculto bajo la niebla). */
  draw(R, cam, frame) {
    const st = this.stats; st.drawn = 0; st.culled = 0; st.occl = 0; st.verts = 0; st.lod[0] = st.lod[1] = st.lod[2] = 0;
    if (this.occDirty) this.rebuildOcc();
    const doOcc = frame % 3 === 0;
    for (const c of this.cells.values()) {
      if (!c.ready) continue;
      const cx = c.cx * CELL, cz = c.cz * CELL, d = Math.hypot(cx - cam.x, cz - cam.z);
      if (d > LOD2_D) { st.culled++; continue; }
      if (!Frustum.aabb(cx - HALF - 4, c.minY - 4, cz - HALF - 4, cx + HALF + 4, c.maxY + 1, cz + HALF + 4)) { st.culled++; continue; }
      if (doOcc) { const hid = d > LOD0_D * 0.9 && this.cellOccluded(c, cam); c.occN = hid ? Math.min(3, c.occN + 1) : 0; }
      if (c.occN >= 2) { st.occl++; continue; }
      const lod = d < LOD0_D ? 0 : (d < LOD1_D ? 1 : 2);
      R.drawMesh(c.mesh[lod]); st.drawn++; st.lod[lod]++; st.verts += c.mesh[lod].n;
    }
  },

  /* ---------- colisiones ---------- */
  resolve(p) {
    if (p.zone >= 0) { Interiors.resolve(p); return; }
    const RAD = 0.32, STEP = 0.45, pcx = cellOf(p.x), pcz = cellOf(p.z);
    let support = 0;
    for (let pass = 0; pass < 2; pass++) {
      support = this.heightAt(p.x, p.z);
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        const cell = this.cells.get(this.key(pcx + dx, pcz + dz));
        if (cell && cell.ready) support = collideList(p, cell.cols, cell.nc, RAD, STEP, support);
      }
    }
    p.x = Math.min(LIM, Math.max(-LIM, p.x)); p.z = Math.min(LIM, Math.max(-LIM, p.z));
    if (p.vy <= 0 && p.y <= support + 0.01) { p.y = support; p.vy = 0; p.grounded = true; }
    else if (p.grounded && p.vy <= 0 && p.y - support < 0.4) { p.y = support; p.grounded = true; } // pegado al suelo en bajadas
    else p.grounded = false;
    p.support = support;
  },
  /** Línea de visión horizontal bloqueada por muros/edificios (solo cajas marcadas como bloqueo de vista). */
  segBlocked(ax, az, bx, bz) {
    const c0x = cellOf(Math.min(ax, bx) - 1), c1x = cellOf(Math.max(ax, bx) + 1), c0z = cellOf(Math.min(az, bz) - 1), c1z = cellOf(Math.max(az, bz) + 1);
    for (let cx = c0x; cx <= c1x; cx++) for (let cz = c0z; cz <= c1z; cz++) {
      const cell = this.cells.get(this.key(cx, cz));
      if (!cell || !cell.ready) continue;
      for (let i = 0; i < cell.nc; i++) {
        const c = cell.cols[i];
        if (c.t === 1 && c.s && segRect(ax, az, bx, bz, c.x0, c.x1, c.z0, c.z1)) return true;
      }
    }
    return false;
  },
  pointSolid(x, y, z) {
    if (y < this.heightAt(x, z) + 0.12) return true;
    const cell = this.cells.get(this.key(cellOf(x), cellOf(z)));
    if (!cell) return false;
    for (let i = 0; i < cell.nc; i++) {
      const c = cell.cols[i];
      if (c.t === 1 && x > c.x0 - 0.15 && x < c.x1 + 0.15 && z > c.z0 - 0.15 && z < c.z1 + 0.15 && y < c.top && y > c.bot) return true;
    }
    return false;
  },
  /** Cámara de 3ª persona: fracción del recorrido target→ojo antes de chocar con terreno o edificios. */
  camClip(tx, ty, tz, ex, ey, ez) {
    for (let i = 1; i <= 10; i++) {
      const t = i / 10;
      if (this.pointSolid(tx + (ex - tx) * t, ty + (ey - ty) * t, tz + (ez - tz) * t)) return Math.max(0.12, (i - 1) / 10);
    }
    return 1;
  },
  /** ¿Hay espacio libre para colocar algo con radio r en (x,z)? (spawns) */
  free(x, z, r) {
    const cell = this.cells.get(this.key(cellOf(x), cellOf(z)));
    if (!cell || !cell.ready) return false;
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      const c2 = this.cells.get(this.key(cell.cx + dx, cell.cz + dz));
      if (!c2 || !c2.ready) continue;
      for (let i = 0; i < c2.nc; i++) {
        const c = c2.cols[i];
        if (c.t === 0) { if (Math.hypot(x - c.x, z - c.z) < c.r + r) return false; }
        else if (x > c.x0 - r && x < c.x1 + r && z > c.z0 - r && z < c.z1 + r && c.top > this.heightAt(x, z) + 0.5) return false;
      }
    }
    return true;
  }
};

/* =====================================================================
   Interiores: salas independientes lejos del mapa exterior (el exterior no se dibuja dentro)
   ===================================================================== */
const Interiors = {
  list: [],
  init(R) {
    this.list.length = 0;
    for (const def of INT_DEFS) {
      const b = new MeshBuilder(), cols = [], ox = def.ox, oz = def.oz, w = def.w, d = def.d, h = def.h;
      // u,v = centro del elemento en coordenadas de la sala; y = base
      const ib = (u, y, v, ww, hh, dd, col, solid, em) => {
        addBox(b, ox + u, y, oz + v, ww, hh, dd, 0, col, em || 0);
        if (solid) cols.push({ t: 1, x: 0, z: 0, r: 0, x0: ox + u - ww / 2, x1: ox + u + ww / 2, z0: oz + v - dd / 2, z1: oz + v + dd / 2, top: y + hh, bot: y, s: false });
      };
      ib(w / 2, -0.2, d / 2, w + 1, 0.2, d + 1, def.floor, false);   // piso
      ib(w / 2, h, d / 2, w + 1, 0.3, d + 1, def.ceil, false);       // techo
      ib(w / 2, 0, -0.15, w + 0.6, h, 0.3, def.wall, true);          // muros
      ib(w / 2, 0, d + 0.15, w + 0.6, h, 0.3, def.wall, true);
      ib(-0.15, 0, d / 2, 0.3, h, d, def.wall, true);
      ib(w + 0.15, 0, d / 2, 0.3, h, d, def.wall, true);
      ib(w / 2, 0, d - 0.06, 1.2, 2.2, 0.06, rgb(0xffe2a8), false, 1); // puerta de salida (luminosa)
      def.build(ib, def);
      this.list.push({ def, mesh: R.makeMesh(b), cols });
    }
  },
  spawn(i) { const d = INT_DEFS[i]; return { x: d.ox + d.w / 2, z: d.oz + d.d - 2.0 }; },
  exitPos(i) { const d = INT_DEFS[i]; return { x: d.ox + d.w / 2, z: d.oz + d.d - 0.9 }; },
  draw(R, i) { R.drawMesh(this.list[i].mesh); },
  resolve(p) {
    const it = this.list[p.zone], d = it.def;
    let sup = 0;
    for (let pass = 0; pass < 2; pass++) sup = collideList(p, it.cols, it.cols.length, 0.32, 0.45, 0);
    p.x = Math.min(d.ox + d.w - 0.4, Math.max(d.ox + 0.4, p.x));
    p.z = Math.min(d.oz + d.d - 0.4, Math.max(d.oz + 0.4, p.z));
    if (p.vy <= 0 && p.y <= sup + 0.01) { p.y = sup; p.vy = 0; p.grounded = true; }
    else if (p.grounded && p.vy <= 0 && p.y - sup < 0.4) { p.y = sup; p.grounded = true; }
    else p.grounded = false;
    p.support = sup;
  },
  segBlocked() { return false; }
};
