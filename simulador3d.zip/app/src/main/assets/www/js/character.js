'use strict';
/* =====================================================================
   character.js — configuración del personaje, creador y render por piezas (low-poly)
   ===================================================================== */
const CPAL = {
  hair: [0x0a0a0c, 0x2b1d14, 0x4e3220, 0x7f5a3c, 0xb98b5e, 0xd9b77f, 0xf0dfaa, 0x8e2b1c, 0xc7324b, 0xe75480, 0x7b3fa0, 0x2f5bd0, 0x1fa89a, 0xb5b5ba],
  eye: [0x2b1a10, 0x6b4a2b, 0x4f8a4b, 0x3e8f8a, 0x4f8fd0, 0x6f7f8a, 0x7a5bc4, 0xb8862f],
  cloth: [0xf2f2f2, 0x9a9aa6, 0x2e2e36, 0x0f0f14, 0xe9dcc3, 0x8c6a4a, 0x3c5a8c, 0x22365e, 0x7a1f2b, 0xc0392b, 0xe67e22, 0xf1c40f, 0x2e7d4f, 0x1f8a8a, 0x7d3c98, 0xd85c9e]
};
const SKIN_ANCH = [0xf6d5c4, 0xe8b48f, 0xc98b63, 0x8f5a3b, 0x573421].map(rgb);
// Estados base: inclinación, amplitud de paso, rebote, apertura de brazos
const STANCES = [
  { lean: 0.02, amp: 1.0, bob: 1.0, out: 0.10 },   // Relajado
  { lean: -0.04, amp: 0.9, bob: 0.7, out: 0.05 },  // Erguido
  { lean: 0.07, amp: 1.25, bob: 1.4, out: 0.15 }   // Enérgico
];
const CDEF = {
  skin: 0.35, hairStyle: 1, hairLen: 0.6, hairColor: 3, eyeColor: 1,
  height: 1, build: 0.4, shoulders: 1, chest: 1, waist: 1, hips: 1, arms: 1, legs: 1,
  top: 0, topColor: 0, bottom: 0, bottomColor: 6, outer: 0, outerColor: 2, shoes: 0, shoeColor: 0,
  stance: 0, energy: 0.5
};
const CTABS = [
  { id: 'look', title: 'Apariencia', items: [
    { t: 'range', k: 'skin', l: 'Tono de piel', min: 0, max: 1, step: 0.01 },
    { t: 'choice', k: 'hairStyle', l: 'Peinado', o: ['Corto', 'Largo', 'Coleta', 'Moño', 'Rapado', 'Rizado'] },
    { t: 'range', k: 'hairLen', l: 'Largo del cabello', min: 0, max: 1, step: 0.01 },
    { t: 'color', k: 'hairColor', l: 'Color de cabello', p: 'hair' },
    { t: 'color', k: 'eyeColor', l: 'Color de ojos', p: 'eye' }] },
  { id: 'body', title: 'Cuerpo', items: [
    { t: 'range', k: 'height', l: 'Estatura / escala', min: 0.92, max: 1.1, step: 0.01 },
    { t: 'range', k: 'build', l: 'Complexión', min: 0, max: 1, step: 0.01 },
    { t: 'range', k: 'shoulders', l: 'Hombros', min: 0.8, max: 1.25, step: 0.01 },
    { t: 'range', k: 'chest', l: 'Pecho / torso', min: 0.8, max: 1.3, step: 0.01 },
    { t: 'range', k: 'waist', l: 'Cintura', min: 0.8, max: 1.25, step: 0.01 },
    { t: 'range', k: 'hips', l: 'Cadera', min: 0.8, max: 1.3, step: 0.01 },
    { t: 'range', k: 'arms', l: 'Brazos', min: 0.8, max: 1.3, step: 0.01 },
    { t: 'range', k: 'legs', l: 'Piernas', min: 0.8, max: 1.3, step: 0.01 }] },
  { id: 'outfit', title: 'Atuendo', items: [
    { t: 'choice', k: 'top', l: 'Prenda superior', o: ['Camiseta', 'Sudadera', 'Camisa', 'Vestido'] },
    { t: 'color', k: 'topColor', l: 'Color superior', p: 'cloth' },
    { t: 'choice', k: 'bottom', l: 'Prenda inferior', o: ['Pantalón', 'Falda', 'Shorts', 'Leggings'] },
    { t: 'color', k: 'bottomColor', l: 'Color inferior', p: 'cloth' },
    { t: 'choice', k: 'outer', l: 'Capa exterior', o: ['Ninguna', 'Chaqueta', 'Abrigo'] },
    { t: 'color', k: 'outerColor', l: 'Color de la capa', p: 'cloth' },
    { t: 'choice', k: 'shoes', l: 'Calzado', o: ['Tenis', 'Botas', 'Sandalias'] },
    { t: 'color', k: 'shoeColor', l: 'Color del calzado', p: 'cloth' }] },
  { id: 'state', title: 'Estado', items: [
    { t: 'choice', k: 'stance', l: 'Postura base', o: ['Relajado', 'Erguido', 'Enérgico'] },
    { t: 'range', k: 'energy', l: 'Energía (ritmo de paso)', min: 0, max: 1, step: 0.01 }] }
];

const Character = {
  cfg: Object.assign({}, CDEF), k: {}, M: {}, S: new MStack(), TABS: CTABS, defs: {}, _saveT: 0,

  init(R) {
    CTABS.forEach(t => t.items.forEach(it => { this.defs[it.k] = it; }));
    const b = new MeshBuilder(), W = [1, 1, 1], M = this.M;
    b.reset(); addBox(b, 0, -0.5, 0, 1, 1, 1, 0, W, 0); M.box = R.makeMesh(b);
    b.reset(); addCyl(b, 0, -0.5, 0, 0.5, 0.5, 1, 10, W, 0); M.cyl = R.makeMesh(b);
    b.reset(); addSphere(b, 0, 0, 0, 0.5, 0.5, 0.5, 10, 7, W, 0); M.sph = R.makeMesh(b);
    b.reset(); addSphere(b, 0, 0, 0, 0.5, 0.5, 0.5, 10, 5, W, 0, true); M.hemi = R.makeMesh(b);
    b.reset(); addCyl(b, 0, -0.5, 0, 0.5, 0.36, 1, 12, W, 0); M.skirt = R.makeMesh(b);
    this.rebuild();
  },

  rebuild() {
    const c = this.cfg, k = this.k;
    const f = Math.min(0.9999, c.skin) * (SKIN_ANCH.length - 1), i = Math.floor(f);
    k.skin = mixc(SKIN_ANCH[i], SKIN_ANCH[i + 1], f - i);
    k.skinDark = shade(k.skin, 0.78);
    k.lip = mixc(k.skin, [0.75, 0.3, 0.34], 0.45);
    k.hair = rgb(CPAL.hair[c.hairColor]); k.brow = shade(k.hair, 0.7);
    k.eye = rgb(CPAL.eye[c.eyeColor]);
    k.top = rgb(CPAL.cloth[c.topColor]); k.bottom = rgb(CPAL.cloth[c.bottomColor]);
    k.outer = rgb(CPAL.cloth[c.outerColor]); k.shoe = rgb(CPAL.cloth[c.shoeColor]);
    k.sole = shade(k.shoe, 0.55);
  },

  set(key, v, noSave) {
    const d = this.defs[key]; if (!d) return;
    if (d.t === 'range') v = Math.min(d.max, Math.max(d.min, +v));
    else if (d.t === 'choice') v = Math.min(d.o.length - 1, Math.max(0, v | 0));
    else v = Math.min(CPAL[d.p].length - 1, Math.max(0, v | 0));
    this.cfg[key] = v; this.rebuild();
    if (!noSave) this.save();
  },
  reset() { this.cfg = Object.assign({}, CDEF); this.rebuild(); this.save(); },
  randomize() {
    for (const key in this.defs) {
      const d = this.defs[key];
      if (d.t === 'range') this.set(key, d.min + Math.random() * (d.max - d.min), true);
      else if (d.t === 'choice') this.set(key, Math.floor(Math.random() * d.o.length), true);
      else this.set(key, Math.floor(Math.random() * CPAL[d.p].length), true);
    }
    this.save();
  },
  save() {
    clearTimeout(this._saveT);
    this._saveT = setTimeout(() => { try { localStorage.setItem('sim3d_char_v1', JSON.stringify(this.cfg)); } catch (e) { /* sin almacenamiento */ } }, 400);
  },
  load() {
    try {
      const s = JSON.parse(localStorage.getItem('sim3d_char_v1') || 'null');
      if (s && typeof s === 'object') for (const key in s) if (key in CDEF) this.set(key, s[key], true);
    } catch (e) { /* configuración inválida: se usa la de fábrica */ }
    this.rebuild();
  },

  shadow(R, x, y, z, h) {
    const S = this.S.reset(); S.translate(x, y + 0.02, z);
    const a = 0.38 * (1 - Math.min(1, h / 1.6));
    if (a <= 0.01) return;
    R.blend(true);
    R.drawPart(this.M.cyl, S.m(), 0.8, 0.02, 0.8, [0, 0, 0], a);
    R.blend(false);
  },

  /** Aplica un preset de apariencia (los otros valores vuelven a los de fábrica). */
  applyPreset(p) {
    this.cfg = Object.assign({}, CDEF);
    for (const key in p) if (key in CDEF) this.set(key, p[key], true);
    this.rebuild(); this.save();
  },

  /** Dibuja al jugador (st: x,y,z,yaw,phase,speed,grounded,t,crouch,swing,swingKind,weapon). */
  draw(R, st) {
    const c = this.cfg, k = this.k, S = this.S, M = this.M, W = this.W || {};
    const part = (mesh, sx, sy, sz, col) => R.drawPart(mesh, S.m(), sx, sy, sz, col, 1);
    const bf = 0.88 + 0.32 * c.build;
    const sw = 0.185 * c.shoulders * bf, cd = 0.105 * c.chest * bf, wr = 0.135 * c.waist * bf;
    const hr = 0.17 * c.hips * bf, ar = 0.042 * c.arms * bf, lr = 0.078 * c.legs * bf;
    const cr = st.crouch || 0, swg = st.swing === undefined ? -1 : st.swing, kind = st.swingKind || 0, wp = st.weapon || 0;
    const sp = Math.min(1, st.speed / 5.2), stn = STANCES[c.stance] || STANCES[0], en = 0.8 + 0.4 * c.energy;
    const A = (sp > 0.02 ? (0.3 + 0.7 * sp) * 0.9 * stn.amp * en : 0) * (1 - 0.6 * cr);
    const bob = (Math.abs(Math.sin(st.phase)) * 0.03 * sp * stn.bob * en + Math.sin(st.t * 2) * 0.004 * (1 - sp)) * (1 - cr * 0.6);
    const air = !st.grounded;
    const topT = c.top, botT = c.bottom, outT = c.outer, hasOut = outT > 0;
    const pelvisCol = topT === 3 ? k.top : k.bottom;
    const chestCol = hasOut ? k.outer : k.top;
    const lean = stn.lean + 0.3 * cr + (swg >= 0 && kind === 2 ? 0.35 * Math.sin(Math.PI * swg) : 0);
    const TINT = [1, 1, 1];

    S.reset(); S.translate(st.x, st.y, st.z); S.rotY(st.yaw); S.scale(c.height);
    S.translate(0, -0.30 * cr, 0); // agachado: la cadera baja

    const seg = (len, dia, frac, cov, covK, skin) => {
      S.push(); S.translate(0, -len / 2, 0);
      if (frac < 0.999) part(M.cyl, dia, len, dia, skin);
      if (frac > 0) { S.push(); S.translate(0, len / 2 - len * frac / 2, 0); part(M.cyl, dia * covK, len * frac, dia * covK, cov); S.pop(); }
      S.pop();
    };

    /* ----- piernas ----- */
    const thF = (botT === 0 || botT === 3) ? 1 : (botT === 2 ? 0.55 : 0);
    const shF = (botT === 0 || botT === 3) ? 1 : 0;
    const covK = botT === 3 ? 1.04 : (botT === 2 ? 1.1 : 1.08);
    for (const s of [-1, 1]) {
      const p = st.phase + (s > 0 ? 0 : Math.PI);
      let th = -Math.sin(p) * A - 0.9 * cr, kn = Math.max(0, Math.cos(p)) * A * 1.1 + 1.7 * cr;
      if (air) { th = s > 0 ? -0.5 : 0.25; kn = s > 0 ? 0.9 : 0.4; }
      S.push(); S.translate(s * hr * 0.55, 0.94, 0); S.rotX(th);
      seg(0.45, 2 * lr, thF, k.bottom, covK, k.skin);
      S.translate(0, -0.45, 0); S.rotX(kn);
      seg(0.43, 2 * lr * 0.82, shF, k.bottom, covK, k.skin);
      if (c.shoes === 1) { S.push(); S.translate(0, -0.32, 0); part(M.cyl, 2 * lr * 0.82 * 1.18, 0.2, 2 * lr * 0.82 * 1.18, k.shoe); S.pop(); }
      S.translate(0, -0.43, 0);
      S.push(); S.translate(0, -0.02, 0.05);
      if (c.shoes === 2) {
        part(M.box, lr * 1.8, 0.06, 0.26, k.skin);
        S.push(); S.translate(0, 0.035, 0); part(M.box, lr * 1.9, 0.02, 0.07, k.shoe); S.pop();
      } else {
        part(M.box, lr * 2.1, 0.07, 0.27, k.shoe);
        S.push(); S.translate(0, -0.03, 0); part(M.box, lr * 2.2, 0.02, 0.28, k.sole); S.pop();
      }
      S.pop();
      S.pop();
    }

    /* ----- tronco, cabeza y brazos ----- */
    S.push(); S.translate(0, bob, 0);
    S.translate(0, 0.94, 0); S.rotX(lean); S.translate(0, -0.94, 0);

    S.push(); S.translate(0, 0.95, 0); part(M.cyl, 2 * hr, 0.2, 2 * hr * 0.74, pelvisCol); S.pop();
    S.push(); S.translate(0, 1.10, 0); part(M.cyl, 2 * wr, 0.2, 2 * wr * 0.78, chestCol); S.pop();
    S.push(); S.translate(0, 1.27 + Math.sin(st.t * 2) * 0.004, 0); part(M.cyl, 2 * sw, 0.26, 2 * cd, chestCol); S.pop();
    if (outT === 1) {
      S.push(); S.translate(0, 0.99, 0); part(M.cyl, 2 * hr * 1.08, 0.1, 2 * hr * 0.8, k.outer); S.pop();
      S.push(); S.translate(0, 1.25, cd + 0.004); part(M.box, 0.06, 0.3, 0.01, k.top); S.pop();
    }
    if (outT === 2) { S.push(); S.translate(0, 0.86, 0); part(M.skirt, 2 * hr * 1.5, 0.78, 2 * hr * 1.15, k.outer); S.pop(); }
    if (topT === 3) { S.push(); S.translate(0, 0.72, 0); part(M.skirt, 2 * hr * 1.6, 0.62, 2 * hr * 1.3, k.top); S.pop(); }
    else if (botT === 1) { S.push(); S.translate(0, 0.79, 0); part(M.skirt, 2 * hr * 1.5, 0.4, 2 * hr * 1.2, k.bottom); S.pop(); }
    if (topT === 2 && !hasOut) { S.push(); S.translate(0, 1.43, 0.01); part(M.box, 0.14, 0.03, 0.1, shade(k.top, 1.1)); S.pop(); }
    S.push(); S.translate(0, 1.49, 0); part(M.cyl, 0.085 * bf, 0.12, 0.085 * bf, k.skin); S.pop();

    // brazos (el derecho empuña el arma)
    const uF = hasOut ? 1 : (topT === 0 ? 0.55 : (topT === 3 ? 0 : 1));
    const fF = hasOut ? 1 : ((topT === 1 || topT === 2) ? 1 : 0);
    const slv = hasOut ? k.outer : k.top, slK = hasOut ? 1.16 : 1.1;
    for (const s of [-1, 1]) {
      const pl = st.phase + (s > 0 ? 0 : Math.PI);
      let ang = Math.sin(pl) * A * 0.8 + Math.sin(st.t * 1.4 + s) * 0.03, el = -(0.15 + 0.5 * Math.max(0, -ang)), sweep = 0;
      if (air) { ang = -0.9; el = -0.4; }
      if (wp === 2) { ang = s > 0 ? -1.35 : -1.25; el = -0.15; sweep = s > 0 ? -0.15 : 0.5; }
      if (s > 0 && wp === 1 && swg >= 0) { // tajo: alto (cabeza) · medio (torso/brazos) · bajo (piernas)
        const e = swg * swg * (3 - 2 * swg);
        if (kind === 0) { ang = swg < 0.35 ? -0.3 + (-2.4) * (swg / 0.35) : -2.7 + 2.2 * ((swg - 0.35) / 0.65); el = -0.3; }
        else if (kind === 1) { ang = -1.45; sweep = 1.0 - 2.1 * e; el = -0.2; }
        else { ang = -0.4 - 0.7 * e; sweep = 0.6 - 1.2 * e; el = -0.25; }
      }
      S.push(); S.translate(s * (sw + ar * 0.9), 1.38, 0);
      part(M.sph, ar * 2.3, ar * 2.3, ar * 2.3, uF > 0 ? slv : k.skin);
      S.rotZ(s * stn.out); S.rotY(sweep); S.rotX(ang);
      seg(0.30, 2 * ar, uF, slv, slK, k.skin);
      S.translate(0, -0.30, 0); S.rotX(el);
      seg(0.27, 2 * ar * 0.9, fF, slv, slK, k.skin);
      S.translate(0, -0.27, 0);
      part(M.sph, 2 * ar * 1.1, 2 * ar * 1.25, 2 * ar * 1.1, k.skin);
      if (s > 0 && wp) {
        const mesh = wp === 1 ? W.machete : W.rifle;
        if (mesh) { S.push(); S.rotX(swg >= 0 ? -0.25 : (wp === 2 ? 0 : -0.9)); R.drawPart(mesh, S.m(), 1, 1, 1, TINT, 1); S.pop(); }
      }
      S.pop();
    }

    // cabeza
    S.push(); S.translate(0, 1.63, 0);
    part(M.sph, 0.205, 0.235, 0.22, k.skin);
    for (const s of [-1, 1]) {
      S.push(); S.translate(s * 0.043, 0.022, 0.092);
      part(M.sph, 0.036, 0.034, 0.02, [0.96, 0.96, 0.97]);
      S.translate(0, 0, 0.006); part(M.sph, 0.024, 0.024, 0.016, k.eye);
      S.pop();
      S.push(); S.translate(s * 0.045, 0.052, 0.09); part(M.box, 0.05, 0.009, 0.014, k.brow); S.pop();
      S.push(); S.translate(s * 0.1, 0.0, 0); part(M.sph, 0.03, 0.045, 0.03, k.skin); S.pop();
    }
    S.push(); S.translate(0, -0.008, 0.108); part(M.box, 0.014, 0.02, 0.014, k.skinDark); S.pop();
    S.push(); S.translate(0, -0.052, 0.097); part(M.box, 0.036, 0.007, 0.01, k.lip); S.pop();

    const hc = k.hair, hs = c.hairStyle;
    S.push(); S.translate(0, 0.012, -0.012); S.rotX(-0.5);
    if (hs === 4) part(M.hemi, 0.222, 0.24, 0.232, mixc(k.hair, k.skin, 0.55));
    else part(M.hemi, 0.238, 0.255, 0.25, hc);
    S.pop();
    if (hs === 1) {
      const H = 0.2 + 0.32 * c.hairLen;
      S.push(); S.translate(0, 0.03 - H / 2, -0.085); part(M.box, 0.235, H, 0.075, hc); S.pop();
      for (const s of [-1, 1]) { S.push(); S.translate(s * 0.108, 0.02 - H * 0.4, -0.01); part(M.box, 0.05, H * 0.8, 0.1, hc); S.pop(); }
    } else if (hs === 2) {
      const L = 0.2 + 0.2 * c.hairLen;
      S.push(); S.translate(0, 0.03, -0.115); part(M.sph, 0.07, 0.07, 0.07, hc); S.pop();
      S.push(); S.translate(0, 0.0, -0.15); S.rotX(0.25); S.translate(0, -L / 2, 0); part(M.cyl, 0.06, L, 0.06, hc); S.pop();
    } else if (hs === 3) {
      S.push(); S.translate(0, 0.125, -0.02); part(M.sph, 0.11, 0.11, 0.11, hc); S.pop();
    } else if (hs === 5) {
      S.push(); S.translate(0, 0.05, -0.045); part(M.sph, 0.31, 0.29, 0.30, hc); S.pop();
    }
    S.pop(); // cabeza
    S.pop(); // tronco
  }
};
