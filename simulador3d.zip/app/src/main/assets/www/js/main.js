(function () {
'use strict';
/* =====================================================================
   main.js — entrada táctil, cámara, físicas, interacción, creador (UI) y bucle
   ===================================================================== */
const $ = id => document.getElementById(id);
const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt !== undefined) e.textContent = txt; return e; };
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* sin almacenamiento */ } }
};

const SPEEDS = [{ n: 'Calmo', v: 1.7 }, { n: 'Normal', v: 3.4 }, { n: 'Ágil', v: 5.2 }];
let speedIdx = store.get('sim3d_speed', 1); if (!(speedIdx >= 0 && speedIdx < 3)) speedIdx = 1;

/* ---------- renderer ---------- */
const canvas = $('gl');
let R;
try { R = new Renderer(canvas); }
catch (err) { $('loading').innerHTML = '<div>No se pudo iniciar WebGL.<small>' + String(err.message || err) + '</small></div>'; return; }
canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); $('loading').style.display = 'flex'; $('loading').firstElementChild.textContent = 'Reiniciando gráficos…'; });
canvas.addEventListener('webglcontextrestored', () => location.reload());
World.init(R); Character.init(R); Character.load();

let resScale = store.get('sim3d_res', 0.85);
function resize() { R.resize(resScale); }
window.addEventListener('resize', resize); resize();

/* ---------- estado ---------- */
const P = { x: 0, y: 0, z: 3, vx: 0, vz: 0, vy: 0, yaw: Math.PI, grounded: true, support: 0, phase: 0, speedH: 0 };
const cam = { yaw: 0, pitch: 0.38, dist: 5.2 };
const camS = { dist: 5.2, ty: 1.25, y: 0, ox: 0, oy: 0 };
const ui = { creator: false };
let loading = true, t = 0, jumpReq = false, exitArmed = 0;
const input = { jx: 0, jy: 0 }, keys = {};

/* ---------- toast ---------- */
let toastT = 0;
function toast(msg) { const e = $('toast'); e.textContent = msg; e.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => { e.hidden = true; }, 2400); }

/* ---------- velocidad / ritmo ---------- */
function buildSpeed() {
  const box = $('speed'); box.innerHTML = '';
  SPEEDS.forEach((s, i) => {
    const b = el('button', 'btn' + (i === speedIdx ? ' on' : ''), s.n);
    b.onclick = () => { speedIdx = i; store.set('sim3d_speed', i); buildSpeed(); };
    box.appendChild(b);
  });
}
buildSpeed();

/* ---------- entrada táctil: joystick flotante (izq.) + cámara (resto) ---------- */
const touch = $('touch'), joy = $('joy'), knob = $('knob');
let joyId = -1, camId = -1, joyX = 0, joyY = 0, lastX = 0, lastY = 0;
const JR = 56;
touch.addEventListener('pointerdown', e => {
  e.preventDefault();
  try { touch.setPointerCapture(e.pointerId); } catch (x) { /* ignorar */ }
  if (e.clientX < window.innerWidth * 0.5 && joyId < 0 && !ui.creator) {
    joyId = e.pointerId; joyX = e.clientX; joyY = e.clientY;
    joy.style.display = 'block'; joy.style.left = joyX + 'px'; joy.style.top = joyY + 'px';
    knob.style.transform = 'translate(0,0)';
  } else if (camId < 0) { camId = e.pointerId; lastX = e.clientX; lastY = e.clientY; }
});
touch.addEventListener('pointermove', e => {
  if (e.pointerId === joyId) {
    let dx = e.clientX - joyX, dy = e.clientY - joyY; const l = Math.hypot(dx, dy);
    if (l > JR) { dx *= JR / l; dy *= JR / l; }
    input.jx = dx / JR; input.jy = dy / JR;
    knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
  } else if (e.pointerId === camId) {
    cam.yaw -= (e.clientX - lastX) * 0.006;
    cam.pitch = Math.min(1.25, Math.max(0.08, cam.pitch + (e.clientY - lastY) * 0.005));
    lastX = e.clientX; lastY = e.clientY;
  }
});
function endPtr(e) {
  if (e.pointerId === joyId) { joyId = -1; input.jx = input.jy = 0; joy.style.display = 'none'; }
  if (e.pointerId === camId) camId = -1;
}
touch.addEventListener('pointerup', endPtr);
touch.addEventListener('pointercancel', endPtr);
touch.addEventListener('contextmenu', e => e.preventDefault());

window.addEventListener('keydown', e => {
  const k = e.key.toLowerCase(); keys[k] = true;
  if (k === ' ') { jumpReq = true; e.preventDefault(); }
  if (k === 'e') doInteract();
});
window.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });

$('btn-jump').addEventListener('pointerdown', e => { e.preventDefault(); jumpReq = true; });
$('btn-act').addEventListener('click', () => doInteract());
$('btn-zin').addEventListener('click', () => { cam.dist = Math.max(2.2, cam.dist - 0.8); });
$('btn-zout').addEventListener('click', () => { cam.dist = Math.min(9, cam.dist + 0.8); });
$('btn-char').addEventListener('click', () => openCreator());

/* ---------- interacción ---------- */
let nearIt = null;
function doInteract() {
  if (ui.creator || !nearIt) return;
  if (nearIt.id === 'mirror') openCreator();
  else if (nearIt.id === 'lamp') { Env.target = Env.target ? 0 : 1; toast(Env.target ? 'Anochece: los faroles se encienden' : 'Amanece'); }
  else if (nearIt.id === 'chest') {
    World.state.chestOpen = !World.state.chestOpen; World.refreshAt(nearIt.x, nearIt.z);
    toast(World.state.chestOpen ? 'Cofre abierto: brilla una luz dorada' : 'Cofre cerrado');
  }
}

/* ---------- creador de personaje (UI) ---------- */
let curTab = 0;
function openCreator() {
  if (ui.creator) return;
  ui.creator = true; document.body.classList.add('cr'); $('creator').hidden = false;
  cam.yaw = P.yaw; cam.pitch = 0.18; input.jx = input.jy = 0;
  buildCreator();
}
function closeCreator() {
  ui.creator = false; document.body.classList.remove('cr'); $('creator').hidden = true;
  cam.yaw = P.yaw + Math.PI; cam.pitch = 0.38;
}
function buildCreator() {
  const tabs = $('cr-tabs'), body = $('cr-body'), keep = body.scrollTop;
  tabs.innerHTML = '';
  Character.TABS.forEach((tb, i) => {
    const b = el('button', 'tab' + (i === curTab ? ' on' : ''), tb.title);
    b.onclick = () => { curTab = i; body.scrollTop = 0; buildCreator(); };
    tabs.appendChild(b);
  });
  body.innerHTML = '';
  Character.TABS[curTab].items.forEach(it => {
    const box = el('div', 'ctl'), lbl = el('div', 'lbl'), cur = Character.cfg[it.k];
    lbl.appendChild(el('span', '', it.l));
    if (it.t === 'range') {
      const val = el('span', '', (+cur).toFixed(2)); lbl.appendChild(val); box.appendChild(lbl);
      const inp = el('input'); inp.type = 'range'; inp.min = it.min; inp.max = it.max; inp.step = it.step; inp.value = cur;
      inp.setAttribute('aria-label', it.l);
      inp.addEventListener('input', () => { Character.set(it.k, parseFloat(inp.value)); val.textContent = (+Character.cfg[it.k]).toFixed(2); });
      box.appendChild(inp);
    } else if (it.t === 'choice') {
      box.appendChild(lbl);
      const pills = el('div', 'pills');
      it.o.forEach((name, i) => {
        const b = el('button', 'pill' + (i === cur ? ' on' : ''), name);
        b.onclick = () => { Character.set(it.k, i); buildCreator(); };
        pills.appendChild(b);
      });
      box.appendChild(pills);
    } else {
      box.appendChild(lbl);
      const sw = el('div', 'sw');
      CPAL[it.p].forEach((hex, i) => {
        const b = el('button', i === cur ? 'on' : ''); b.setAttribute('aria-label', 'Color ' + (i + 1));
        const dot = el('i'); dot.style.background = '#' + hex.toString(16).padStart(6, '0'); b.appendChild(dot);
        b.onclick = () => { Character.set(it.k, i); buildCreator(); };
        sw.appendChild(b);
      });
      box.appendChild(sw);
    }
    body.appendChild(box);
  });
  body.scrollTop = keep;
}
$('cr-close').addEventListener('click', closeCreator);
$('cr-rand').addEventListener('click', () => { Character.randomize(); buildCreator(); });
$('cr-reset').addEventListener('click', () => { Character.reset(); buildCreator(); });

/* ---------- botón atrás (lo llama MainActivity) ---------- */
window.nativeBack = function () {
  if (ui.creator) { closeCreator(); return; }
  const now = Date.now();
  if (now - exitArmed < 2200) { if (window.Android && window.Android.exitApp) window.Android.exitApp(); return; }
  exitArmed = now; toast('Pulsa atrás otra vez para salir');
};

/* ---------- jugador ---------- */
function updatePlayer(dt) {
  let ix = input.jx, iy = input.jy;
  if (keys['a'] || keys['arrowleft']) ix -= 1;
  if (keys['d'] || keys['arrowright']) ix += 1;
  if (keys['w'] || keys['arrowup']) iy -= 1;
  if (keys['s'] || keys['arrowdown']) iy += 1;
  let mag = Math.hypot(ix, iy);
  if (mag > 1) { ix /= mag; iy /= mag; mag = 1; }
  if (mag < 0.12 || ui.creator) { mag = 0; ix = iy = 0; }
  const sp = SPEEDS[speedIdx].v;
  const fx = -Math.sin(cam.yaw), fz = -Math.cos(cam.yaw), rx = Math.cos(cam.yaw), rz = -Math.sin(cam.yaw);
  const dx = fx * (-iy) + rx * ix, dz = fz * (-iy) + rz * ix, dl = Math.hypot(dx, dz);
  let tvx = 0, tvz = 0;
  if (dl > 0.001) {
    tvx = dx / dl * sp * mag; tvz = dz / dl * sp * mag;
    let da = Math.atan2(dx, dz) - P.yaw;
    while (da > Math.PI) da -= 2 * Math.PI;
    while (da < -Math.PI) da += 2 * Math.PI;
    P.yaw += da * Math.min(1, dt * 12);
  }
  const k = 1 - Math.exp(-(P.grounded ? 14 : 4) * dt);
  P.vx += (tvx - P.vx) * k; P.vz += (tvz - P.vz) * k;
  P.x += P.vx * dt; P.z += P.vz * dt;
  if (jumpReq && P.grounded && !ui.creator) { P.vy = 6.3; P.grounded = false; }
  jumpReq = false;
  P.vy -= 18 * dt; P.y += P.vy * dt;
  World.resolve(P);
  P.speedH = Math.hypot(P.vx, P.vz);
  P.phase += P.speedH * dt * 3.6;
  if (P.y < -5) { P.x = 0; P.z = 3; P.y = 0; P.vy = 0; }
}

/* ---------- cámara tercera persona ---------- */
const proj = M4.create(), view = M4.create(), vp = M4.create();
const camInfo = { x: 0, z: 0, fx: 0, fz: -1 };
function updateCamera(dt) {
  const h = Character.cfg.height, k = Math.min(1, dt * 6), land = R.aspect >= 1;
  camS.dist += ((ui.creator ? 3.4 : cam.dist) - camS.dist) * k;
  camS.ty += ((ui.creator ? 0.9 : 1.25) * h - camS.ty) * k;
  camS.y += (P.y - camS.y) * Math.min(1, dt * 10);
  // En el creador, el panel tapa parte de la pantalla: se desplaza la imagen para dejar al personaje visible.
  const tox = ui.creator && land ? Math.min(0.46, 460 / Math.max(1, window.innerWidth)) : 0;
  const toy = ui.creator && !land ? -0.46 : 0;
  camS.ox += (tox - camS.ox) * k; camS.oy += (toy - camS.oy) * k;
  const tx = P.x, ty = camS.y + camS.ty, tz = P.z, cp = Math.cos(cam.pitch);
  let ex = tx + Math.sin(cam.yaw) * cp * camS.dist, ey = ty + Math.sin(cam.pitch) * camS.dist, ez = tz + Math.cos(cam.yaw) * cp * camS.dist;
  if (ey < 0.3) ey = 0.3;
  M4.perspective(proj, land ? 1.0 : 1.35, R.aspect, 0.15, 90);
  proj[8] = camS.ox; proj[9] = camS.oy;
  M4.lookAt(view, ex, ey, ez, tx, ty, tz);
  M4.mul(vp, proj, view);
  camInfo.x = ex; camInfo.z = ez; camInfo.fx = -Math.sin(cam.yaw); camInfo.fz = -Math.cos(cam.yaw);
}

/* ---------- render ---------- */
const chr = { x: 0, y: 0, z: 0, yaw: 0, phase: 0, speed: 0, grounded: true, t: 0 };
function render() {
  R.begin(Env); R.setVP(vp); R.useStatic();
  World.draw(R, camInfo);
  chr.x = P.x; chr.y = P.y; chr.z = P.z; chr.yaw = P.yaw; chr.phase = P.phase; chr.speed = P.speedH; chr.grounded = P.grounded; chr.t = t;
  Character.draw(R, chr);
  Character.shadow(R, P.x, P.support, P.z, P.y - P.support);
}

/* ---------- bucle ---------- */
let last = 0, fAcc = 0, fN = 0, fps = 60, hudT = 0, perfT = 0;
function frame(ts) {
  requestAnimationFrame(frame);
  if (document.hidden) { last = ts; return; }
  if (!last) last = ts;
  let dt = (ts - last) / 1000; last = ts;
  if (dt <= 0) return;
  if (dt > 0.05) dt = 0.05;
  t += dt;

  updatePlayer(dt); updateCamera(dt); Env.update(dt);
  World.update(P.x, P.z, loading ? 14 : 2.5);
  if (loading) {
    const n = World.count();
    $('loadpct').textContent = n + ' / ' + World.total() + ' zonas';
    if (n >= World.total()) { loading = false; $('loading').style.display = 'none'; toast('Busca las balizas de colores: son puntos interactivos'); }
  }
  render();

  nearIt = ui.creator ? null : World.nearest(P.x, P.z);
  const ab = $('btn-act');
  if (nearIt) { ab.hidden = false; if (ab.textContent !== nearIt.name) ab.textContent = nearIt.name; } else ab.hidden = true;

  fAcc += dt; fN++; hudT += dt; perfT += dt;
  if (fAcc >= 0.5) { fps = Math.round(fN / fAcc); fAcc = 0; fN = 0; }
  if (hudT > 0.4) {
    hudT = 0;
    $('info').textContent = 'Zona ' + cellOf(P.x) + ',' + cellOf(P.z) + ' · zonas ' + World.count() + ' (pool ' + World.pool.length + ') · ' + fps + ' fps · res ' + Math.round(resScale * 100) + '%';
  }
  if (perfT > 3 && !loading) { // resolución dinámica
    perfT = 0;
    if (fps < 40 && resScale > 0.55) { resScale = Math.max(0.55, resScale - 0.1); resize(); store.set('sim3d_res', resScale); }
    else if (fps >= 58 && resScale < 1) { resScale = Math.min(1, resScale + 0.05); resize(); store.set('sim3d_res', resScale); }
  }
}
requestAnimationFrame(frame);
})();
