(function () {
'use strict';
/* =====================================================================
   main.js — entrada táctil, cámara 1ª/3ª persona, sigilo, ruido, combate, consumibles,
   interiores, viaje rápido, modos de juego, guardado local, HUD y bucle principal
   ===================================================================== */
const $ = id => document.getElementById(id);
const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt !== undefined) e.textContent = txt; return e; };
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* sin almacenamiento */ } }
};

/* ---------- personajes jugables ---------- */
const CHARS = [
  { id: 'estudiante', name: 'Estudiante universitario', desc: 'Veloz y ágil, pisadas silenciosas, mayor alcance de señuelo. Inicia en calles y campus de Zapopan.',
    hp: 90, sta: 100, spd: 1.12, foot: 0.6, throwR: 1.5, throwNoise: 1.3, mach: 1.0, reach: 1.0, heal: 1.0, heavy: false, steady: 1,
    look: { skin: 0.3, hairStyle: 0, hairColor: 1, eyeColor: 1, height: 0.99, build: 0.3, top: 0, topColor: 6, bottom: 0, bottomColor: 2, shoes: 0, shoeColor: 0, stance: 2, energy: 0.7 } },
  { id: 'granjero', name: 'Granjero de la sierra', desc: 'Resistente, mucha energía, domina el machete y aprovecha mejor los botiquines. Inicia en el sendero serrano.',
    hp: 130, sta: 150, spd: 0.95, foot: 1.0, throwR: 1.0, throwNoise: 1.0, mach: 1.4, reach: 1.15, heal: 1.5, heavy: false, steady: 1,
    look: { skin: 0.58, hairStyle: 4, hairColor: 2, eyeColor: 1, height: 1.05, build: 0.75, shoulders: 1.15, arms: 1.1, top: 2, topColor: 5, bottom: 0, bottomColor: 6, shoes: 1, shoeColor: 5, stance: 1, energy: 0.4 } },
  { id: 'militar', name: 'Militar entrenado', desc: 'Arma pesada de alto impacto con enfriamiento y munición; más estable agachado, pero muy ruidoso. Inicia en el retén.',
    hp: 115, sta: 110, spd: 1.0, foot: 1.15, throwR: 1.0, throwNoise: 1.0, mach: 1.0, reach: 1.0, heal: 1.0, heavy: true, steady: 0.5,
    look: { skin: 0.42, hairStyle: 4, hairColor: 0, eyeColor: 1, height: 1.04, build: 0.7, shoulders: 1.2, chest: 1.1, top: 2, topColor: 12, bottom: 0, bottomColor: 12, outer: 1, outerColor: 12, shoes: 1, shoeColor: 3, stance: 1, energy: 0.5 } }
];
const SPEEDS = [{ n: 'Calmo', v: 1.6 }, { n: 'Normal', v: 2.3 }, { n: 'Ágil', v: 3.0 }];
const ZES = ['Cabeza', 'Torso', 'Brazo izq.', 'Brazo der.', 'Pierna izq.', 'Pierna der.'];
let speedIdx = store.get('sim3d_speed', 1); if (!(speedIdx >= 0 && speedIdx < 3)) speedIdx = 1;

/* ---------- renderer y módulos ---------- */
const canvas = $('gl');
let R;
try { R = new Renderer(canvas); }
catch (err) { $('loading').style.display = 'flex'; $('loading').innerHTML = '<div>No se pudo iniciar WebGL.<small>' + String(err.message || err) + '</small></div>'; return; }
canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); $('loading').style.display = 'flex'; });
canvas.addEventListener('webglcontextrestored', () => location.reload());
World.init(R); Interiors.init(R); Character.init(R); Character.load(); Actors.init(R);
const AM = Actors.M, S2 = new MStack(), FS = new MStack();

let resScale = store.get('sim3d_res', 0.8);
function resize() { R.resize(resScale); }
window.addEventListener('resize', resize); resize();

/* ---------- estado ---------- */
const P = { i: 200, x: 0, y: 0, z: 0, vx: 0, vz: 0, vy: 0, yaw: Math.PI, grounded: true, support: 0, phase: 0, speedH: 0, zone: -1, crouch: 0 };
const cam = { yaw: 0, pitch: 0.38, dist: 5.2, fp: 0 };
const camS = { dist: 5.2, ty: 1.25, y: 0, ox: 0, oy: 0 };
const camInfo = { x: 0, z: 0, ey: 0, fx: 0, fz: -1 };
const G = {
  mode: 1, chIdx: 0, ch: CHARS[0], hp: 90, hpMax: 90, sta: 100, staMax: 100, med: 1, adr: 0, decoy: 3, ammo: 0, heat: 0, jam: 0, kills: 0,
  ts: 1, tsT: 1, adrT: 0, dayT: 0.04, night: false, dead: false, paused: true, started: false, vision: 17, collected: new Set(), msgCd: 0,
  heightSel: 1, fp: false, wp: 0, crouchOn: false, swing: -1, swingKind: 1, swingN: 0, hitDone: true, cd: 0, cd2: 0, busy: false, outPos: null,
  recoil: 0, near: null, stepT: 0, runLock: false, saveT: 0
};
const ui = { creator: false };
let loading = true, t = 0, frameN = 0, jumpReq = false, exitArmed = 0, menuMode = 1, menuChar = 0, lastLookChar = -1;
function ensureLook(idx) { if (lastLookChar !== idx) { Character.applyPreset(CHARS[idx].look); lastLookChar = idx; } }
const input = { jx: 0, jy: 0 }, keys = {};

/* ---------- avisos, marcador de golpe y burbujas de diálogo ---------- */
let toastT = 0, hitT = 0;
function toast(msg) { const e = $('toast'); e.textContent = msg; e.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => { e.hidden = true; }, 2200); }
function hitMark(msg) { const e = $('hit'); e.textContent = msg; e.hidden = false; clearTimeout(hitT); hitT = setTimeout(() => { e.hidden = true; }, 800); }
const bubbles = [];
for (let i = 0; i < 3; i++) { const d = el('div'); $('bubbles').appendChild(d); bubbles.push({ d, n: null, t: 0 }); }
function showBubble(n, text) {
  let b = null; for (const q of bubbles) if (q.t <= 0) { b = q; break; }
  if (!b) { b = bubbles[0]; for (const q of bubbles) if (q.t < b.t) b = q; }
  b.n = n; b.t = 3; b.d.textContent = text; b.d.style.display = 'block';
}
Hooks.say = showBubble;
Hooks.msg = toast;
Hooks.kill = () => { G.kills++; };
Hooks.hit = (z, zone, res) => {
  const nm = ZES[zone];
  hitMark(res === 'dead' ? (zone === 0 ? 'Cabeza · letal' : nm + ' · baja') : res === 'cut' ? nm + ' cortado' : res === 'stagger' ? 'Torso · retrocede' : nm + ' dañado');
};
Hooks.hurt = dmg => hurt(dmg);
Zombies.hiddenFn = (x, y, z) => !Frustum.sphere(x, y, z, 1) || World.rayBlocked(camInfo.x, camInfo.ey, camInfo.z, x, y, z);

/* ---------- ritmo base (velocidad): un botón que cicla Calmo / Normal / Ágil ---------- */
$('btn-speed').addEventListener('click', () => { speedIdx = (speedIdx + 1) % 3; store.set('sim3d_speed', speedIdx); toast('Ritmo ' + SPEEDS[speedIdx].n); });

/* ---------- entrada táctil: joystick flotante (izq.) + cámara (resto) ---------- */
const touch = $('touch'), joy = $('joy'), knob = $('knob');
let joyId = -1, camId = -1, joyX = 0, joyY = 0, lastX = 0, lastY = 0;
const JR = 56;
touch.addEventListener('pointerdown', e => {
  e.preventDefault();
  try { touch.setPointerCapture(e.pointerId); } catch (x) { /* ignorar */ }
  if (e.clientX < window.innerWidth * 0.5 && joyId < 0 && !ui.creator) {
    joyId = e.pointerId; joyX = e.clientX; joyY = e.clientY;
    joy.style.display = 'block'; joy.style.left = joyX + 'px'; joy.style.top = joyY + 'px'; knob.style.transform = 'translate(0,0)';
  } else if (camId < 0) { camId = e.pointerId; lastX = e.clientX; lastY = e.clientY; }
});
touch.addEventListener('pointermove', e => {
  if (e.pointerId === joyId) {
    let dx = e.clientX - joyX, dy = e.clientY - joyY; const l = Math.hypot(dx, dy);
    if (l > JR) { dx *= JR / l; dy *= JR / l; }
    input.jx = dx / JR; input.jy = dy / JR; knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
  } else if (e.pointerId === camId) {
    cam.yaw -= (e.clientX - lastX) * 0.006;
    if (G.fp && !ui.creator) cam.fp = Math.min(1.3, Math.max(-1.3, cam.fp - (e.clientY - lastY) * 0.005));
    else cam.pitch = Math.min(1.25, Math.max(0.08, cam.pitch + (e.clientY - lastY) * 0.005));
    lastX = e.clientX; lastY = e.clientY;
  }
});
function endPtr(e) {
  if (e.pointerId === joyId) { joyId = -1; input.jx = input.jy = 0; joy.style.display = 'none'; }
  if (e.pointerId === camId) camId = -1;
}
touch.addEventListener('pointerup', endPtr);
touch.addEventListener('pointercancel', endPtr);
touch.addEventListener('contextmenu', e => e.preventDefault());

window.addEventListener('keydown', e => {
  const k = e.key.toLowerCase(); keys[k] = true;
  if (k === ' ') { jumpReq = true; e.preventDefault(); }
  if (k === 'e') interact();
  if (k === 'f') attack();
  if (k === 'c') toggleCrouch();
  if (k === 'v') toggleCam();
  if (k === 'g') throwDecoy();
  if (k === 'h') useMed();
  if (k === 'r') useAdr();
  if (k === 'q') describeScene();
});
window.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });

$('btn-jump').addEventListener('pointerdown', e => { e.preventDefault(); jumpReq = true; });
$('btn-atk').addEventListener('pointerdown', e => { e.preventDefault(); attack(); });
$('btn-crouch').addEventListener('click', () => toggleCrouch());
$('btn-cam').addEventListener('click', () => toggleCam());
$('btn-throw').addEventListener('click', () => throwDecoy());
$('btn-med').addEventListener('click', () => useMed());
$('btn-adr').addEventListener('click', () => useAdr());
$('btn-weap').addEventListener('click', () => { if (G.ch.heavy) { G.wp = G.wp ? 0 : 1; toast(G.wp ? 'Arma pesada' : 'Machete'); } });
$('btn-height').addEventListener('click', () => { if (!G.fp) G.heightSel = (G.heightSel + 1) % 3; });
$('btn-act').addEventListener('click', () => interact());
$('btn-zin').addEventListener('click', () => { cam.dist = Math.max(2.2, cam.dist - 0.8); });
$('btn-zout').addEventListener('click', () => { cam.dist = Math.min(9, cam.dist + 0.8); });
$('btn-menu').addEventListener('click', () => openMenu());
$('btn-desc').addEventListener('click', () => describeScene());

function toggleCrouch() { if (!G.started || G.paused) return; G.crouchOn = !G.crouchOn; toast(G.crouchOn ? 'Sigilo: paso silencioso' : 'De pie'); }
function toggleCam() { if (!G.started || G.paused) return; G.fp = !G.fp; if (G.fp) { cam.fp = 0; cam.yaw = P.yaw + Math.PI; } else { cam.yaw = P.yaw + Math.PI; cam.pitch = 0.38; } }

/* ---------- combate: tajo de machete por altura, arma pesada, señuelo, consumibles ---------- */
function curHeight() { if (G.fp) return cam.fp > 0.22 ? 0 : (cam.fp < -0.25 ? 2 : 1); return G.heightSel; } // 0 alto (cabeza) · 1 medio · 2 bajo (piernas)
function pickZone(z, kind) {
  if (kind === 0) return z.cut[ZH] ? ZT : ZH;
  if (kind === 1) { const zi = [ZT, ZRA, ZT, ZLA][G.swingN & 3]; return (zi !== ZT && z.cut[zi]) ? ZT : zi; }
  const a = (G.swingN & 1) ? ZRL : ZLL, b = a === ZLL ? ZRL : ZLL;
  return !z.cut[a] ? a : (!z.cut[b] ? b : ZT);
}
function attack() {
  if (!G.started || G.paused || G.dead || G.busy || ui.creator) return;
  if (G.wp === 1) { fire(); return; }
  if (G.swing >= 0 || G.cd > 0) return;
  G.swing = 0; G.swingKind = curHeight(); G.swingN++; G.hitDone = false; G.cd = 0.5;
  if (!G.fp && G.mode === 1) { // ayuda de puntería: gira hacia el infectado más cercano
    const l = Zombies.query(P.x, P.z, Math.sin(P.yaw), Math.cos(P.yaw), 3.2, -1, P.zone);
    if (l.length) P.yaw = Math.atan2(l[0].x - P.x, l[0].z - P.z);
  }
  Noise.emit(P.x, P.z, 11 * G.ch.foot, P.zone); // machete: ruido medio, mucho menor que un arma pesada
}
function doSlashHit() {
  if (G.mode !== 1) return;
  const fx = Math.sin(P.yaw), fz = Math.cos(P.yaw), list = Zombies.query(P.x, P.z, fx, fz, 1.9 * G.ch.reach, 0.42, P.zone);
  const n = G.swingKind === 1 ? Math.min(list.length, 3) : Math.min(list.length, 1);
  for (let i = 0; i < n; i++) {
    const z = list[i];
    Zombies.hit(z, pickZone(z, G.swingKind), 34 * G.ch.mach * (0.9 + Math.random() * 0.25) * (i ? 0.6 : 1), fx, fz, P);
  }
}
function fire() {
  if (G.cd > 0 || G.jam > 0) return;
  if (G.ammo <= 0) { toast('Sin munición'); G.cd = 0.4; return; }
  G.ammo--; G.cd = 0.3; G.heat += 0.2; G.recoil = 1;
  if (G.heat >= 1) { G.jam = 1.6; toast('Arma sobrecalentada'); }
  Noise.emit(P.x, P.z, 60, P.zone);                                   // disparo pesado: ruido muy amplio
  const fx = Math.sin(P.yaw), fz = Math.cos(P.yaw), cr = 1 - 0.3 * P.crouch;
  const my = P.y + (G.fp ? 1.45 : 1.3) * Character.cfg.height * cr, mx = P.x + fx * 0.7, mz = P.z + fz * 0.7;
  const list = Zombies.query(P.x, P.z, fx, fz, 55, G.fp ? 0.985 : 0.95, P.zone);
  let tg = null; for (const z of list) if (P.zone >= 0 || !World.segBlocked(P.x, P.z, z.x, z.z)) { tg = z; break; }
  if (tg) {
    const k = curHeight(), zone = k === 0 ? ZH : (k === 1 ? ZT : (tg.cut[ZLL] ? ZRL : ZLL)), ty = k === 0 ? 1.65 : (k === 1 ? 1.2 : 0.5);
    Proj.tracer(mx, my, mz, tg.x, tg.y + ty * tg.sc, tg.z);
    Zombies.hit(tg, zone, 70 * (0.9 + Math.random() * 0.2), fx, fz, P);
  } else Proj.tracer(mx, my, mz, mx + fx * 40, my, mz + fz * 40);
}
function throwDecoy() {
  if (!G.started || G.paused || G.dead || G.busy || G.decoy <= 0 || G.cd2 > 0) { if (G.started && G.decoy <= 0) toast('Sin señuelos'); return; }
  G.decoy--; G.cd2 = 0.8;
  const fx = Math.sin(P.yaw), fz = Math.cos(P.yaw), cr = 1 - 0.3 * P.crouch;
  Proj.throwDecoy(P.x + fx * 0.6, P.y + 1.5 * cr, P.z + fz * 0.6, fx, fz, 20 * G.ch.throwR, P.zone, G.ch.throwNoise);
}
function useMed() {
  if (!G.started || G.paused || G.dead) return;
  if (G.med <= 0) { toast('Sin botiquines'); return; }
  if (G.hp >= G.hpMax) { toast('Salud completa'); return; }
  G.med--; G.hp = Math.min(G.hpMax, G.hp + 40 * G.ch.heal); toast('Botiquín usado: +' + Math.round(40 * G.ch.heal) + ' salud');
}
function useAdr() {
  if (!G.started || G.paused || G.dead) return;
  if (G.adr <= 0) { toast('Sin adrenalina'); return; }
  G.adr--; G.adrT = 9; G.tsT = 0.4; G.sta = G.staMax; toast('Adrenalina: cámara lenta');
}
function hurt(dmg) {
  if (G.dead || G.mode !== 1) return;
  G.hp -= dmg; const f = $('flash'); f.style.opacity = 1; setTimeout(() => { f.style.opacity = 0; }, 160);
  if (G.hp <= 0) { G.hp = 0; G.dead = true; $('dead').hidden = false; }
}

/* ---------- transiciones: interiores y viaje rápido ---------- */
function fadeTo(fn) {
  if (G.busy) return;
  G.busy = true; $('fade').style.opacity = 1;
  setTimeout(() => { fn(); $('fade').style.opacity = 0; setTimeout(() => { G.busy = false; }, 260); }, 280);
}
function enterInterior(idx) {
  fadeTo(() => {
    G.outPos = { x: P.x, z: P.z, yaw: P.yaw };
    const s = Interiors.spawn(idx);
    P.zone = idx; P.x = s.x; P.z = s.z; P.y = 0; P.vx = P.vz = P.vy = 0; P.yaw = Math.PI; cam.yaw = 0; Env.inside = true;
    Zombies.enterInterior(idx, G); toast(INT_DEFS[idx].name);
  });
}
function exitInterior() {
  fadeTo(() => {
    const i = P.zone, o = G.outPos || { x: SPAWNS[0].x, z: SPAWNS[0].z, yaw: 0 };
    Zombies.leaveInterior(i); Pieces.clear(); Proj.clear();
    P.zone = -1; P.x = o.x; P.z = o.z; P.y = World.heightAt(o.x, o.z); P.vx = P.vz = P.vy = 0; P.yaw = o.yaw + Math.PI; cam.yaw = o.yaw; Env.inside = false;
  });
}
function travelTo(i) {
  $('travel').hidden = true;
  fadeTo(() => {
    const s = SPAWNS[i];
    P.x = s.x; P.z = s.z; P.y = World.heightAt(s.x, s.z); P.vx = P.vz = P.vy = 0; P.zone = -1; Env.inside = false;
    Pieces.clear(); Proj.clear(); loading = true; $('loading').style.display = 'flex'; toast(SECTORS[i].name);
  });
}
function nearInter() {
  if (P.zone >= 0) { const e = Interiors.exitPos(P.zone); return Math.hypot(P.x - e.x, P.z - e.z) < 1.7 ? { type: 'exit', name: 'Salir' } : null; }
  for (const d of DOORS) if (Math.hypot(P.x - d.x, P.z - d.z) < 2.6) return { type: 'door', name: d.name, idx: d.idx };
  for (const p of TPOSTS) if (Math.hypot(P.x - p.x, P.z - p.z) < 2.8) return { type: 'post', name: 'Viaje rápido' };
  return null;
}
function interact() {
  if (!G.started || G.paused || G.busy || !G.near) return;
  const n = G.near;
  if (n.type === 'door') enterInterior(n.idx); else if (n.type === 'exit') exitInterior(); else if (n.type === 'post') openTravel();
}
function openTravel() {
  const box = $('t-btns'); box.innerHTML = ''; G.paused = true;
  SECTORS.forEach((s, i) => { const b = el('button', 'pill', (i + 1) + '. ' + s.name); b.onclick = () => { G.paused = false; travelTo(i); }; box.appendChild(b); });
  $('travel').hidden = false;
}
$('t-close').addEventListener('click', () => { $('travel').hidden = true; G.paused = false; });
function travelFromMenu() {
  if (G.mode === 1 && Zombies.countNear(P.x, P.z, 25) > 0) { toast('Hay infectados cerca: no puedes viajar ahora'); return; }
  $('menu').hidden = true; openTravel();
}

/* ---------- guardado local ---------- */
function save() {
  if (!G.started || G.dead) return;
  const o = P.zone >= 0 ? (G.outPos || { x: P.x, z: P.z, yaw: P.yaw }) : { x: P.x, z: P.z, yaw: P.yaw };
  store.set('sim3d_save_v2', { v: 2, mode: G.mode, ch: G.chIdx, x: o.x, z: o.z, yaw: o.yaw, hp: G.hp, sta: G.sta, med: G.med, adr: G.adr, decoy: G.decoy, ammo: G.ammo,
    kills: G.kills, dayT: G.dayT, col: Array.from(G.collected), cfg: Character.cfg, wp: G.wp, clr: Zombies.cleared });
}
window.addEventListener('pagehide', save);
document.addEventListener('visibilitychange', () => { if (document.hidden) save(); });

/* ---------- partida: nueva / continuar / reinicio rápido ---------- */
function startGame(fresh) {
  const sv = fresh ? null : store.get('sim3d_save_v2', null);
  G.mode = sv ? sv.mode : menuMode; G.chIdx = sv ? sv.ch : menuChar; G.ch = CHARS[G.chIdx];
  menuChar = G.chIdx; menuMode = G.mode;                       // reiniciar / continuar conserva personaje y modo
  if (sv && sv.cfg) { for (const k in sv.cfg) Character.set(k, sv.cfg[k], true); Character.rebuild(); lastLookChar = G.chIdx; } else ensureLook(G.chIdx);
  G.hpMax = G.ch.hp; G.staMax = G.ch.sta;
  G.hp = sv ? sv.hp : G.hpMax; G.sta = sv ? sv.sta : G.staMax; G.med = sv ? sv.med : 1; G.adr = sv ? sv.adr : 0; G.decoy = sv ? sv.decoy : 3;
  G.ammo = sv ? sv.ammo : (G.ch.heavy ? 24 : 0); G.kills = sv ? sv.kills : 0; G.dayT = sv ? sv.dayT : 0.04; G.wp = sv && G.ch.heavy ? (sv.wp || 0) : 0;
  G.collected = new Set(sv ? sv.col : []); G.heat = 0; G.jam = 0; G.dead = false; G.ts = G.tsT = 1; G.adrT = 0; G.crouchOn = false; G.fp = false;
  G.swing = -1; G.cd = G.cd2 = 0; G.near = null; G.paused = false; G.started = true; G.busy = false;
  Actors.reset(); if (sv && sv.clr) Zombies.cleared = sv.clr.slice(); Pickups.reset(G.collected);
  const st = STARTS[G.chIdx], x = sv ? sv.x : st.x, z = sv ? sv.z : st.z, yaw = sv ? sv.yaw : st.yaw;
  P.zone = -1; Env.inside = false; P.x = x; P.z = z; P.y = World.heightAt(x, z); P.vx = P.vz = P.vy = 0; P.yaw = yaw; P.crouch = 0; P.grounded = true;
  cam.yaw = yaw + Math.PI; cam.pitch = 0.38; cam.fp = 0; camS.y = P.y;
  Env.night = Env.target = 0; $('dead').hidden = true; $('menu').hidden = true; $('fade').style.opacity = 0;
  loading = true; $('loading').style.display = 'flex'; document.body.classList.remove('slow');
  if (G.mode === 1) Zombies.spawnT = 1.5;
  toast(G.mode === 1 ? 'Modo Zombi: usa el sigilo y el machete' : 'Mundo Abierto: explora Zapopan');
}
function openMenu() {
  if (ui.creator) return;
  G.paused = true; buildMenu(); $('menu').hidden = false;
}
function buildMenu() {
  const modes = $('m-modes'), chars = $('m-chars'), btns = $('m-btns'); modes.innerHTML = chars.innerHTML = btns.innerHTML = '';
  [['Mundo Abierto', 0], ['Modo Zombi', 1]].forEach(m => { const b = el('button', 'pill' + (menuMode === m[1] ? ' on' : ''), m[0]); b.onclick = () => { menuMode = m[1]; buildMenu(); }; modes.appendChild(b); });
  CHARS.forEach((c, i) => {
    const d = el('div', 'card' + (menuChar === i ? ' on' : '')); d.style.margin = '5px 0';
    d.appendChild(el('b', '', c.name)); d.appendChild(el('span', '', c.desc)); d.onclick = () => { menuChar = i; buildMenu(); }; chars.appendChild(d);
  });
  if (G.started && !G.dead) { const b = el('button', 'btn', 'Reanudar'); b.style.cssText = 'min-width:150px;background:#ffc857;color:#000'; b.onclick = () => { $('menu').hidden = true; G.paused = false; }; btns.appendChild(b); }
  if (G.started && !G.dead && P.zone < 0) { const b = el('button', 'btn', 'Viaje rápido'); b.onclick = () => travelFromMenu(); btns.appendChild(b); }
  if (store.get('sim3d_save_v2', null)) { const b = el('button', 'btn', 'Continuar partida'); b.onclick = () => startGame(false); btns.appendChild(b); }
  const n = el('button', 'btn', G.started ? 'Nueva con esta selección' : 'Jugar'); n.onclick = () => startGame(true); btns.appendChild(n);
  const c = el('button', 'btn', 'Apariencia'); c.onclick = () => { if (!G.started) { ensureLook(menuChar); P.x = STARTS[menuChar].x; P.z = STARTS[menuChar].z; P.y = World.heightAt(P.x, P.z); } openCreator(); }; btns.appendChild(c);
}
$('d-restart').addEventListener('click', () => startGame(true));
$('d-menu').addEventListener('click', () => { $('dead').hidden = true; G.started = false; openMenu(); });

/* ---------- creador de apariencia (UI) ---------- */
let curTab = 0;
function openCreator() {
  if (ui.creator) return;
  ui.creator = true; document.body.classList.add('cr'); $('creator').hidden = false; $('menu').hidden = true; G.fp = false;
  cam.yaw = P.yaw; cam.pitch = 0.18; input.jx = input.jy = 0; buildCreator();
}
function closeCreator() {
  ui.creator = false; document.body.classList.remove('cr'); $('creator').hidden = true;
  cam.yaw = P.yaw + Math.PI; cam.pitch = 0.38; openMenu();
}
function buildCreator() {
  const tabs = $('cr-tabs'), body = $('cr-body'), keep = body.scrollTop;
  tabs.innerHTML = '';
  Character.TABS.forEach((tb, i) => { const b = el('button', 'tab' + (i === curTab ? ' on' : ''), tb.title); b.onclick = () => { curTab = i; body.scrollTop = 0; buildCreator(); }; tabs.appendChild(b); });
  body.innerHTML = '';
  Character.TABS[curTab].items.forEach(it => {
    const box = el('div', 'ctl'), lbl = el('div', 'lbl'), cur = Character.cfg[it.k];
    lbl.appendChild(el('span', '', it.l));
    if (it.t === 'range') {
      const val = el('span', '', (+cur).toFixed(2)); lbl.appendChild(val); box.appendChild(lbl);
      const inp = el('input'); inp.type = 'range'; inp.min = it.min; inp.max = it.max; inp.step = it.step; inp.value = cur; inp.setAttribute('aria-label', it.l);
      inp.addEventListener('input', () => { Character.set(it.k, parseFloat(inp.value)); val.textContent = (+Character.cfg[it.k]).toFixed(2); });
      box.appendChild(inp);
    } else if (it.t === 'choice') {
      box.appendChild(lbl); const pills = el('div', 'pills');
      it.o.forEach((name, i) => { const b = el('button', 'pill' + (i === cur ? ' on' : ''), name); b.onclick = () => { Character.set(it.k, i); buildCreator(); }; pills.appendChild(b); });
      box.appendChild(pills);
    } else {
      box.appendChild(lbl); const sw = el('div', 'sw');
      CPAL[it.p].forEach((hex, i) => {
        const b = el('button', i === cur ? 'on' : ''); b.setAttribute('aria-label', 'Color ' + (i + 1));
        const dot = el('i'); dot.style.background = '#' + hex.toString(16).padStart(6, '0'); b.appendChild(dot);
        b.onclick = () => { Character.set(it.k, i); buildCreator(); }; sw.appendChild(b);
      });
      box.appendChild(sw);
    }
    body.appendChild(box);
  });
  body.scrollTop = keep;
}
$('cr-close').addEventListener('click', closeCreator);
$('cr-rand').addEventListener('click', () => { Character.randomize(); buildCreator(); });
$('cr-reset').addEventListener('click', () => { Character.reset(); buildCreator(); });

/* ---------- botón atrás (lo llama MainActivity) ---------- */
window.nativeBack = function () {
  if (ui.creator) { closeCreator(); return; }
  if (!$('travel').hidden) { $('travel').hidden = true; G.paused = false; return; }
  if (!$('menu').hidden && G.started && !G.dead) { $('menu').hidden = true; G.paused = false; return; }
  if (G.started && !G.paused) { openMenu(); return; }
  const now = Date.now();
  if (now - exitArmed < 2200) { if (window.Android && window.Android.exitApp) window.Android.exitApp(); return; }
  exitArmed = now; toast('Pulsa atrás otra vez para salir');
};

/* ---------- jugador: movimiento, sigilo, ruido, estamina ---------- */
function updatePlayer(dt) {
  let ix = input.jx, iy = input.jy;
  if (keys['a'] || keys['arrowleft']) ix -= 1;
  if (keys['d'] || keys['arrowright']) ix += 1;
  if (keys['w'] || keys['arrowup']) iy -= 1;
  if (keys['s'] || keys['arrowdown']) iy += 1;
  let mag = Math.hypot(ix, iy);
  if (mag > 1) { ix /= mag; iy /= mag; mag = 1; }
  if (mag < 0.12 || ui.creator || G.dead) { mag = 0; ix = iy = 0; }
  P.crouch += ((G.crouchOn ? 1 : 0) - P.crouch) * Math.min(1, dt * 9);
  const crouched = P.crouch > 0.5;
  const wantRun = mag > 0.88 && !crouched && !G.runLock, running = wantRun && G.sta > 0;
  const pace = SPEEDS[speedIdx].v * G.ch.spd * (running ? 1.65 : 1) * (crouched ? 0.5 : 1);
  const fx = -Math.sin(cam.yaw), fz = -Math.cos(cam.yaw), rx = Math.cos(cam.yaw), rz = -Math.sin(cam.yaw);
  const dx = fx * (-iy) + rx * ix, dz = fz * (-iy) + rz * ix, dl = Math.hypot(dx, dz);
  let tvx = 0, tvz = 0;
  if (dl > 0.001) {
    tvx = dx / dl * pace * mag; tvz = dz / dl * pace * mag;
    if (!G.fp) { let da = Math.atan2(dx, dz) - P.yaw; while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI; P.yaw += da * Math.min(1, dt * 12); }
  }
  if (G.fp) P.yaw = cam.yaw + Math.PI;
  const k = 1 - Math.exp(-(P.grounded ? 14 : 4) * dt);
  P.vx += (tvx - P.vx) * k; P.vz += (tvz - P.vz) * k;
  // se mueve por ejes separados: en pendientes demasiado empinadas se desliza en lugar de atravesar
  const mv = (mx, mz) => {
    if (!mx && !mz) return;
    if (P.grounded && P.zone < 0) { const h0 = World.heightAt(P.x, P.z), h1 = World.heightAt(P.x + mx, P.z + mz); if ((h1 - h0) / Math.hypot(mx, mz) > 0.95) return; }
    P.x += mx; P.z += mz;
  };
  mv(P.vx * dt, 0); mv(0, P.vz * dt);
  if (jumpReq && P.grounded && !ui.creator && !G.dead) { P.vy = 6.3; P.grounded = false; }
  jumpReq = false;
  P.vy -= 18 * dt; P.y += P.vy * dt;
  World.resolve(P);
  P.speedH = Math.hypot(P.vx, P.vz);
  P.phase += P.speedH * dt * 3.6;
  if (P.zone < 0 && P.y < -5) { P.y = World.heightAt(P.x, P.z); P.vy = 0; }
  // estamina
  if (running && P.speedH > 0.5) { G.sta -= 16 * dt; if (G.sta <= 0) { G.sta = 0; G.runLock = true; } } else G.sta = Math.min(G.staMax, G.sta + (crouched ? 18 : 12) * dt);
  if (G.runLock && G.sta > 22) G.runLock = false;
  // ruido dinámico: agachado mínimo · caminar medio · correr amplio (el estudiante pisa más silencioso)
  const moving = P.speedH > 0.5;
  const base = crouched ? (moving ? 4 : 1.5) : (moving ? (running ? 22 : 11) : 2);
  const rad = base * G.ch.foot;
  Noise.hold(rad);
  G.stepT -= dt;
  if (moving && G.stepT <= 0) { G.stepT = 0.55; if (rad > 3) Noise.emit(P.x, P.z, rad, P.zone); }
}

/* ---------- cámara: 3ª persona con colisión · 1ª persona a la altura de los ojos ---------- */
const proj = M4.create(), view = M4.create(), vp = M4.create();
function updateCamera(dt) {
  const h = Character.cfg.height, k = Math.min(1, dt * 6), land = R.aspect >= 1, inside = P.zone >= 0, crh = 1 - 0.3 * P.crouch;
  const fp = G.fp && !ui.creator;
  camS.y += (P.y - camS.y) * Math.min(1, dt * 10);
  let ex, ey, ez, tx, ty, tz;
  if (fp) {
    const eye = 1.55 * h * crh, cp = Math.cos(cam.fp);
    ex = P.x; ey = P.y + eye; ez = P.z;
    tx = ex - Math.sin(cam.yaw) * cp; ty = ey + Math.sin(cam.fp); tz = ez - Math.cos(cam.yaw) * cp;
    camS.ox += (0 - camS.ox) * k; camS.oy += (0 - camS.oy) * k;
  } else {
    camS.dist += ((ui.creator ? 3.4 : cam.dist) - camS.dist) * k;
    camS.ty += ((ui.creator ? 0.9 : 1.25 * crh) * h - camS.ty) * k;
    const tox = ui.creator && land ? Math.min(0.46, 460 / Math.max(1, window.innerWidth)) : 0, toy = ui.creator && !land ? -0.46 : 0;
    camS.ox += (tox - camS.ox) * k; camS.oy += (toy - camS.oy) * k;
    tx = P.x; ty = camS.y + camS.ty; tz = P.z;
    const cp = Math.cos(cam.pitch);
    ex = tx + Math.sin(cam.yaw) * cp * camS.dist; ey = ty + Math.sin(cam.pitch) * camS.dist; ez = tz + Math.cos(cam.yaw) * cp * camS.dist;
    if (inside) {
      const d = INT_DEFS[P.zone];
      ex = Math.min(d.ox + d.w - 0.4, Math.max(d.ox + 0.4, ex)); ez = Math.min(d.oz + d.d - 0.4, Math.max(d.oz + 0.4, ez)); ey = Math.min(d.h - 0.25, Math.max(0.3, ey));
    } else {
      const f = World.camClip(tx, ty, tz, ex, ey, ez);
      if (f < 1) { ex = tx + (ex - tx) * f; ey = ty + (ey - ty) * f; ez = tz + (ez - tz) * f; }
      ey = Math.max(ey, World.heightAt(ex, ez) + 0.35);
    }
  }
  M4.perspective(proj, fp ? (land ? 0.95 : 1.2) : (land ? 0.9 : 1.35), R.aspect, 0.12, 130); // vertical del FOV: en horizontal ~94° de ancho
  proj[8] = camS.ox; proj[9] = camS.oy;
  M4.lookAt(view, ex, ey, ez, tx, ty, tz);
  M4.mul(vp, proj, view);
  Frustum.extract(vp);
  camInfo.x = ex; camInfo.ey = ey; camInfo.z = ez;
  const dx = tx - ex, dz = tz - ez, dl = Math.hypot(dx, dz) || 1; camInfo.fx = dx / dl; camInfo.fz = dz / dl;
}

/* ---------- render: frustum → oclusión → LOD (en mundo) · interiores suspenden el exterior ---------- */
const chr = { x: 0, y: 0, z: 0, yaw: 0, phase: 0, speed: 0, grounded: true, t: 0, crouch: 0, swing: -1, swingKind: 1, weapon: 1 };
function drawFPWeapon() {
  const h = Character.cfg.height, crh = 1 - 0.3 * P.crouch, kind = G.swingKind, u = G.swing;
  FS.reset(); FS.translate(P.x, P.y + 1.55 * h * crh, P.z); FS.rotY(cam.yaw + Math.PI); FS.rotX(-cam.fp);
  const skin = Character.k.skin;
  if (G.wp === 1) {
    FS.translate(-0.2, -0.22, 0.42 - 0.07 * G.recoil); FS.rotX(-1.5 + 0.08 * G.recoil);
    R.drawPart(AM.rifle, FS.m(), 1.1, 1.1, 1.1, [1, 1, 1], 1);
    FS.push(); FS.translate(0, -0.1, 0); R.drawPart(Character.M.sph, FS.m(), 0.1, 0.1, 0.1, skin, 1); FS.pop();
    return;
  }
  FS.translate(-0.3, -0.3, 0.5);
  let a = -1.25, sweep = 0;
  if (u >= 0) {
    const e = u * u * (3 - 2 * u);
    if (kind === 0) a = u < 0.35 ? -1.25 - 1.3 * (u / 0.35) : -2.55 + 2.0 * ((u - 0.35) / 0.65);
    else if (kind === 1) { a = -1.4; sweep = 0.9 - 1.9 * e; }
    else { a = -1.0 + 0.8 * e; sweep = 0.5 - 1.0 * e; FS.translate(0, -0.15 * e, 0); }
  }
  FS.rotY(sweep); FS.rotX(a);
  R.drawPart(AM.machete, FS.m(), 1.3, 1.3, 1.3, [1, 1, 1], 1);
  FS.push(); R.drawPart(Character.M.sph, FS.m(), 0.09, 0.09, 0.09, skin, 1); FS.pop();
}
function render() {
  const inside = P.zone >= 0; Env.inside = inside;
  R.begin(Env.cur()); R.setVP(vp); R.useStatic();
  if (inside) Interiors.draw(R, P.zone); else World.draw(R, camInfo, frameN);
  Pickups.draw(R, S2, AM, camInfo, frameN, P);
  Npcs.draw(R, camInfo, frameN, P);
  Zombies.draw(R, camInfo, frameN, P);
  Pieces.draw(R, S2, P.zone);
  Proj.draw(R, S2, AM, P.zone);
  if (G.fp && !ui.creator) drawFPWeapon();
  else {
    chr.x = P.x; chr.y = P.y; chr.z = P.z; chr.yaw = P.yaw; chr.phase = P.phase; chr.speed = P.speedH; chr.grounded = P.grounded; chr.t = t; chr.crouch = P.crouch;
    chr.swing = G.swing; chr.swingKind = G.swingKind; chr.weapon = ui.creator ? 0 : (G.wp === 1 ? 2 : 1);
    Character.draw(R, chr);
    Character.shadow(R, P.x, P.support, P.z, P.y - P.support);
  }
}

/* ---------- burbujas de diálogo (3 elementos reutilizados, con enfriamiento en los NPC) ---------- */
function updateBubbles(dt) {
  for (const b of bubbles) {
    if (b.t <= 0) continue;
    b.t -= dt;
    if (b.t <= 0 || !b.n || P.zone >= 0) { b.t = 0; b.d.style.display = 'none'; continue; }
    const x = b.n.x, y = b.n.y + 2.05 * b.n.sc, z = b.n.z, m = vp;
    const cw = m[3] * x + m[7] * y + m[11] * z + m[15];
    if (cw <= 0.1) { b.d.style.display = 'none'; continue; }
    const px = (((m[0] * x + m[4] * y + m[8] * z + m[12]) / cw) * 0.5 + 0.5) * window.innerWidth;
    const py = (1 - (((m[1] * x + m[5] * y + m[9] * z + m[13]) / cw) * 0.5 + 0.5)) * window.innerHeight;
    if (px < -40 || px > window.innerWidth + 40 || py < -40 || py > window.innerHeight + 40) { b.d.style.display = 'none'; continue; }
    b.d.style.display = 'block'; b.d.style.transform = 'translate(' + Math.round(px - 80) + 'px,' + Math.round(py - 34) + 'px)';
  }
}

/* ---------- brújula ligera (rumbo, puertas/postes y infectados cercanos) ---------- */
const cctx = $('compass').getContext('2d');
const CARD = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'];
const CARDN = ['norte', 'noreste', 'este', 'sureste', 'sur', 'suroeste', 'oeste', 'noroeste'];
function heading() { return Math.atan2(camInfo.fx, -camInfo.fz); }       // 0 = norte (−z) · π/2 = este (+x)
function cardIdx(h) { return ((Math.round(h / (Math.PI / 4)) % 8) + 8) % 8; }
function bearingOf(x, z) { return Math.atan2(x - P.x, -(z - P.z)); }
function drawCompass() {
  if (!cctx) return;
  const W = 200, hd = heading(), half = Math.PI / 2;
  const xOf = a => { let d = a - hd; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return Math.abs(d) > half ? -1 : W / 2 + (d / half) * (W / 2 - 4); };
  cctx.clearRect(0, 0, W, 28); cctx.fillStyle = 'rgba(20,20,28,0.82)'; cctx.fillRect(0, 0, W, 28);
  cctx.textAlign = 'center'; cctx.textBaseline = 'middle';
  for (let k = 0; k < 24; k++) {
    const x = xOf(k * Math.PI / 12); if (x < 0) continue;
    if (k % 3 === 0) { cctx.fillStyle = k % 6 === 0 ? '#ffc857' : '#c9c9d8'; cctx.font = (k % 6 === 0 ? 'bold 13px' : '10px') + ' sans-serif'; cctx.fillText(CARD[k / 3], x, 9); }
    else { cctx.fillStyle = '#6a6a7e'; cctx.fillRect(x - 0.5, 5, 1, 6); }
  }
  const dia = (x, col) => { cctx.fillStyle = col; cctx.beginPath(); cctx.moveTo(x, 15); cctx.lineTo(x + 4, 20); cctx.lineTo(x, 25); cctx.lineTo(x - 4, 20); cctx.closePath(); cctx.fill(); };
  if (P.zone >= 0) { const e = Interiors.exitPos(P.zone), x = xOf(bearingOf(e.x, e.z)); if (x >= 0) dia(x, '#59d8c8'); }
  else {
    for (const d of DOORS) { if (Math.hypot(d.x - P.x, d.z - P.z) < 170) { const x = xOf(bearingOf(d.x, d.z)); if (x >= 0) dia(x, '#ffc857'); } }
    for (const p of TPOSTS) { if (Math.hypot(p.x - P.x, p.z - P.z) < 170) { const x = xOf(bearingOf(p.x, p.z)); if (x >= 0) dia(x, '#59d8c8'); } }
  }
  for (const z of Zombies.pool) {
    if (!z.active || z.dead || z.zone !== P.zone) continue;
    const d = Math.hypot(z.x - P.x, z.z - P.z); if (d > 35) continue;
    const x = xOf(bearingOf(z.x, z.z)); if (x < 0) continue;
    cctx.fillStyle = '#ff5a5f'; cctx.beginPath(); cctx.arc(x, 21, d < 12 ? 4 : 3, 0, 6.283); cctx.fill();
  }
  cctx.fillStyle = '#ffffff'; cctx.beginPath(); cctx.moveTo(W / 2 - 4, 0); cctx.lineTo(W / 2 + 4, 0); cctx.lineTo(W / 2, 5); cctx.closePath(); cctx.fill();
}
/** Dirección relativa a hacia dónde mira la cámara. */
function relDir(dx, dz) {
  const fwd = dx * camInfo.fx + dz * camInfo.fz, right = -dx * camInfo.fz + dz * camInfo.fx;
  const a = Math.abs(Math.atan2(right, fwd)) * 180 / Math.PI, lado = right >= 0 ? 'derecha' : 'izquierda';
  if (a < 22) return 'al frente'; if (a < 67) return 'al frente a la ' + lado; if (a < 112) return 'a la ' + lado; if (a < 157) return 'atrás a la ' + lado; return 'atrás';
}
const DOORN = { aula: 'la puerta del aula', bunker: 'la caseta del retén', cabana: 'la cabaña' };
const PICKN = { med: 'un botiquín', adr: 'un inyector de adrenalina', ammo: 'una caja de munición', decoy: 'señuelos' };
/** Descripción breve del entorno (texto discreto en el HUD). Devuelve las líneas mostradas. */
function describeScene() {
  if (!G.started || ui.creator) return [];
  const L = [], inside = P.zone >= 0, nl = Noise.level;
  L.push('Miras al ' + CARDN[cardIdx(heading())] + ' en ' + (inside ? INT_DEFS[P.zone].name : SECTORS[sectorAt(P.x, P.z)].name) + (inside ? '.' : (G.night ? ', de noche.' : ', de día.')));
  L.push('Salud ' + Math.round(100 * G.hp / G.hpMax) + '%. ' + (P.crouch > 0.5 ? 'Agachado: sigilo activo' : 'De pie') + ', ruido ' + (nl < 4 ? 'mínimo' : nl < 13 ? 'medio' : nl < 30 ? 'amplio' : 'muy amplio') + '.');
  let best = null, bd = 45;
  const consider = (txt, x, z) => { const d = Math.hypot(x - P.x, z - P.z); if (d < bd) { bd = d; best = txt + ' a ' + Math.round(d) + ' m, ' + relDir(x - P.x, z - P.z) + '.'; } };
  if (inside) { const e = Interiors.exitPos(P.zone); consider('La salida', e.x, e.z); }
  else { for (const d of DOORS) consider('Hay ' + DOORN[d.id], d.x, d.z); for (const p of TPOSTS) consider('Hay un poste de viaje rápido', p.x, p.z); }
  for (const p of Pickups.list) if (!p.got && p.zone === P.zone) consider('Hay ' + PICKN[p.t], p.x, p.z);
  if (best) L.push(best);
  if (G.mode === 1) {
    let n = 0, near = null, nd = 1e9;
    for (const z of Zombies.pool) { if (!z.active || z.dead || z.zone !== P.zone) continue; const d = Math.hypot(z.x - P.x, z.z - P.z); if (d < 30) { n++; if (d < nd) { nd = d; near = z; } } }
    L.push(n ? 'Infectados cerca: ' + n + '. El más próximo a ' + Math.round(nd) + ' m, ' + relDir(near.x - P.x, near.z - P.z) + '.' : 'Sin infectados cerca.');
  } else {
    let np = null, pd = 18; for (const n of Npcs.list) { if (!n.act) continue; const d = Math.hypot(n.x - P.x, n.z - P.z); if (d < pd) { pd = d; np = n; } }
    if (np) L.push('Hay una persona a ' + Math.round(pd) + ' m, ' + relDir(np.x - P.x, np.z - P.z) + '.');
  }
  showDesc(L); return L;
}
let descT = 0;
function showDesc(lines) {
  const d = $('desc'); d.innerHTML = '';
  lines.slice(0, 4).forEach(t => d.appendChild(el('div', '', t)));
  d.hidden = false; clearTimeout(descT); descT = setTimeout(() => { d.hidden = true; }, 7000);
}

/* ---------- HUD ---------- */
const hudC = {};
function setText(id, v) { if (hudC[id] !== v) { hudC[id] = v; $(id).textContent = v; } }
function updateHud() {
  const ch = G.ch;
  setText('sector', SECTORS[sectorAt(P.x, P.z)].name + (P.zone >= 0 ? ' · ' + INT_DEFS[P.zone].name : '') + (G.mode === 1 ? ' · Bajas ' + G.kills : ''));
  const hrs = (6 + G.dayT * 24) % 24; setText('clock', (G.night ? 'Noche ' : 'Día ') + String(Math.floor(hrs)).padStart(2, '0') + ':' + String(Math.floor((hrs % 1) * 60)).padStart(2, '0') + (G.adrT > 0 ? ' · Adrenalina ' + Math.ceil(G.adrT) + 's' : ''));
  setText('hptxt', 'Salud ' + Math.ceil(G.hp) + '/' + G.hpMax);
  $('hpf').style.width = (100 * G.hp / G.hpMax).toFixed(0) + '%'; $('stf').style.width = (100 * G.sta / G.staMax).toFixed(0) + '%';
  setText('ammo', ch.heavy ? ('Munición ' + G.ammo + ' · Calor ' + Math.round(G.heat * 100) + '%' + (G.jam > 0 ? ' (enfriando)' : '')) : '');
  const nl = Noise.level; $('noisef').style.width = Math.min(100, nl / 60 * 100).toFixed(0) + '%';
  setText('noisel', 'Ruido: ' + (nl < 4 ? 'Mínimo' : nl < 13 ? 'Medio' : nl < 30 ? 'Amplio' : 'Muy amplio'));
  setText('btn-crouch', G.crouchOn ? 'De pie' : 'Agachar');
  setText('btn-cam', G.fp ? '3ª persona' : '1ª persona');
  setText('btn-height', G.fp ? 'Auto: ' + ['Alto', 'Medio', 'Bajo'][curHeight()] : 'Altura: ' + ['Alto', 'Medio', 'Bajo'][G.heightSel]);
  setText('btn-atk', G.wp === 1 ? 'Disparo' : 'Tajo');
  setText('btn-med', 'Botiquín ' + G.med); setText('btn-adr', 'Adrenalina ' + G.adr); setText('btn-throw', 'Señuelo ' + G.decoy); setText('btn-speed', 'Ritmo: ' + SPEEDS[speedIdx].n);
  drawCompass();
  $('btn-weap').style.display = ch.heavy ? '' : 'none'; setText('btn-weap', G.wp ? 'Usar machete' : 'Usar arma');
  $('cross').style.display = G.fp && !ui.creator ? 'block' : 'none';
  document.body.classList.toggle('slow', G.adrT > 0);
  const ab = $('btn-act');
  if (G.near) { ab.hidden = false; setText('btn-act', G.near.name); } else ab.hidden = true;
}

/* ---------- actualización de juego ---------- */
function gameUpdate(dt) {
  const dtW = dt * G.ts, dtP = dt * Math.min(1, G.ts * 2.1);
  if (G.adrT > 0) { G.adrT -= dt; if (G.adrT <= 0) G.tsT = 1; }
  G.ts += (G.tsT - G.ts) * Math.min(1, dt * 4);
  G.dayT = (G.dayT + dt / 300) % 1;
  const night = G.dayT > 0.6 && G.dayT < 0.92;
  if (night !== G.night) { G.night = night; Env.target = night ? 1 : 0; Npcs.onTime(night, P); }
  G.msgCd -= dt; G.cd -= dtP; G.cd2 -= dtP; G.recoil = Math.max(0, G.recoil - dtP * 6);
  if (G.jam > 0) { G.jam -= dtP; if (G.jam <= 0) G.heat = 0.3; } else G.heat = Math.max(0, G.heat - 0.35 * dtP);
  updatePlayer(dtP);
  if (G.swing >= 0) {
    G.swing += dtP / 0.38;
    if (!G.hitDone && G.swing >= 0.4) { G.hitDone = true; doSlashHit(); }
    if (G.swing >= 1) G.swing = -1;
  }
  Zombies.update(dtW, P, G); Zombies.spawnTick(dtW, P, G); Npcs.update(dtW, P, G);
  Pieces.update(dtW); Proj.update(dtW); Pickups.update(dt, P, G); Noise.decay(dt);
  G.near = G.busy ? null : nearInter();
  G.saveT += dt; if (G.saveT > 8) { G.saveT = 0; save(); }
}

/* ---------- bucle ---------- */
let last = 0, fAcc = 0, fN = 0, fps = 60, hudT = 0, perfT = 0;
function frame(ts) {
  requestAnimationFrame(frame);
  if (document.hidden) { last = ts; return; }
  if (!last) last = ts;
  let dt = (ts - last) / 1000; last = ts;
  if (dt <= 0) return;
  if (dt > 0.05) dt = 0.05;
  if (isPortrait()) { input.jx = input.jy = 0; return; } // en vertical el juego se pausa tras la pantalla «Gira el teléfono»
  t += dt; frameN++;

  if (G.started && !G.paused && !G.busy && !loading) gameUpdate(dt);
  else if (ui.creator) { P.phase += 0; }
  updateCamera(dt); Env.update(dt);
  if (P.zone < 0) World.update(P.x, P.z, loading ? 14 : 2.5);
  if (loading) {
    const n = World.count(), pend = World.pending();
    $('loadpct').textContent = n + ' zonas listas · ' + pend + ' pendientes';
    if (pend === 0 && World.cellLoaded(P.x, P.z)) { loading = false; $('loading').style.display = 'none'; }
  }
  render();
  updateBubbles(dt);

  fAcc += dt; fN++; hudT += dt; perfT += dt;
  if (fAcc >= 0.5) { fps = Math.round(fN / fAcc); fAcc = 0; fN = 0; }
  if (hudT > 0.15) {
    hudT = 0; updateHud();
    const st = World.stats;
    setText('info', fps + ' fps · res ' + Math.round(resScale * 100) + '% · celdas ' + st.drawn + ' (LOD ' + st.lod.join('/') + ') · fuera ' + st.culled + ' · ocultas ' + st.occl + ' · ' + Math.round(st.verts / 1000) + 'k vért');
  }
  if (perfT > 3 && !loading) {
    perfT = 0;
    if (fps < 40 && resScale > 0.55) { resScale = Math.max(0.55, resScale - 0.1); resize(); store.set('sim3d_res', resScale); }
    else if (fps >= 58 && resScale < 1) { resScale = Math.min(1, resScale + 0.05); resize(); store.set('sim3d_res', resScale); }
  }
}

const isPortrait = () => window.innerHeight > window.innerWidth;
try { if (typeof screen !== 'undefined' && screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(() => { /* el Manifest ya fuerza horizontal */ }); } catch (e) { /* ignorar */ }
// arranque: el mundo se construye detrás del menú
ensureLook(menuChar);
P.x = STARTS[menuChar].x; P.z = STARTS[menuChar].z; P.y = World.heightAt(P.x, P.z); camS.y = P.y;
buildMenu(); $('loading').style.display = 'none';
requestAnimationFrame(frame);
window.__sim = { describeScene, G, P, cam, World, Zombies, Npcs, Noise, startGame, attack, fire, throwDecoy, enterInterior, exitInterior, travelTo, interact, hurt, save, chars: CHARS };
})();
